import axios from 'axios';

const api = axios.create({
  baseURL: '/api',
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('pharmaflow_token');
  const companyId = localStorage.getItem('pharmaflow_company_id');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  if (companyId) {
    config.headers['x-company-id'] = companyId;
  }
  return config;
});

api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('pharmaflow_token');
      localStorage.removeItem('pharmaflow_user');
      localStorage.removeItem('pharmaflow_company_id');
      window.location.reload();
    }
    return Promise.reject(error);
  }
);

export default api;
