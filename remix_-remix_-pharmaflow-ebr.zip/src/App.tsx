import React, { useState, useEffect, useRef } from 'react';
import { GoogleGenAI, Type } from "@google/genai";
import { 
  DndContext, 
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  verticalListSortingStrategy,
  useSortable,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { 
  LayoutDashboard, 
  PlusCircle, 
  ClipboardList, 
  History, 
  LogOut, 
  User as UserIcon,
  ChevronRight,
  ChevronLeft,
  CheckCircle2,
  Clock,
  AlertCircle,
  AlertTriangle,
  Calendar,
  FileText,
  Search,
  Bell,
  Menu,
  X,
  ArrowRight,
  ArrowLeft,
  ArrowRightLeft,
  Send,
  Check,
  RotateCcw,
  Ban,
  Download,
  FileSpreadsheet,
  FileJson,
  Edit3,
  Edit2,
  Calculator,
  Table as TableIcon,
  Upload,
  Eye,
  Settings,
  Database,
  Shield,
  Plus,
  Minus,
  Trash2,
  RefreshCw,
  Lock,
  Warehouse,
  Package,
  Truck,
  ShoppingCart,
  ShieldCheck,
  Wrench,
  Layers,
  BarChart3,
  QrCode,
  Scale,
  HelpCircle,
  Activity,
  UserPlus,
  Key,
  Cpu,
  TrendingUp,
  DollarSign,
  MessageSquare,
  Sparkles,
  ChevronDown,
  ChevronUp,
  Maximize2,
  Minimize2,
  FileDown,
  PenTool
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  User, Workflow, Instance, AuditLog, Stats, WorkflowStep, WorkflowField, Role, InstanceStatus,
  Warehouse as WarehouseType, Bin, Material, Equipment, BOM, PurchaseOrder, 
  Inspection, MaintenanceLog, Shipment, WeighingSession, FinancialTransaction, Permissions
} from './types';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import * as XLSX from 'xlsx';
import { Toaster, toast } from 'sonner';
import { 
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, BarChart, Bar, Legend, AreaChart, Area
} from 'recharts';
import { cn } from './lib/utils';
import { io, Socket } from 'socket.io-client';
import api from './services/api';
import { ElectronicSignatureModal } from './components/ElectronicSignatureModal';
import { DeviationModal } from './components/DeviationModal';
import { MasterDataPanel } from './components/MasterDataPanel';
import { UserAdminPanel } from './components/UserAdminPanel';
import { AIInsights } from './components/AIInsights';
import { WeighingModule } from './components/WeighingModule';
import { MaterialGenealogy } from './components/MaterialGenealogy';
import { ConfirmationModal } from './components/ConfirmationModal';
import { ReportingCenter } from './components/ReportingCenter';
import { SystemGuide } from './components/SystemGuide';
import { HelpTooltip } from './components/HelpTooltip';

// --- Safe Math Parser (Replacement for eval) ---
const safeEval = (expr: string): number | string => {
  try {
    // Remove all whitespace
    const cleanExpr = expr.replace(/\s+/g, '');
    
    // Only allow numbers, basic operators (+, -, *, /, (, ))
    if (!/^[0-9+\-*/().]+$/.test(cleanExpr)) {
      return 'Error: Invalid Chars';
    }

    // Use Function constructor as a slightly safer alternative to eval for simple math
    // In a real app, use a dedicated math library
    return new Function(`return ${cleanExpr}`)();
  } catch (e) {
    return 'Error';
  }
};

// Extend jsPDF with autotable types
declare module 'jspdf' {
  interface jsPDF {
    autoTable: (options: any) => jsPDF;
  }
}

// --- Components ---

const Sidebar = ({ user, activeTab, setActiveTab, onLogout, isMobileOpen, setIsMobileOpen, isCollapsed, setIsCollapsed, width, setWidth }: { 
  user: User, 
  activeTab: string, 
  setActiveTab: (t: string) => void, 
  onLogout: () => void, 
  isMobileOpen: boolean,
  setIsMobileOpen: (o: boolean) => void,
  isCollapsed: boolean,
  setIsCollapsed: (c: boolean) => void,
  width: number,
  setWidth: (w: number) => void
}) => {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, roles: ['Admin', 'Operator', 'Reviewer', 'QA Approver'], helpText: 'Overview of system status, active batches, and key metrics.' },
    { id: 'workflows', label: 'Workflows', icon: PlusCircle, roles: ['Admin', 'Operator', 'Reviewer', 'QA Approver'], helpText: 'Design and manage digital Master Batch Records (MBR).' },
    { id: 'instances', label: 'Active Tasks', icon: ClipboardList, roles: ['Admin', 'Operator', 'Reviewer', 'QA Approver'], helpText: 'Execute and monitor ongoing batch production instances.' },
    { id: 'weighing-workflow', label: 'Weighing Workflow', icon: Scale, roles: ['Admin', 'Operator', 'Reviewer', 'QA Approver'], helpText: 'Dedicated module for material weighing and dispensing.' },
    { id: 'genealogy', label: 'Genealogy Map', icon: Layers, roles: ['Admin', 'Operator', 'Reviewer', 'QA Approver'], helpText: 'Trace material flow and batch relationships visually.' },
    { id: 'master-data', label: 'Master Data', icon: Database, roles: ['Admin'], helpText: 'Manage system-wide data like products, materials, and equipment.' },
    { id: 'inventory', label: 'Inventory & Assets', icon: TableIcon, roles: ['Admin', 'Operator', 'Reviewer', 'QA Approver'], helpText: 'Track warehouse inventory and equipment status.' },
    { id: 'supply-chain', label: 'Supply Chain', icon: Truck, roles: ['Admin', 'Operator', 'Reviewer', 'QA Approver'], helpText: 'Manage production scheduling and logistics.' },
    { id: 'quality', label: 'Quality & QC', icon: ShieldCheck, roles: ['Admin', 'Operator', 'Reviewer', 'QA Approver'], helpText: 'Manage deviations, CAPAs, and batch release processes.' },
    { id: 'reports', label: 'Report Center', icon: BarChart3, roles: ['Admin', 'Operator', 'Reviewer', 'QA Approver'], helpText: 'Access and generate system reports and analytics.' },
    { id: 'audit', label: 'Audit Trail', icon: History, roles: ['Admin', 'Operator', 'Reviewer', 'QA Approver'], helpText: 'View a complete history of all system transactions and changes.' },
    { id: 'ai_insights', label: 'AI Insights', icon: Sparkles, roles: ['Admin', 'Operator', 'Reviewer', 'QA Approver'], helpText: 'Get AI-powered insights and optimizations for your processes.' },
  ];

  const handleTabClick = (id: string) => {
    setActiveTab(id);
    setIsMobileOpen(false);
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    e.preventDefault();
    const startX = e.clientX;
    const startWidth = width;

    const handleMouseMove = (moveEvent: MouseEvent) => {
      const newWidth = Math.max(80, Math.min(400, startWidth + moveEvent.clientX - startX));
      setWidth(newWidth);
    };

    const handleMouseUp = () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
  };

  return (
    <>
      {/* Mobile Backdrop */}
      <AnimatePresence>
        {isMobileOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsMobileOpen(false)}
            className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-[60] lg:hidden"
          />
        )}
      </AnimatePresence>

      <div 
        style={{ width: isCollapsed ? 80 : width }}
        className={cn(
          "h-screen bg-pharma-primary text-white flex flex-col fixed left-0 top-0 z-[70] transition-all duration-300 lg:translate-x-0",
          isMobileOpen ? "translate-x-0" : "-translate-x-full"
        )}
      >
        <div className="absolute right-0 top-0 bottom-0 w-1 cursor-col-resize hover:bg-pharma-accent" onMouseDown={handleMouseDown} />
        <div className="p-6 flex items-center justify-between border-b border-white/10">
          <button 
            onClick={() => handleTabClick('dashboard')}
            className="flex items-center gap-3 overflow-hidden hover:opacity-80 transition-opacity"
          >
            <div className="w-8 h-8 bg-pharma-accent rounded-lg flex items-center justify-center flex-shrink-0">
              <FileText className="text-white w-5 h-5" />
            </div>
            {!isCollapsed && <span className="font-bold text-xl tracking-tight whitespace-nowrap">PharmaFlow</span>}
          </button>
          <button 
            onClick={() => setIsCollapsed(!isCollapsed)}
            className="p-2 hover:bg-white/10 rounded-lg transition-colors text-slate-400 hover:text-white hidden lg:block"
          >
            {isCollapsed ? <ChevronRight size={20} /> : <ChevronLeft size={20} />}
          </button>
          <button 
            onClick={() => setIsMobileOpen(false)}
            className="p-2 hover:bg-white/10 rounded-lg transition-colors text-slate-400 hover:text-white lg:hidden"
          >
            <X size={20} />
          </button>
        </div>
        
        <nav className="flex-1 p-4 space-y-2 overflow-y-auto custom-scrollbar">
          {menuItems.filter(item => item.roles.includes(user.role)).map((item) => (
            <button
              key={item.id}
              onClick={() => handleTabClick(item.id)}
              className={cn(
                "w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all",
                activeTab === item.id 
                  ? 'bg-pharma-accent text-white shadow-lg shadow-pharma-accent/20' 
                  : 'text-slate-400 hover:text-white hover:bg-white/5',
                isCollapsed && "justify-center px-0"
              )}
            >
              <item.icon size={20} />
              {!isCollapsed && <span className="font-medium flex-1 text-left">{item.label}</span>}
              {!isCollapsed && <HelpTooltip text={item.helpText} guideLink={item.id} className="text-white/40 hover:text-white" />}
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-white/10">
          <button 
            onClick={onLogout}
            className={cn(
              "w-full flex items-center gap-2 px-2 py-1.5 text-slate-400 hover:text-white hover:bg-white/5 rounded-lg transition-all text-xs",
              isCollapsed && "justify-center"
            )}
          >
            <LogOut size={14} />
            {!isCollapsed && <span className="font-medium">Logout</span>}
          </button>
          <div className={cn("flex items-center gap-2 px-2 py-1.5 mt-1", isCollapsed && "justify-center")}>
            <div className="w-6 h-6 bg-slate-700 rounded-full flex items-center justify-center flex-shrink-0">
              <UserIcon size={12} />
            </div>
            {!isCollapsed && (
              <div className="overflow-hidden">
                <p className="text-[10px] font-semibold truncate">{user.full_name}</p>
                <p className="text-[9px] text-slate-400">{user.role}</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
};

// --- New Components for Client Readiness ---

const BarcodeModal = ({ item, isOpen, onClose }: { item: any, isOpen: boolean, onClose: () => void }) => {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
      <motion.div 
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="bg-white rounded-3xl shadow-2xl max-w-sm w-full p-8 text-center space-y-6"
      >
        <div className="flex justify-between items-center">
          <h3 className="text-lg font-bold text-slate-900">Barcode Label</h3>
          <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded-full transition-colors">
            <X size={20} />
          </button>
        </div>
        
        <div className="p-6 bg-slate-50 rounded-2xl border-2 border-dashed border-slate-200 flex flex-col items-center gap-4">
          <div className="w-full h-24 bg-white border border-slate-200 rounded flex flex-col items-center justify-center p-2">
            <div className="flex gap-1 h-12 items-end mb-2">
              {[2, 4, 1, 3, 2, 5, 1, 4, 2, 3, 1, 5, 2, 4].map((h, i) => (
                <div key={i} className="bg-black w-1" style={{ height: `${h * 15}%` }} />
              ))}
            </div>
            <p className="text-[10px] font-mono tracking-[0.3em] text-slate-900">*{item.sku || item.asset_id}*</p>
          </div>
          <div className="text-left w-full space-y-1">
            <p className="text-xs font-bold text-slate-900 truncate">{item.name}</p>
            <p className="text-[10px] text-slate-500">LOT: {item.lot_number || 'N/A'}</p>
            <p className="text-[10px] text-slate-500">EXP: {item.expiry_date || 'N/A'}</p>
          </div>
        </div>

        <div className="flex gap-3">
          <button onClick={onClose} className="flex-1 py-3 bg-slate-100 text-slate-700 rounded-xl font-bold hover:bg-slate-200 transition-all">
            Close
          </button>
          <button 
            onClick={() => { toast.success("Sent to printer"); onClose(); }}
            className="flex-1 py-3 bg-pharma-primary text-white rounded-xl font-bold hover:bg-pharma-primary/90 transition-all flex items-center justify-center gap-2"
          >
            <Download size={18} /> Print
          </button>
        </div>
      </motion.div>
    </div>
  );
};

const Skeleton = ({ className }: { className?: string, key?: any }) => (
  <div className={cn("animate-pulse bg-slate-200 rounded", className)} />
);

const getStatusColor = (status: string) => {
  switch (status) {
    case 'Executing': return 'bg-blue-100 text-blue-700 border border-blue-200';
    case 'Under Review': return 'bg-amber-100 text-amber-700 border border-amber-200';
    case 'QA Review': return 'bg-purple-100 text-purple-700 border border-purple-200';
    case 'Quarantine': return 'bg-red-100 text-red-700 border border-red-200';
    case 'Released': return 'bg-emerald-100 text-emerald-700 border border-emerald-200';
    case 'Work in Process': return 'bg-indigo-100 text-indigo-700 border border-indigo-200';
    case 'Completed': return 'bg-emerald-100 text-emerald-700 border border-emerald-200';
    case 'Discontinued': return 'bg-red-100 text-red-700 border border-red-200';
    case 'Archived': return 'bg-slate-200 text-slate-700 border border-slate-300';
    case 'Scheduled': return 'bg-purple-100 text-purple-700 border border-purple-200';
    default: return 'bg-slate-100 text-slate-700 border border-slate-200';
  }
};

const Pagination = ({ current, total, limit, onPageChange }: { current: number, total: number, limit: number, onPageChange: (p: number) => void }) => {
  const totalPages = Math.ceil(total / limit);
  if (totalPages <= 1) return null;
  return (
    <div className="flex items-center justify-center gap-2 mt-6">
      <button 
        disabled={current === 1}
        onClick={() => onPageChange(current - 1)}
        className="p-2 rounded-lg hover:bg-slate-100 disabled:opacity-30 transition-colors"
      >
        <ChevronLeft size={20} />
      </button>
      <span className="text-sm font-bold text-slate-600">Page {current} of {totalPages}</span>
      <button 
        disabled={current === totalPages}
        onClick={() => onPageChange(current + 1)}
        className="p-2 rounded-lg hover:bg-slate-100 disabled:opacity-30 transition-colors"
      >
        <ChevronRight size={20} />
      </button>
    </div>
  );
};

const CostAnalysis = () => {
  const [data, setData] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    api.get('/reports/financials')
      .then(res => res.data)
      .then(setData)
      .catch(() => toast.error("Failed to fetch financial data"))
      .finally(() => setIsLoading(false));
  }, []);

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[1,2,3].map(i => <Skeleton key={i} className="h-24" />)}
        </div>
        <Skeleton className="h-80" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="glass-panel p-6">
          <p className="text-xs font-bold text-slate-400 uppercase">Avg. Batch Profit</p>
          <p className="text-2xl font-bold text-emerald-600">
            ${(data.reduce((acc, curr) => acc + curr.profit, 0) / (data.length || 1)).toLocaleString()}
          </p>
          <p className="text-[10px] text-emerald-500 mt-1">↑ 12% from last month</p>
        </div>
        <div className="glass-panel p-6">
          <p className="text-xs font-bold text-slate-400 uppercase">Labor Efficiency</p>
          <p className="text-2xl font-bold text-blue-600">94.2%</p>
          <p className="text-[10px] text-blue-500 mt-1">↑ 2.4% improvement</p>
        </div>
        <div className="glass-panel p-6">
          <p className="text-xs font-bold text-slate-400 uppercase">Material Variance</p>
          <p className="text-2xl font-bold text-amber-600">-1.5%</p>
          <p className="text-[10px] text-amber-500 mt-1">Within tolerance</p>
        </div>
      </div>

      <div className="glass-panel p-6">
        <h3 className="text-sm font-bold text-slate-500 uppercase mb-6">Batch Profitability vs Labor Cost</h3>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis dataKey="name" fontSize={10} />
              <YAxis fontSize={10} />
              <Tooltip 
                contentStyle={{ backgroundColor: '#fff', borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
              />
              <Legend />
              <Bar dataKey="profit" fill="#10b981" radius={[4, 4, 0, 0]} name="Profit ($)" />
              <Bar dataKey="labor" fill="#3b82f6" radius={[4, 4, 0, 0]} name="Labor Cost ($)" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
const DashboardCharts = ({ setActiveTab }: { setActiveTab: (t: string) => void }) => {
  const [data, setData] = useState<any>(null);
  const [alerts, setAlerts] = useState<{ lowStock: any[], expiringSoon: any[] }>({ lowStock: [], expiringSoon: [] });

  useEffect(() => {
    api.get('/dashboard/charts').then(res => res.data).then(setData);
    api.get('/mrp/alerts').then(res => res.data).then(setAlerts);
  }, []);

  if (!data) return <div className="h-64 flex items-center justify-center text-slate-400">Loading analytics...</div>;

  const COLORS = ['#0f172a', '#3b82f6', '#10b981', '#f59e0b', '#ef4444'];

  return (
    <div className="space-y-6">
      {/* MRP Alerts */}
      {((alerts?.lowStock?.length || 0) > 0 || (alerts?.expiringSoon?.length || 0) > 0) && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {(alerts?.lowStock?.length || 0) > 0 && (
            <div 
              onClick={() => setActiveTab('inventory')}
              className="bg-amber-50 border border-amber-200 rounded-2xl p-4 flex items-start gap-3 cursor-pointer hover:bg-amber-100 transition-colors"
            >
              <AlertCircle className="text-amber-600 shrink-0" size={20} />
              <div>
                <p className="text-sm font-bold text-amber-900">Low Stock Alerts</p>
                <p className="text-xs text-amber-700">{alerts.lowStock.length} items are below reorder point.</p>
              </div>
            </div>
          )}
          {(alerts?.expiringSoon?.length || 0) > 0 && (
            <div 
              onClick={() => setActiveTab('inventory')}
              className="bg-red-50 border border-red-200 rounded-2xl p-4 flex items-start gap-3 cursor-pointer hover:bg-red-100 transition-colors"
            >
              <Clock className="text-red-600 shrink-0" size={20} />
              <div>
                <p className="text-sm font-bold text-red-900">Expiry Alerts</p>
                <p className="text-xs text-red-700">{alerts.expiringSoon.length} items expiring within 30 days.</p>
              </div>
            </div>
          )}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <div className="glass-panel p-6 cursor-pointer hover:shadow-md transition-shadow" onClick={() => setActiveTab('instances')}>
        <h3 className="text-sm font-bold text-slate-500 uppercase mb-6 flex items-center justify-between">
          Batch Production (Last 7 Days)
          <ArrowRight size={16} className="text-slate-400" />
        </h3>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data.yieldTrend || []}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis dataKey="date" fontSize={10} tickFormatter={(str) => str.split('-').slice(1).join('/')} />
              <YAxis fontSize={10} />
              <Tooltip 
                contentStyle={{ backgroundColor: '#fff', borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
              />
              <Line type="monotone" dataKey="count" stroke="#0f172a" strokeWidth={3} dot={{ r: 4, fill: '#0f172a' }} activeDot={{ r: 6 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="glass-panel p-6 cursor-pointer hover:shadow-md transition-shadow" onClick={() => setActiveTab('instances')}>
        <h3 className="text-sm font-bold text-slate-500 uppercase mb-6 flex items-center justify-between">
          Batch Status Distribution
          <ArrowRight size={16} className="text-slate-400" />
        </h3>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={data.statusDist || []}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={80}
                paddingAngle={5}
                dataKey="value"
              >
                {(data.statusDist || []).map((entry: any, index: number) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
              <Legend verticalAlign="bottom" height={36}/>
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
    </div>
  );
};

const GlobalSearch = ({ isOpen, onClose, onSelect }: { isOpen: boolean, onClose: () => void, onSelect: (tab: string, id?: number) => void }) => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<any[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  useEffect(() => {
    if (query.length < 2) {
      setResults([]);
      return;
    }
    const delay = setTimeout(async () => {
      setIsSearching(true);
      try {
        const res = await api.get(`/search?q=${query}`);
        setResults(res.data);
      } catch (e) {
        // Fallback mock results
        setResults([
          { type: 'Workflow', label: 'Paracetamol 500mg MBR', tab: 'workflows' },
          { type: 'Batch', label: 'BN-1122 (In Progress)', tab: 'instances', id: 1122 },
          { type: 'Material', label: 'API-LOT-9921', tab: 'inventory' },
          { type: 'Equipment', label: 'Scale-01 (Cleaned)', tab: 'inventory' },
        ].filter(r => r.label.toLowerCase().includes(query.toLowerCase())));
      } finally {
        setIsSearching(false);
      }
    }, 300);
    return () => clearTimeout(delay);
  }, [query]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-[300] flex items-start justify-center pt-24 p-4">
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[70vh]"
      >
        <div className="p-6 border-b border-slate-100 flex items-center gap-4">
          <Search className="text-pharma-accent" size={24} />
          <input 
            autoFocus
            value={query}
            onChange={e => setQuery(e.target.value)}
            className="flex-1 text-xl font-medium outline-none placeholder:text-slate-300 bg-transparent"
            placeholder="Search workflows, batches, materials, equipment..."
          />
          <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded-full transition-colors"><X size={24} /></button>
        </div>
        
        <div className="flex-1 overflow-y-auto p-4 space-y-2 custom-scrollbar">
          {isSearching ? (
            <div className="py-12 text-center text-slate-400 flex flex-col items-center gap-2">
              <RotateCcw className="animate-spin" size={32} />
              <p className="font-medium">Searching system database...</p>
            </div>
          ) : results.length > 0 ? (
            (Array.isArray(results) ? results : []).map((res, i) => (
              <button
                key={i}
                onClick={() => { onSelect(res.tab, res.id); onClose(); }}
                className="w-full flex items-center gap-4 p-4 rounded-2xl hover:bg-pharma-accent/5 border border-transparent hover:border-pharma-accent/20 transition-all group"
              >
                <div className="w-10 h-10 bg-slate-100 rounded-xl flex items-center justify-center group-hover:bg-pharma-accent group-hover:text-white transition-colors">
                  {res.type === 'Workflow' ? <FileText size={20} /> : res.type === 'Batch' ? <ClipboardList size={20} /> : <Database size={20} />}
                </div>
                <div className="text-left">
                  <p className="font-bold text-slate-900">{res.label}</p>
                  <p className="text-xs text-slate-400 uppercase font-bold">{res.type}</p>
                </div>
                <ChevronRight className="ml-auto text-slate-300 group-hover:text-pharma-accent transition-colors" size={20} />
              </button>
            ))
          ) : query.length >= 2 ? (
            <div className="py-12 text-center text-slate-400">
              <Search className="mx-auto mb-2 opacity-20" size={48} />
              <p>No results found for "{query}"</p>
            </div>
          ) : (
            <div className="py-12 text-center text-slate-300">
              <p className="text-sm font-medium">Type at least 2 characters to search everything</p>
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
};
const ReauthModal = ({ isOpen, onConfirm, onCancel, title, description }: { 
  isOpen: boolean, 
  onConfirm: (password: string) => void, 
  onCancel: () => void,
  title: string,
  description: string
}) => {
  const [password, setPassword] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[200] flex items-center justify-center p-6">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        className="glass-panel p-8 max-w-md w-full space-y-6"
      >
        <div className="flex items-center gap-3 text-pharma-primary">
          <Lock size={24} />
          <h2 className="text-2xl font-bold">{title}</h2>
        </div>
        <p className="text-slate-500 text-sm">{description}</p>
        
        <div className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Confirm Identity (Password)</label>
            <input 
              type="password"
              value={password}
              onChange={e => setPassword(e.target.value)}
              className="input-field"
              placeholder="Enter your password"
              autoFocus
            />
          </div>
        </div>

        <div className="flex gap-4">
          <button onClick={onCancel} className="btn-secondary flex-1">Cancel</button>
          <button 
            onClick={() => {
              setIsVerifying(true);
              onConfirm(password);
            }} 
            disabled={isVerifying || !password}
            className="btn-primary flex-1"
          >
            {isVerifying ? 'Verifying...' : 'Sign & Confirm'}
            <HelpTooltip text="Verify your identity with your system password to proceed with this sensitive action." guideLink="audit" />
          </button>
        </div>
      </motion.div>
    </div>
  );
};

const PasswordReset = ({ onBack }: { onBack: () => void }) => {
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [step, setStep] = useState<'request' | 'confirm'>('request');
  const [isSuccess, setIsSuccess] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleRequestReset = async () => {
    if (!email && !phone) return toast.error('Please provide email or phone');
    setIsLoading(true);
    try {
      const res = await api.post('/auth/request-reset', { email, phone });
      if (res.status === 200) {
        setStep('confirm');
        toast.success('OTP sent to your registered contact');
      } else {
        toast.error('Failed to request reset');
      }
    } catch (e) {
      toast.error('An error occurred');
    } finally {
      setIsLoading(false);
    }
  };

  const handleConfirmReset = async () => {
    if (!otp || !newPassword) return toast.error('Please provide OTP and new password');
    setIsLoading(true);
    try {
      const res = await api.post('/auth/confirm-reset', { email, phone, otp, newPassword });
      if (res.status === 200) {
        setIsSuccess(true);
        toast.success('Password reset successfully!');
      } else {
        toast.error('Invalid or expired OTP');
      }
    } catch (e) {
      toast.error('Failed to reset password');
    } finally {
      setIsLoading(false);
    }
  };

  if (isSuccess) {
    return (
      <div className="text-center space-y-4">
        <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
          <Check size={32} />
        </div>
        <h2 className="text-2xl font-bold">Success!</h2>
        <p className="text-slate-500">Your password has been updated. You can now log in.</p>
        <button onClick={onBack} className="btn-primary w-full">Back to Login</button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-bold">Reset Password</h2>
        <p className="text-slate-500 text-sm">
          {step === 'request' ? 'Enter your registered email or phone to receive an OTP.' : 'Enter the 6-digit OTP sent to you and your new password.'}
        </p>
      </div>
      
      {step === 'request' ? (
        <div className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Email Address</label>
            <input value={email} onChange={e => setEmail(e.target.value)} className="input-field" placeholder="email@example.com" />
          </div>
          <div className="relative">
            <div className="absolute inset-0 flex items-center"><span className="w-full border-t border-slate-200" /></div>
            <div className="relative flex justify-center text-xs uppercase"><span className="bg-white px-2 text-slate-400">Or</span></div>
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Phone Number</label>
            <input value={phone} onChange={e => setPhone(e.target.value)} className="input-field" placeholder="+1 234 567 890" />
          </div>
          <div className="flex flex-col gap-3 pt-4">
            <button onClick={handleRequestReset} disabled={isLoading} className="btn-primary w-full">
              {isLoading ? 'Sending...' : 'Request OTP'}
            </button>
            <button onClick={onBack} className="btn-secondary w-full">Back to Login</button>
          </div>
        </div>
      ) : (
        <div className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase mb-1">6-Digit OTP</label>
            <input 
              value={otp} 
              onChange={e => setOtp(e.target.value)} 
              className="input-field text-center tracking-widest font-bold text-lg" 
              placeholder="000000" 
              maxLength={6}
            />
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase mb-1">New Password</label>
            <input type="password" value={newPassword} onChange={e => setNewPassword(e.target.value)} className="input-field" placeholder="••••••••" />
          </div>
          <div className="flex flex-col gap-3 pt-4">
            <button onClick={handleConfirmReset} disabled={isLoading} className="btn-primary w-full">
              {isLoading ? 'Resetting...' : 'Confirm & Reset'}
            </button>
            <button onClick={() => setStep('request')} className="btn-secondary w-full">Back</button>
          </div>
        </div>
      )}
    </div>
  );
};

const AIAssistant = ({ context }: { context: any }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{ role: 'user' | 'ai', text: string }[]>([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim()) return;
    const userMsg = input;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setIsTyping(true);

    try {
      const res = await api.post('/ai/chat', { message: userMsg, context });
      const data = res.data;
      setMessages(prev => [...prev, { role: 'ai', text: data.text }]);
    } catch (e) {
      toast.error('AI Assistant is offline');
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="fixed bottom-4 right-4 md:bottom-6 md:right-6 z-[100]">
      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="bg-white rounded-3xl shadow-2xl w-[calc(100vw-2rem)] md:w-96 h-[500px] max-h-[calc(100vh-8rem)] flex flex-col border border-slate-100 overflow-hidden mb-4"
          >
            <div className="bg-pharma-primary p-4 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sparkles size={20} className="text-pharma-accent" />
                <span className="font-bold">PharmaFlow AI</span>
              </div>
              <button onClick={() => setIsOpen(false)} className="hover:bg-white/10 p-1 rounded-lg"><X size={20} /></button>
            </div>
            <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50">
              {messages.length === 0 && (
                <div className="text-center py-8 space-y-2">
                  <HelpCircle className="mx-auto text-slate-300" size={48} />
                  <p className="text-sm text-slate-500">How can I help you today?</p>
                </div>
              )}
              {messages.map((m, i) => (
                <div key={i} className={cn("flex", m.role === 'user' ? "justify-end" : "justify-start")}>
                  <div className={cn("max-w-[80%] p-3 rounded-2xl text-sm", 
                    m.role === 'user' ? "bg-pharma-primary text-white rounded-tr-none" : "bg-white text-slate-800 shadow-sm border border-slate-100 rounded-tl-none")}>
                    {m.text}
                  </div>
                </div>
              ))}
              {isTyping && (
                <div className="flex justify-start">
                  <div className="bg-white p-3 rounded-2xl rounded-tl-none shadow-sm border border-slate-100 flex gap-1">
                    <span className="w-1.5 h-1.5 bg-slate-300 rounded-full animate-bounce" />
                    <span className="w-1.5 h-1.5 bg-slate-300 rounded-full animate-bounce [animation-delay:0.2s]" />
                    <span className="w-1.5 h-1.5 bg-slate-300 rounded-full animate-bounce [animation-delay:0.4s]" />
                  </div>
                </div>
              )}
            </div>
            <div className="p-4 bg-white border-t border-slate-100 flex gap-2">
              <input 
                value={input} 
                onChange={e => setInput(e.target.value)} 
                onKeyDown={e => e.key === 'Enter' && handleSend()}
                placeholder="Ask anything..." 
                className="flex-1 bg-slate-100 border-none rounded-xl px-4 py-2 text-sm focus:ring-2 focus:ring-pharma-accent"
              />
              <button onClick={handleSend} className="bg-pharma-accent text-white p-2 rounded-xl hover:scale-105 transition-transform">
                <Send size={20} />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="w-14 h-14 bg-pharma-primary text-white rounded-full shadow-xl flex items-center justify-center hover:scale-110 transition-all group"
      >
        <MessageSquare size={24} className="group-hover:rotate-12 transition-transform" />
        <div className="absolute -top-1 -right-1 w-4 h-4 bg-pharma-accent rounded-full border-2 border-white animate-pulse" />
      </button>
    </div>
  );
};

const SettingsMenu = ({ user, isOpen, onClose }: { user: User, isOpen: boolean, onClose: () => void }) => {
  const [activeSubTab, setActiveSubTab] = useState('instructions');
  const [permissions, setPermissions] = useState<Permissions[]>([]);
  const [equipment, setEquipment] = useState<Equipment[]>([]);
  const [recentActivity, setRecentActivity] = useState<AuditLog[]>([]);
  const [isScanning, setIsScanning] = useState(false);
  const [connectedDevices, setConnectedDevices] = useState<any[]>([]);

  const scanNetwork = () => {
    setIsScanning(true);
    toast.info("Scanning local network for IoT equipment...");
    setTimeout(() => {
      setConnectedDevices([
        { id: 1, name: 'Mettler Toledo Scale XP-200', ip: '192.168.1.45', status: 'Connected', type: 'Scale' },
        { id: 2, name: 'Silverson High-Shear Mixer', ip: '192.168.1.48', status: 'Connected', type: 'Mixer' },
        { id: 3, name: 'Temp/Humidity Sensor R101', ip: '192.168.1.52', status: 'Connected', type: 'Sensor' }
      ]);
      setIsScanning(false);
      toast.success("Found 3 devices on network.");
    }, 2500);
  };

  const refreshPermissions = () => {
    api.get('/permissions').then(res => res.data).then(setPermissions);
  };

  useEffect(() => {
    if (isOpen) {
      refreshPermissions();
      // Only fetch if not already loaded or if we need a refresh
      if (equipment.length === 0) {
        api.get('/inventory').then(res => res.data).then(data => setEquipment(data.equipment));
      }
      api.get('/audit').then(res => res.data).then(data => setRecentActivity(Array.isArray(data.data) ? data.data.slice(0, 10) : []));
    }
  }, [isOpen]);

  const togglePermission = async (role: Role, key: string, currentVal: boolean) => {
    if (user.role !== 'Admin') return toast.error("Only Admins can modify permissions.");
    const res = await api.post('/permissions', { role, [key]: !currentVal });
    if (res.status === 200) {
      toast.success(`Permission updated for ${role}`);
      refreshPermissions();
    } else {
      toast.error("Failed to update permission");
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-[200] flex justify-end" onClick={onClose}>
          <motion.div 
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 30, stiffness: 250, mass: 0.8 }}
            onClick={(e) => e.stopPropagation()}
            className="bg-white w-full max-w-4xl h-full shadow-2xl flex flex-col overflow-hidden"
          >
            <div className="p-4 md:p-6 border-b border-slate-100 flex items-center justify-between bg-pharma-primary text-white">
              <div className="flex items-center gap-3">
                <Settings size={24} className="text-pharma-accent" />
                <h2 className="text-lg md:text-xl font-bold truncate">System Settings & Customization</h2>
              </div>
              <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full transition-colors"><X size={24} /></button>
            </div>

            <div className="flex flex-col md:flex-row flex-1 overflow-hidden">
              <div className="w-full md:w-48 bg-slate-50 border-b md:border-b-0 md:border-r border-slate-100 p-2 md:p-4 flex md:flex-col gap-1 overflow-x-auto md:overflow-y-auto whitespace-nowrap md:whitespace-normal custom-scrollbar">
                {[
                  { id: 'instructions', label: 'System Guide', icon: HelpCircle },
                  ...(user.role === 'Admin' ? [{ id: 'user-admin', label: 'User Admin', icon: Shield }] : []),
                  { id: 'permissions', label: 'Permissions', icon: ShieldCheck },
                  { id: 'calibration', label: 'Calibration', icon: Wrench },
                  { id: 'connections', label: 'IoT Connections', icon: Cpu },
                  { id: 'activity', label: 'Recent Activity', icon: Activity },
                ].map(tab => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveSubTab(tab.id)}
                    className={cn("flex items-center gap-3 px-4 py-2 rounded-lg text-sm font-medium transition-all",
                      activeSubTab === tab.id ? "bg-white text-pharma-primary shadow-sm" : "text-slate-500 hover:bg-slate-100")}
                  >
                    <tab.icon size={18} />
                    {tab.label}
                  </button>
                ))}
              </div>

              <div className="flex-1 overflow-y-auto p-4 md:p-8">
                {activeSubTab === 'instructions' && (
                  <SystemGuide />
                )}
                {activeSubTab === 'user-admin' && user.role === 'Admin' && (
                  <UserAdminPanel />
                )}

            {activeSubTab === 'permissions' && (
              <div className="space-y-6">
                <h3 className="text-xl font-bold">Role-Based Access Control</h3>
                <div className="space-y-4">
                  {Array.isArray(permissions) && permissions.map(p => (
                    <div key={p.role} className="p-4 border border-slate-100 rounded-2xl space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-pharma-primary">{p.role}</span>
                        <span className="text-xs bg-slate-100 px-2 py-1 rounded-full text-slate-500">Active</span>
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        {Object.entries(p).filter(([key]) => key.startsWith('can_')).map(([key, val]) => (
                          <button 
                            key={key} 
                            onClick={() => togglePermission(p.role, key, !!val)}
                            disabled={user.role !== 'Admin'}
                            className={cn("flex items-center gap-2 text-xs p-1 rounded hover:bg-slate-50 transition-colors", user.role === 'Admin' ? "cursor-pointer" : "cursor-default")}
                          >
                            <div className={cn("w-4 h-4 rounded flex items-center justify-center", val ? "bg-emerald-500 text-white" : "bg-slate-200")}>
                              {val ? <Check size={10} /> : <X size={10} />}
                            </div>
                            <span className="capitalize">{key.replace('can_', '').replace(/_/g, ' ')}</span>
                          </button>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeSubTab === 'calibration' && (
              <div className="space-y-6">
                <h3 className="text-xl font-bold">Equipment Calibration</h3>
                <div className="space-y-4">
                  {(equipment || []).map(e => (
                    <div key={e.id} className="p-4 border border-slate-100 rounded-2xl flex items-center justify-between">
                      <div>
                        <p className="font-bold text-slate-900">{e.name}</p>
                        <p className="text-xs text-slate-500">Asset ID: {e.asset_id}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-xs font-bold text-slate-400 uppercase">Next Due</p>
                        <p className={cn("text-sm font-bold", new Date(e.next_calibration) < new Date() ? "text-red-500" : "text-emerald-500")}>
                          {e.next_calibration}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeSubTab === 'connections' && (
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <h3 className="text-xl font-bold">IoT & Network Connections</h3>
                  <div className="flex items-center gap-2 text-xs font-bold text-emerald-500 bg-emerald-50 px-2 py-1 rounded-full">
                    <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
                    Network Active
                  </div>
                </div>
                <p className="text-sm text-slate-500">Connect directly to scales, mixers, and sensors on your local network.</p>
                
                <div className="space-y-4">
                  {connectedDevices.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {connectedDevices.map(device => (
                        <div key={device.id} className="p-4 border border-slate-100 rounded-2xl bg-white shadow-sm">
                          <div className="flex items-center justify-between mb-2">
                            <div className="p-2 bg-slate-50 rounded-lg">
                              <Cpu size={18} className="text-slate-600" />
                            </div>
                            <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded uppercase">
                              {device.status}
                            </span>
                          </div>
                          <p className="font-bold text-slate-900 text-sm">{device.name}</p>
                          <p className="text-xs text-slate-400 mt-1">IP: {device.ip}</p>
                          <div className="mt-3 pt-3 border-t border-slate-50 flex justify-between items-center">
                            <span className="text-[10px] text-slate-500 uppercase font-bold">{device.type}</span>
                            <button className="text-[10px] font-bold text-blue-600 hover:underline">Configure</button>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="p-12 border-2 border-dashed border-slate-200 rounded-3xl text-center space-y-4">
                      <Cpu size={48} className="mx-auto text-slate-300" />
                      <div className="space-y-1">
                        <p className="font-bold text-slate-900">No devices connected</p>
                        <p className="text-sm text-slate-500">Scan your network to find compatible equipment.</p>
                      </div>
                      <button 
                        onClick={scanNetwork} 
                        disabled={isScanning}
                        className="btn-primary"
                      >
                        {isScanning ? 'Scanning Network...' : 'Scan Network for Equipment'}
                      </button>
                    </div>
                  )}
                </div>

                <div className="p-4 bg-blue-50 rounded-2xl border border-blue-100">
                  <div className="flex gap-3">
                    <QrCode className="text-blue-600 shrink-0" size={20} />
                    <div>
                      <p className="text-sm font-bold text-blue-900">Sample Data for Scanning</p>
                      <p className="text-xs text-blue-700 mt-1">Use these strings to simulate QR/Barcode scans in the weighing module:</p>
                      <div className="mt-2 grid grid-cols-2 gap-2">
                        <div className="bg-white/50 p-2 rounded border border-blue-200">
                          <p className="text-[10px] font-bold text-blue-800 uppercase">Material Lot</p>
                          <code className="text-[10px] block mt-1">LOT-PARA-2026-001</code>
                        </div>
                        <div className="bg-white/50 p-2 rounded border border-blue-200">
                          <p className="text-[10px] font-bold text-blue-800 uppercase">Equipment ID</p>
                          <code className="text-[10px] block mt-1">EQ-MIX-04-A</code>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeSubTab === 'activity' && (
              <div className="space-y-6">
                <h3 className="text-xl font-bold">Recent System Activity</h3>
                <div className="space-y-4">
                  {(recentActivity || []).map(log => (
                    <div key={log.id} className="flex gap-4 p-3 hover:bg-slate-50 rounded-xl transition-colors">
                      <div className="w-10 h-10 bg-slate-100 rounded-full flex items-center justify-center shrink-0">
                        <Activity size={18} className="text-slate-500" />
                      </div>
                      <div>
                        <p className="text-sm font-medium text-slate-800">{log.details}</p>
                        <p className="text-xs text-slate-400 mt-1">
                          {log.user_name} ({log.user_role}) • {new Date(log.timestamp).toLocaleString()}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </motion.div>
    </div>
    )}
  </AnimatePresence>
);
};

const WeighingDispensing = ({ user }: { user: User }) => {
  const [materials, setMaterials] = useState<Material[]>([]);
  const [selectedMaterial, setSelectedMaterial] = useState<Material | null>(null);
  const [sessions, setSessions] = useState<WeighingSession[]>([]);
  const [liveWeight, setLiveWeight] = useState({ gross: 0, tare: 0, net: 0 });
  const [isWeighing, setIsWeighing] = useState(false);
  const socketRef = useRef<Socket | null>(null);

  useEffect(() => {
    // Only fetch materials once on mount
    api.get('/inventory').then(res => res.data).then(data => setMaterials(data.materials));
    
    socketRef.current = io();
    socketRef.current.on('connect_error', (err) => {
      // Ignore connection errors to prevent them from bubbling up to the global handler
      console.warn('Socket connection error:', err.message);
    });
    
    return () => { socketRef.current?.disconnect(); };
  }, []);

  useEffect(() => {
    if (!socketRef.current) return;

    const handleUpdate = (data: any) => {
      if (data.materialId === selectedMaterial?.id) {
        setLiveWeight({ gross: data.gross, tare: data.tare, net: data.net });
      }
    };

    socketRef.current.on('live-weighing', handleUpdate);
    return () => { socketRef.current?.off('live-weighing', handleUpdate); };
  }, [selectedMaterial]);

  const handleWeigh = () => {
    if (!selectedMaterial) return;
    setIsWeighing(true);
    // Simulate scale communication
    let g = 0;
    const interval = setInterval(() => {
      g += Math.random() * 5;
      const n = Math.max(0, g - liveWeight.tare);
      const update = { instanceId: 0, materialId: selectedMaterial.id, gross: g, tare: liveWeight.tare, net: n, status: 'In Progress' };
      setLiveWeight({ gross: g, tare: liveWeight.tare, net: n });
      socketRef.current?.emit('weighing-update', update);
      if (g >= 100) {
        clearInterval(interval);
        setIsWeighing(false);
        saveSession(g, liveWeight.tare, n);
      }
    }, 500);
  };

  const saveSession = async (g: number, t: number, n: number) => {
    await api.post('/weighing', {
      instanceId: 0,
      materialId: selectedMaterial?.id,
      targetWeight: 100,
      grossWeight: g,
      tareWeight: t,
      netWeight: n,
      status: 'Completed',
      userId: user.id,
      userRole: user.role
    });
    toast.success('Weighing session completed and recorded.');
  };

  return (
    <div className="space-y-8">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Weighing & Dispensing</h1>
          <p className="text-slate-500">Live material weighing with direct scale integration.</p>
        </div>
        <div className="flex items-center gap-2 bg-emerald-50 text-emerald-700 px-4 py-2 rounded-full text-sm font-bold">
          <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
          Scale Connected: Mettler Toledo ICS425
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-1 space-y-6">
          <div className="glass-panel p-6">
            <h3 className="text-sm font-bold text-slate-500 uppercase mb-4">Select Material</h3>
            <div className="space-y-2">
              {(materials || []).map(m => (
                <button
                  key={m.id}
                  onClick={() => setSelectedMaterial(m)}
                  className={cn("w-full text-left p-4 rounded-2xl border transition-all",
                    selectedMaterial?.id === m.id ? "bg-pharma-primary text-white border-pharma-primary shadow-lg" : "bg-white text-slate-700 border-slate-100 hover:border-pharma-accent")}
                >
                  <p className="font-bold">{m.name}</p>
                  <p className="text-xs opacity-60">SKU: {m.sku} | Available: {m.quantity} {m.unit}</p>
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="lg:col-span-2 space-y-6">
          <div className="glass-panel p-8 flex flex-col items-center justify-center space-y-8 min-h-[400px]">
            {!selectedMaterial ? (
              <div className="text-center space-y-4">
                <Scale size={64} className="mx-auto text-slate-200" />
                <p className="text-slate-400">Select a material to start weighing</p>
              </div>
            ) : (
              <>
                <div className="text-center">
                  <h2 className="text-4xl font-black text-slate-900 font-mono tracking-tighter">
                    {liveWeight.net.toFixed(3)} <span className="text-xl text-slate-400">{selectedMaterial.unit}</span>
                  </h2>
                  <p className="text-sm font-bold text-emerald-500 uppercase tracking-widest mt-2">Net Weight</p>
                </div>

                <div className="grid grid-cols-2 gap-8 w-full max-w-md">
                  <div className="text-center p-4 bg-slate-50 rounded-2xl">
                    <p className="text-2xl font-bold text-slate-700 font-mono">{liveWeight.gross.toFixed(3)}</p>
                    <p className="text-[10px] font-bold text-slate-400 uppercase">Gross</p>
                  </div>
                  <div className="text-center p-4 bg-slate-50 rounded-2xl">
                    <p className="text-2xl font-bold text-slate-700 font-mono">{liveWeight.tare.toFixed(3)}</p>
                    <p className="text-[10px] font-bold text-slate-400 uppercase">Tare</p>
                  </div>
                </div>

                <div className="flex gap-4 w-full max-w-md">
                  <button 
                    onClick={() => setLiveWeight(prev => ({ ...prev, tare: prev.gross, net: 0 }))}
                    className="btn-secondary flex-1 py-4"
                  >
                    Tare Scale
                  </button>
                  <button 
                    onClick={handleWeigh}
                    disabled={isWeighing}
                    className="btn-primary flex-1 py-4 flex items-center justify-center gap-2"
                  >
                    {isWeighing ? <RotateCcw className="animate-spin" size={20} /> : <Scale size={20} />}
                    {isWeighing ? 'Weighing...' : 'Start Weighing'}
                  </button>
                </div>
              </>
            )}
          </div>

          <div className="glass-panel p-6">
            <h3 className="text-sm font-bold text-slate-500 uppercase mb-6">Live Weighing Analytics</h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={[{ t: 0, w: 0 }, { t: 1, w: 20 }, { t: 2, w: 45 }, { t: 3, w: 80 }, { t: 4, w: 100 }]}>
                  <defs>
                    <linearGradient id="colorWeight" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="t" hide />
                  <YAxis fontSize={10} />
                  <Tooltip />
                  <Area type="monotone" dataKey="w" stroke="#3b82f6" fillOpacity={1} fill="url(#colorWeight)" strokeWidth={3} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
            <div className="grid grid-cols-3 gap-4 mt-6">
              <div className="text-center">
                <p className="text-lg font-bold text-emerald-600">85%</p>
                <p className="text-[10px] text-slate-400 uppercase">Material Used</p>
              </div>
              <div className="text-center">
                <p className="text-lg font-bold text-blue-600">12%</p>
                <p className="text-[10px] text-slate-400 uppercase">Manufactured</p>
              </div>
              <div className="text-center">
                <p className="text-lg font-bold text-red-600">3%</p>
                <p className="text-[10px] text-slate-400 uppercase">Waste</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const FinancialDashboard = () => {
  const [data, setData] = useState<any>(null);

  useEffect(() => {
    api.get('/financials').then(res => res.data).then(setData);
  }, []);

  if (!data) return null;

  return (
    <div className="space-y-8">
      <header>
        <h1 className="text-3xl font-bold text-slate-900">Cost & Yield Analysis</h1>
        <p className="text-slate-500">Advanced financial tracking and material efficiency metrics.</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="glass-panel p-6 border-l-4 border-l-blue-500">
          <p className="text-xs font-bold text-slate-400 uppercase">Total Material Spend</p>
          <p className="text-3xl font-bold text-slate-900 mt-1">${data?.summary?.total_spent?.toLocaleString() || '0'}</p>
          <div className="flex items-center gap-1 text-emerald-500 text-xs mt-2">
            <TrendingUp size={14} /> <span>8.2% vs last quarter</span>
          </div>
        </div>
        <div className="glass-panel p-6 border-l-4 border-l-emerald-500">
          <p className="text-xs font-bold text-slate-400 uppercase">Total Revenue Generated</p>
          <p className="text-3xl font-bold text-slate-900 mt-1">${data?.summary?.total_revenue?.toLocaleString() || '0'}</p>
          <div className="flex items-center gap-1 text-emerald-500 text-xs mt-2">
            <TrendingUp size={14} /> <span>15.4% growth</span>
          </div>
        </div>
        <div className="glass-panel p-6 border-l-4 border-l-red-500">
          <p className="text-xs font-bold text-slate-400 uppercase">Material Waste Cost</p>
          <p className="text-3xl font-bold text-slate-900 mt-1">${data?.summary?.total_waste?.toLocaleString() || '0'}</p>
          <div className="flex items-center gap-1 text-red-500 text-xs mt-2">
            <AlertCircle size={14} /> <span>2.1% of total production</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="glass-panel p-6">
          <h3 className="text-sm font-bold text-slate-500 uppercase mb-6">Revenue vs Waste Trend</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={[
                { name: 'Jan', rev: 4000, waste: 400 },
                { name: 'Feb', rev: 3000, waste: 300 },
                { name: 'Mar', rev: 2000, waste: 500 },
                { name: 'Apr', rev: 2780, waste: 390 },
                { name: 'May', rev: 1890, waste: 480 },
                { name: 'Jun', rev: 2390, waste: 380 },
              ]}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" fontSize={10} />
                <YAxis fontSize={10} />
                <Tooltip />
                <Area type="monotone" dataKey="rev" stackId="1" stroke="#10b981" fill="#10b981" fillOpacity={0.1} />
                <Area type="monotone" dataKey="waste" stackId="1" stroke="#ef4444" fill="#ef4444" fillOpacity={0.1} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="glass-panel p-6">
          <h3 className="text-sm font-bold text-slate-500 uppercase mb-6">Recent Financial Transactions</h3>
          <div className="space-y-4">
            {(data?.transactions || []).slice(0, 6).map((t: any) => (
              <div key={t.id} className="flex items-center justify-between p-3 hover:bg-slate-50 rounded-xl transition-colors">
                <div className="flex items-center gap-3">
                  <div className={cn("w-10 h-10 rounded-full flex items-center justify-center", 
                    t.type === 'Sale' ? "bg-emerald-100 text-emerald-600" : "bg-red-100 text-red-600")}>
                    {t.type === 'Sale' ? <DollarSign size={18} /> : <ShoppingCart size={18} />}
                  </div>
                  <div>
                    <p className="text-sm font-bold text-slate-800">{t.description}</p>
                    <p className="text-xs text-slate-400">{new Date(t.timestamp).toLocaleDateString()}</p>
                  </div>
                </div>
                <p className={cn("font-bold", t.type === 'Sale' ? "text-emerald-600" : "text-red-600")}>
                  {t.type === 'Sale' ? '+' : '-'}${t.amount?.toLocaleString() || '0'}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

const Dashboard = ({ user, onStartWorkflow, setActiveTab }: { user: User, onStartWorkflow: (id: number, bn: string, pn: string, sa?: string) => void, setActiveTab: (t: string) => void }) => {
  const [stats, setStats] = useState<Stats | null>(null);
  const [workflows, setWorkflows] = useState<Workflow[]>([]);
  const [recentLogs, setRecentLogs] = useState<AuditLog[]>([]);
  const [showStartModal, setShowStartModal] = useState<number | null>(null);
  const [batchNumber, setBatchNumber] = useState('');
  const [productName, setProductName] = useState('');
  const [scheduledAt, setScheduledAt] = useState('');

  useEffect(() => {
    api.get('/stats').then(res => res.data).then(setStats);
    api.get('/workflows').then(res => res.data).then(setWorkflows);
    api.get('/audit').then(res => res.data).then(data => setRecentLogs(Array.isArray(data.data) ? data.data.slice(0, 5) : []));
  }, []);

  return (
    <div className="space-y-8">
      <header>
        <h1 className="text-3xl font-bold text-slate-900">Welcome back, {user.full_name.split(' ')[0]}</h1>
        <p className="text-slate-500">System status and pending activities for today.</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { label: 'Inventory Health', value: '94%', icon: Package, color: 'text-blue-600', bg: 'bg-blue-50', tab: 'inventory' },
          { label: 'Active Batches', value: stats?.activeInstances || 0, icon: Activity, color: 'text-amber-600', bg: 'bg-amber-50', tab: 'instances' },
          { label: 'Production Yield', value: '98.2%', icon: TrendingUp, color: 'text-emerald-600', bg: 'bg-emerald-50', tab: 'reports' },
          { label: 'Pending Dispatch', value: '12', icon: Truck, color: 'text-purple-600', bg: 'bg-purple-50', tab: 'supply-chain' },
        ].map((stat, i) => (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            key={stat.label} 
            onClick={() => setActiveTab(stat.tab)}
            className="glass-panel p-6 cursor-pointer hover:shadow-md transition-all hover:border-pharma-accent/30 group"
          >
            <div className={`w-12 h-12 ${stat.bg} ${stat.color} rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
              <stat.icon size={24} />
            </div>
            <p className="text-slate-500 text-sm font-medium">{stat.label}</p>
            <p className="text-3xl font-bold text-slate-900 mt-1">{stat.value}</p>
          </motion.div>
        ))}
      </div>

      <DashboardCharts setActiveTab={setActiveTab} />

        <div className="space-y-6">
          <div className="glass-panel p-6">
            <h2 className="text-xl font-bold mb-6">Available Workflows</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {(Array.isArray(workflows) ? workflows : []).map((wf) => (
                <div key={wf.id} className="p-4 border border-slate-100 rounded-xl hover:border-pharma-accent/30 hover:bg-pharma-accent/5 transition-all group">
                  <h3 className="font-bold text-slate-800">{wf.name}</h3>
                  <p className="text-sm text-slate-500 mt-1 line-clamp-2">{wf.description}</p>
                  <button 
                    onClick={() => {
                      setShowStartModal(wf.id);
                      setProductName(wf.name);
                      setBatchNumber(`BN-${Date.now().toString().slice(-6)}`);
                    }}
                    className="mt-4 flex items-center gap-2 text-pharma-accent text-sm font-bold group-hover:gap-3 transition-all"
                  >
                    Start Execution <ArrowRight size={16} />
                    <HelpTooltip text="Initiate a new production instance of this workflow." guideLink="instances" />
                  </button>
                </div>
              ))}
              {(workflows || []).length === 0 && (
                <div className="col-span-2 py-12 text-center text-slate-400">
                  <FileText className="mx-auto mb-2 opacity-20" size={48} />
                  <p>No workflows defined yet.</p>
                </div>
              )}
            </div>
          </div>
        </div>

      <AnimatePresence>
        {showStartModal && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[100] flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="glass-panel p-8 max-w-md w-full space-y-6"
            >
              <h2 className="text-2xl font-bold">Start Batch Record</h2>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-1">Batch Number</label>
                  <input 
                    value={batchNumber}
                    onChange={e => setBatchNumber(e.target.value)}
                    className="input-field" 
                  />
                </div>
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-1">Product Name</label>
                  <input 
                    value={productName}
                    onChange={e => setProductName(e.target.value)}
                    className="input-field" 
                  />
                </div>
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-1">Schedule Date (Optional)</label>
                  <input 
                    type="datetime-local"
                    value={scheduledAt}
                    onChange={e => setScheduledAt(e.target.value)}
                    className="input-field" 
                  />
                  <p className="text-[10px] text-slate-400 mt-1 italic">Leave empty to start execution immediately.</p>
                </div>
              </div>
              <div className="flex gap-4">
                <button onClick={() => setShowStartModal(null)} className="btn-secondary flex-1">Cancel</button>
                <button 
                  onClick={() => {
                    onStartWorkflow(showStartModal, batchNumber, productName, scheduledAt || undefined);
                    setShowStartModal(null);
                    setScheduledAt('');
                  }} 
                  className="btn-primary flex-1"
                >
                  {scheduledAt ? 'Schedule' : 'Start'}
                  <HelpTooltip text={scheduledAt ? "Schedule this batch for the selected date and time." : "Start this batch immediately."} guideLink="scheduling" />
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

// --- Table Configurator ---

const TableConfigurator = ({ config, onChange, disabled }: { config: any, onChange: (c: any) => void, disabled?: boolean }) => {
  const [rows, setRows] = useState(config?.rows || 3);
  const [cols, setCols] = useState(config?.cols || 3);
  const [cells, setCells] = useState<any>(config?.cells || {});
  const [selectedCell, setSelectedCell] = useState<string | null>(null);

  useEffect(() => {
    onChange({ rows, cols, cells });
  }, [rows, cols, cells]);

  const updateCell = (r: number, c: number, updates: any) => {
    if (disabled) return;
    const key = `${r}-${c}`;
    setCells({
      ...cells,
      [key]: { ...(cells[key] || {}), ...updates }
    });
  };

  const addRow = () => { if (!disabled) setRows(rows + 1); };
  const removeRow = () => { if (!disabled && rows > 1) setRows(rows - 1); };
  const addCol = () => { if (!disabled) setCols(cols + 1); };
  const removeCol = () => { if (!disabled && cols > 1) setCols(cols - 1); };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-2">
        <button onClick={addRow} disabled={disabled} className="btn-secondary text-xs px-2 py-1 flex items-center gap-1"><Plus size={14} /> Row</button>
        <button onClick={removeRow} disabled={disabled} className="btn-secondary text-xs px-2 py-1 flex items-center gap-1 text-red-500"><Minus size={14} /> Row</button>
        <button onClick={addCol} disabled={disabled} className="btn-secondary text-xs px-2 py-1 flex items-center gap-1"><Plus size={14} /> Col</button>
        <button onClick={removeCol} disabled={disabled} className="btn-secondary text-xs px-2 py-1 flex items-center gap-1 text-red-500"><Minus size={14} /> Col</button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 overflow-x-auto">
          <table className="border-collapse border border-slate-300 w-full min-w-[400px]">
            <tbody>
              {Array.from({ length: rows }).map((_, ri) => (
                <tr key={ri}>
                  {Array.from({ length: cols }).map((_, ci) => {
                    const key = `${ri}-${ci}`;
                    const cell = cells[key] || {};
                    if (cell.isMerged) return null;
                    return (
                      <td 
                        key={ci} 
                        rowSpan={cell.rowSpan || 1}
                        colSpan={cell.colSpan || 1}
                        onClick={() => setSelectedCell(key)}
                        style={{ backgroundColor: cell.color || 'transparent' }}
                        className={`border border-slate-300 p-2 min-w-[80px] h-12 cursor-pointer transition-all hover:ring-2 hover:ring-pharma-accent/50 relative ${selectedCell === key ? 'ring-2 ring-pharma-accent bg-pharma-accent/5' : ''}`}
                      >
                        <div className="text-[10px] font-bold text-slate-400 absolute top-0.5 left-1 uppercase">
                          {String.fromCharCode(65 + ci)}{ri + 1}
                        </div>
                        <div className="text-xs text-center truncate mt-2">
                          {cell.value || (cell.formula ? 'fx' : '')}
                        </div>
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="glass-panel p-4 space-y-4 bg-slate-50/50">
          <h4 className="text-sm font-bold flex items-center gap-2">
            <Settings size={16} /> Cell Properties {selectedCell && `(${String.fromCharCode(65 + parseInt(selectedCell.split('-')[1]))}${parseInt(selectedCell.split('-')[0]) + 1})`}
          </h4>
          
          {selectedCell ? (
            <div className="space-y-3">
              <div>
                <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Cell Label/Value</label>
                <input 
                  disabled={disabled}
                  value={cells[selectedCell]?.value || ''}
                  onChange={e => updateCell(parseInt(selectedCell.split('-')[0]), parseInt(selectedCell.split('-')[1]), { value: e.target.value })}
                  className="input-field text-xs"
                  placeholder="e.g., Total Weight"
                />
              </div>
              <div>
                <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Formula (Excel style)</label>
                <input 
                  disabled={disabled}
                  value={cells[selectedCell]?.formula || ''}
                  onChange={e => updateCell(parseInt(selectedCell.split('-')[0]), parseInt(selectedCell.split('-')[1]), { formula: e.target.value })}
                  className="input-field text-xs font-mono"
                  placeholder="e.g., =A1 + B1"
                />
                <p className="text-[9px] text-slate-400 mt-1 italic">Use A1, B2 etc. to reference cells in this table.</p>
              </div>
              <div>
                <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Background Color</label>
                <div className="flex flex-wrap gap-1">
                  {['', '#f8fafc', '#f1f5f9', '#e2e8f0', '#fee2e2', '#fef3c7', '#ecfdf5', '#eff6ff', '#faf5ff'].map(c => (
                    <button 
                      key={c}
                      onClick={() => updateCell(parseInt(selectedCell.split('-')[0]), parseInt(selectedCell.split('-')[1]), { color: c })}
                      className={`w-6 h-6 rounded border border-slate-200 ${cells[selectedCell]?.color === c ? 'ring-2 ring-pharma-accent' : ''}`}
                      style={{ backgroundColor: c || '#fff' }}
                    />
                  ))}
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Col Span</label>
                  <input 
                    type="number"
                    min="1"
                    disabled={disabled}
                    value={cells[selectedCell]?.colSpan || 1}
                    onChange={e => updateCell(parseInt(selectedCell.split('-')[0]), parseInt(selectedCell.split('-')[1]), { colSpan: parseInt(e.target.value) })}
                    className="input-field text-xs"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Row Span</label>
                  <input 
                    type="number"
                    min="1"
                    disabled={disabled}
                    value={cells[selectedCell]?.rowSpan || 1}
                    onChange={e => updateCell(parseInt(selectedCell.split('-')[0]), parseInt(selectedCell.split('-')[1]), { rowSpan: parseInt(e.target.value) })}
                    className="input-field text-xs"
                  />
                </div>
              </div>
              <p className="text-[10px] text-slate-400 italic">Note: Merging cells is visual. Ensure you don't overlap important data.</p>
            </div>
          ) : (
            <div className="text-center py-8 text-slate-400 text-xs">
              Select a cell to configure properties
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const FieldEditor = ({ field, onChange, onDelete, disabled }: any) => {
  return (
    <div className="p-4 bg-white border border-slate-200 rounded-xl space-y-3 relative group/field shadow-sm">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        <div>
          <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Field Name / Label</label>
          <input 
            value={field.name}
            onChange={e => onChange({ ...field, name: e.target.value, config: { ...field.config, label: e.target.value } })}
            className="input-field py-1.5 text-sm" 
            placeholder="e.g. Temperature" 
            disabled={disabled}
          />
        </div>
        <div>
          <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1 flex items-center gap-1">
            Variable ID <span className="text-[8px] lowercase font-normal">(for formulas)</span>
          </label>
          <input 
            value={field.variableName || ''}
            onChange={e => onChange({ ...field, variableName: e.target.value.replace(/[^a-zA-Z0-9_]/g, '') })}
            className="input-field py-1.5 text-sm font-mono" 
            placeholder="e.g. temp_1" 
            disabled={disabled}
          />
        </div>
        <div>
          <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Field Type</label>
          <select 
            value={field.type}
            onChange={e => onChange({ ...field, type: e.target.value })}
            className="input-field py-1.5 text-sm"
            disabled={disabled}
          >
            <option value="text">Text Input</option>
            <option value="number">Numeric Value</option>
            <option value="date">Date/Time</option>
            <option value="dropdown">Dropdown</option>
            <option value="file">File Upload</option>
            <option value="comment">Comment Box</option>
            <option value="calculation">Calculation</option>
            <option value="table">Data Table</option>
          </select>
        </div>

        <div>
          <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Layout Width</label>
          <select 
            value={field.config?.width || 'full'}
            onChange={e => onChange({ ...field, config: { ...field.config, width: e.target.value } })}
            className="input-field py-1.5 text-sm"
            disabled={disabled}
          >
            <option value="full">Full Width (100%)</option>
            <option value="half">Half Width (50%)</option>
            <option value="third">Third Width (33%)</option>
          </select>
        </div>

        {field.type === 'dropdown' && (
          <div className="md:col-span-3">
            <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Options (comma separated)</label>
            <input 
              value={field.config?.options?.join(', ') || ''}
              onChange={e => onChange({ ...field, config: { ...field.config, options: e.target.value.split(',').map(s => s.trim()) } })}
              className="input-field py-1.5 text-sm" 
              placeholder="Option 1, Option 2" 
              disabled={disabled}
            />
          </div>
        )}

        {field.type === 'calculation' && (
          <div className="md:col-span-3">
            <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Formula</label>
            <input 
              value={field.config?.formula || ''}
              onChange={e => onChange({ ...field, config: { ...field.config, formula: e.target.value } })}
              className="input-field py-1.5 text-sm" 
              placeholder="e.g. {{temp_1}} * 2" 
              disabled={disabled}
            />
            <p className="text-[9px] text-slate-400 mt-1">Use variable IDs in double curly braces: {"{{variable_id}}"}</p>
          </div>
        )}

        {field.type === 'table' && (
          <div className="md:col-span-3">
            <TableConfigurator 
              config={field.config?.tableConfig} 
              onChange={(tc) => onChange({ ...field, config: { ...field.config, tableConfig: tc } })}
              disabled={disabled}
            />
          </div>
        )}
      </div>
      {!disabled && (
        <button 
          onClick={onDelete}
          className="absolute -right-2 -top-2 w-6 h-6 bg-white border border-slate-200 text-red-500 rounded-full flex items-center justify-center opacity-0 group-hover/field:opacity-100 transition-all hover:bg-red-50 shadow-sm"
        >
          <X size={12} />
        </button>
      )}
    </div>
  );
};

const SortableField = ({ field, onChange, onDelete, disabled }: any) => {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
  } = useSortable({ id: field.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  return (
    <div ref={setNodeRef} style={style} {...attributes} className="relative group">
      <div 
        {...listeners} 
        className="absolute left-2 top-1/2 -translate-y-1/2 p-1 text-slate-300 hover:text-slate-500 cursor-grab active:cursor-grabbing opacity-0 group-hover:opacity-100 transition-opacity z-10"
      >
        <Menu size={14} />
      </div>
      <div className="pl-8">
        <FieldEditor 
          field={field}
          onChange={onChange}
          onDelete={onDelete}
          disabled={disabled}
        />
      </div>
    </div>
  );
};

const WorkflowBuilder = ({ user }: { user: User }) => {
  const [workflows, setWorkflows] = useState<(Workflow & { instance_count?: number })[]>([]);
  const [view, setView] = useState<'list' | 'editor'>('list');
  const [activeTab, setActiveTab] = useState<'Draft' | 'Released' | 'Effective' | 'Deleted'>('Draft');
  
  // Editor State
  const [selectedWorkflowId, setSelectedWorkflowId] = useState<number | null>(null);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [status, setStatus] = useState<Workflow['status']>('Draft');
  const [steps, setSteps] = useState<Partial<WorkflowStep>[]>([]);
  const [isSaving, setIsSaving] = useState(false);
  const [isLocked, setIsLocked] = useState(false);
  const [confirmModal, setConfirmModal] = useState<{ isOpen: boolean; onConfirm: () => void; title: string; message: string } | null>(null);

  const saveTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const isInitialLoad = useRef(true);

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  useEffect(() => {
    fetchWorkflows();
  }, [view]);

  const fetchWorkflows = async () => {
    try {
      const res = await api.get('/workflows');
      const data = Array.isArray(res.data) ? res.data : [];
      setWorkflows(data);
    } catch (e) {
      console.error(e);
      setWorkflows([]);
    }
  };

  const loadWorkflow = async (id: number) => {
    try {
      const res = await api.get(`/workflows/${id}`);
      const data = res.data;
      const wf = workflows.find(w => w.id === id);
      setSelectedWorkflowId(id);
      setName(data.name);
      setDescription(data.description || '');
      setStatus(data.status || 'Draft');
      setSteps(data.steps || []);
      setIsLocked((wf?.instance_count || 0) > 0);
      isInitialLoad.current = true; // Reset initial load flag so we don't auto-save immediately after loading
      setView('editor');
    } catch (e) {
      toast.error("Failed to load workflow");
    }
  };

  const handleCreateNew = async () => {
    setIsSaving(true);
    try {
      const res = await api.post('/workflows', { 
        name: 'Untitled Workflow', 
        description: '', 
        status: 'Draft', 
        steps: [], 
        userId: user.id, 
        userRole: user.role 
      });
      await fetchWorkflows();
      loadWorkflow(res.data.id);
    } catch (e) {
      toast.error("Failed to create workflow");
    } finally {
      setIsSaving(false);
    }
  };

  const handleDeleteWorkflow = async (id: number) => {
    try {
      const wf = workflows.find(w => w.id === id);
      if (!wf) return;
      
      const res = await api.post('/workflows', {
        ...wf,
        status: 'Deleted',
        userId: user.id,
        userRole: user.role
      });
      
      if (res.status === 200 || res.status === 201) {
        toast.success("Workflow moved to Deleted");
        fetchWorkflows();
      }
    } catch (e) {
      toast.error("Failed to delete workflow");
    }
  };

  const handleRestoreWorkflow = async (id: number) => {
    try {
      const wf = workflows.find(w => w.id === id);
      if (!wf) return;
      
      const res = await api.post('/workflows', {
        ...wf,
        status: 'Draft',
        userId: user.id,
        userRole: user.role
      });
      
      if (res.status === 200 || res.status === 201) {
        toast.success("Workflow restored to Draft");
        fetchWorkflows();
      }
    } catch (e) {
      toast.error("Failed to restore workflow");
    }
  };

  const triggerAutoSave = (updates: { name?: string, description?: string, status?: Workflow['status'], steps?: Partial<WorkflowStep>[] }) => {
    // This function is now just a placeholder for manual triggers if needed,
    // as we've moved to a useEffect-based debounced save.
  };

  useEffect(() => {
    if (isInitialLoad.current) {
      isInitialLoad.current = false;
      return;
    }
    
    if (!selectedWorkflowId || isLocked) return;

    const payload = {
      id: selectedWorkflowId,
      name,
      description,
      status,
      steps,
      userId: user.id,
      userRole: user.role
    };

    if (saveTimeoutRef.current) clearTimeout(saveTimeoutRef.current);
    
    setIsSaving(true);
    saveTimeoutRef.current = setTimeout(async () => {
      try {
        await api.post('/workflows', payload);
      } catch (e) {
        console.error("Auto-save failed:", e);
        toast.error("Auto-save failed");
      } finally {
        setIsSaving(false);
      }
    }, 1000);

    return () => {
      if (saveTimeoutRef.current) clearTimeout(saveTimeoutRef.current);
    };
  }, [name, description, status, steps, selectedWorkflowId, isLocked]);

  const updateName = (val: string) => { setName(val); };
  const updateDescription = (val: string) => { setDescription(val); };
  const updateStatus = (val: Workflow['status']) => { 
    if (val === 'Released' && user.role !== 'QA Approver' && user.role !== 'Admin') {
      toast.error("Only QA Approvers can release workflows.");
      return;
    }
    setStatus(val); 
  };

  const updateStepsAndSave = (newSteps: Partial<WorkflowStep>[]) => {
    setSteps(newSteps);
  };

  const handleDragEnd = (stepIndex: number, event: any) => {
    const { active, over } = event;
    if (active.id !== over.id) {
      const oldIndex = steps[stepIndex].config?.fields?.findIndex((f: any) => f.id === active.id);
      const newIndex = steps[stepIndex].config?.fields?.findIndex((f: any) => f.id === over.id);
      
      if (oldIndex !== undefined && newIndex !== undefined) {
        const newFields = arrayMove(steps[stepIndex].config?.fields || [], oldIndex, newIndex);
        const newSteps = [...steps];
        newSteps[stepIndex] = { ...newSteps[stepIndex], config: { ...newSteps[stepIndex].config, fields: newFields } };
        updateStepsAndSave(newSteps);
      }
    }
  };

  const resetForm = () => {
    setSelectedWorkflowId(null);
    setName('');
    setDescription('');
    setStatus('Draft');
    setSteps([]);
    setIsLocked(false);
    setView('list');
  };

  const addStep = () => {
    if (isLocked) return;
    updateStepsAndSave([...steps, { 
      name: `Step ${steps.length + 1}`, 
      type: 'multi-field', 
      responsible_role: 'Operator',
      config: { label: '', required: true, reasonMandatory: true, fields: [] }
    }]);
  };

  const addFieldToStep = (stepIndex: number) => {
    if (isLocked) return;
    const newSteps = [...steps];
    const step = newSteps[stepIndex];
    const fields = step.config?.fields || [];
    const newField: WorkflowField = {
      id: `field_${Date.now()}`,
      name: '',
      type: 'text',
      config: { label: '', required: true }
    };
    newSteps[stepIndex] = {
      ...step,
      config: { ...step.config, fields: [...fields, newField] }
    };
    updateStepsAndSave(newSteps);
  };

  const updateFieldInStep = (stepIndex: number, fieldIndex: number, updates: any) => {
    if (isLocked) return;
    const newSteps = [...steps];
    const step = newSteps[stepIndex];
    const fields = [...(step.config?.fields || [])];
    fields[fieldIndex] = { ...fields[fieldIndex], ...updates };
    newSteps[stepIndex] = {
      ...step,
      config: { ...step.config, fields }
    };
    updateStepsAndSave(newSteps);
  };

  const deleteFieldFromStep = (stepIndex: number, fieldIndex: number) => {
    if (isLocked) return;
    const newSteps = [...steps];
    const step = newSteps[stepIndex];
    const fields = (step.config?.fields || []).filter((_, i) => i !== fieldIndex);
    newSteps[stepIndex] = {
      ...step,
      config: { ...step.config, fields }
    };
    updateStepsAndSave(newSteps);
  };

  const updateStep = (index: number, updates: any) => {
    if (isLocked) return;
    const newSteps = [...steps];
    newSteps[index] = { ...newSteps[index], ...updates };
    updateStepsAndSave(newSteps);
  };

  const [isGeneratingAI, setIsGeneratingAI] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleAIGenerate = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsGeneratingAI(true);
    
    try {
      const apiKey = process.env.GEMINI_API_KEY || process.env.API_KEY;
      if (!apiKey) {
        toast.error("Gemini API key is not configured.");
        setIsGeneratingAI(false);
        return;
      }

      // Create a fresh instance to ensure we use the latest key
      const ai = new GoogleGenAI({ apiKey });
      
      // Convert file to base64
      const reader = new FileReader();
      const base64Promise = new Promise<string>((resolve, reject) => {
        reader.onload = () => {
          const base64 = (reader.result as string).split(',')[1];
          resolve(base64);
        };
        reader.onerror = reject;
      });
      reader.readAsDataURL(file);
      const base64Data = await base64Promise;

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: [
          {
            inlineData: {
              data: base64Data,
              mimeType: file.type
            }
          },
          { text: "Convert this document into a structured workflow. Extract the title, description, and a sequence of steps. For each step, identify the name (MANDATORY, do not leave empty), type (e.g., 'text', 'number', 'date', 'dropdown', 'file', 'comment', 'calculation', 'table', 'multi-field'), the responsible role (e.g., 'Operator', 'Reviewer', 'QA Approver'), and any specific configuration like required fields or labels. Also provide a confidence score (High, Medium, Low) and a source reference (e.g., 'Page 1, Section 2') for each step. If a step requires multiple inputs, use the 'multi-field' type and define the sub-fields in the config. Ensure every step has a non-empty name." }
        ],
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING },
              description: { type: Type.STRING },
              confidence_overall: { type: Type.STRING, description: "High, Medium, or Low" },
              steps: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    id: { type: Type.STRING, description: "A unique string ID for the step" },
                    name: { type: Type.STRING },
                    type: { type: Type.STRING, description: "Must be one of: text, number, date, dropdown, file, comment, calculation, table, multi-field" },
                    responsible_role: { type: Type.STRING },
                    confidence: { type: Type.STRING, description: "High, Medium, or Low" },
                    source_reference: { type: Type.STRING },
                    is_inferred: { type: Type.BOOLEAN },
                    config: {
                      type: Type.OBJECT,
                      properties: {
                        label: { type: Type.STRING },
                        required: { type: Type.BOOLEAN },
                        fields: {
                          type: Type.ARRAY,
                          items: {
                            type: Type.OBJECT,
                            properties: {
                              id: { type: Type.STRING },
                              name: { type: Type.STRING },
                              type: { type: Type.STRING },
                              config: {
                                type: Type.OBJECT,
                                properties: {
                                  label: { type: Type.STRING },
                                  required: { type: Type.BOOLEAN }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  },
                  required: ["id", "name", "type", "responsible_role"]
                }
              }
            },
            required: ["name", "description", "steps"]
          }
        }
      });

      const text = response.text || '{}';
      const cleanText = text.replace(/```json\n?|```/g, '').trim();
      const generated = JSON.parse(cleanText);

      // Ensure all steps have names to avoid validation errors
      if (generated.steps && Array.isArray(generated.steps)) {
        generated.steps = generated.steps.map((step: any, idx: number) => ({
          ...step,
          name: step.name || `Step ${idx + 1}`
        }));
      }
      
      // Create a new draft workflow with the generated data
      const createRes = await api.post('/workflows', {
        name: generated.name || 'AI Generated Workflow',
        description: generated.description || 'Generated from document',
        status: 'Draft',
        steps: generated.steps || []
      });
      
      toast.success('AI workflow generated and saved to Drafts');
      await fetchWorkflows();
      await loadWorkflow(createRes.data.id);
    } catch (err) {
      console.error(err);
      toast.error('Failed to generate workflow from document');
    } finally {
      setIsGeneratingAI(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  if (view === 'list') {
    const filteredWorkflows = workflows.filter(wf => wf.status === activeTab);
    
    return (
      <div className="max-w-6xl mx-auto space-y-8">
        <header className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-slate-900">Workflows</h1>
            <p className="text-slate-500">Manage and design your manufacturing processes.</p>
          </div>
          <div className="flex gap-3">
            <input 
              type="file" 
              ref={fileInputRef} 
              onChange={handleAIGenerate} 
              className="hidden" 
              accept=".pdf,.docx,.doc,.txt,.png,.jpg,.jpeg"
            />
            <button 
              onClick={() => fileInputRef.current?.click()} 
              disabled={isGeneratingAI || isSaving} 
              className="btn-secondary flex items-center gap-2 bg-purple-50 text-purple-700 border-purple-200 hover:bg-purple-100 shadow-sm hover:shadow-md transition-all group"
            >
              {isGeneratingAI ? <RefreshCw className="animate-spin" size={20} /> : <Sparkles size={20} className="group-hover:scale-110 transition-transform" />}
              AI Generate Workflow
              <HelpTooltip text="Use AI to automatically generate a workflow based on a PDF or text description of your process." guideLink="ai" />
            </button>
            <button 
              onClick={handleCreateNew} 
              disabled={isSaving || isGeneratingAI} 
              className="btn-primary flex items-center gap-2 shadow-lg shadow-pharma-primary/20 hover:shadow-pharma-primary/30 transition-all active:scale-95"
            >
              <Plus size={20} /> Create Workflow
              <HelpTooltip text="Create a new digital Master Batch Record (MBR) workflow with custom steps and validation rules." guideLink="ebr" />
            </button>
          </div>
        </header>

        <div className="glass-panel overflow-hidden">
          <div className="flex border-b border-slate-200">
            {['Draft', 'Released', 'Effective', 'Deleted'].map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab as any)}
                className={`flex-1 py-4 text-sm font-bold uppercase tracking-wider transition-colors ${
                  activeTab === tab 
                    ? 'text-pharma-primary border-b-2 border-pharma-primary bg-blue-50/50' 
                    : 'text-slate-500 hover:bg-slate-50 hover:text-slate-700'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>
          
          <div className="p-0">
            {filteredWorkflows.length === 0 ? (
              <div className="text-center py-16 text-slate-500">
                <p className="text-lg font-medium mb-2">No {activeTab.toLowerCase()} workflows found.</p>
                {activeTab === 'Draft' && (
                  <button onClick={handleCreateNew} className="text-pharma-primary hover:underline font-bold">
                    Create your first workflow
                  </button>
                )}
              </div>
            ) : (
              <div className="divide-y divide-slate-100">
                {filteredWorkflows.map(wf => (
                  <div key={wf.id} className="p-6 hover:bg-slate-50 transition-colors flex flex-col md:flex-row md:items-center justify-between group">
                    <div>
                      <h3 className="text-lg font-bold text-slate-900 mb-1">{wf.name}</h3>
                      <p className="text-slate-500 text-sm line-clamp-1 max-w-2xl">{wf.description || 'No description provided.'}</p>
                      <div className="flex items-center gap-4 mt-3 text-xs font-medium text-slate-400">
                        <span className="flex items-center gap-1"><Clock size={14} /> Updated {new Date(wf.updated_at || wf.created_at).toLocaleDateString()}</span>
                        {wf.instance_count !== undefined && (
                          <span className="flex items-center gap-1"><Activity size={14} /> {wf.instance_count} instances</span>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-3 opacity-100 md:opacity-0 md:group-hover:opacity-100 transition-opacity mt-4 md:mt-0">
                      <button 
                        onClick={() => loadWorkflow(wf.id)}
                        className="btn-secondary flex items-center gap-2 text-sm py-2"
                      >
                        <Edit2 size={16} /> Edit
                      </button>
                      {activeTab !== 'Deleted' ? (
                        <button 
                          onClick={() => setConfirmModal({
                            isOpen: true,
                            title: 'Delete Workflow',
                            message: `Are you sure you want to delete "${wf.name}"? It will be moved to the Deleted tab.`,
                            onConfirm: () => handleDeleteWorkflow(wf.id)
                          })}
                          className="btn-secondary flex items-center gap-2 text-sm py-2 text-red-600 hover:bg-red-50 hover:border-red-200"
                        >
                          <Trash2 size={16} /> Delete
                        </button>
                      ) : (
                        <button 
                          onClick={() => setConfirmModal({
                            isOpen: true,
                            title: 'Restore Workflow',
                            message: `Are you sure you want to restore "${wf.name}" to Draft?`,
                            onConfirm: () => handleRestoreWorkflow(wf.id)
                          })}
                          className="btn-secondary flex items-center gap-2 text-sm py-2 text-blue-600 hover:bg-blue-50 hover:border-blue-200"
                        >
                          <RefreshCw size={16} /> Restore
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <header className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button onClick={resetForm} className="p-2 hover:bg-slate-100 rounded-full transition-colors text-slate-500">
            <ArrowLeft size={24} />
          </button>
          <div>
            <h1 className="text-3xl font-bold text-slate-900">{name || 'Untitled Workflow'}</h1>
            <p className="text-slate-500 flex items-center gap-2">
              <span className={`px-2 py-0.5 rounded-full text-xs font-bold ${
                status === 'Draft' ? 'bg-slate-100 text-slate-600' :
                status === 'Released' ? 'bg-blue-100 text-blue-700' :
                status === 'Effective' ? 'bg-green-100 text-green-700' :
                'bg-red-100 text-red-700'
              }`}>
                {status}
              </span>
              {isSaving ? <span className="text-amber-500 flex items-center gap-1"><Clock size={14} /> Saving...</span> : <span className="text-green-500 flex items-center gap-1"><Check size={14} /> Saved</span>}
            </p>
          </div>
        </div>
      </header>

      {isLocked && (
        <div className="bg-amber-50 border border-amber-200 p-4 rounded-xl flex items-center gap-3 text-amber-800">
          <Lock size={20} />
          <p className="text-sm font-medium">This workflow is locked because it has active batch records. No changes allowed.</p>
        </div>
      )}

      <div className="glass-panel p-8 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="md:col-span-1">
            <label className="block text-sm font-bold text-slate-700 mb-1">Workflow Name</label>
            <input 
              value={name}
              onChange={e => updateName(e.target.value)}
              className="input-field text-lg font-semibold" 
              placeholder="e.g., Tablet Manufacturing Batch Record" 
              disabled={isLocked}
            />
          </div>
          <div className="md:col-span-1">
            <label className="block text-sm font-bold text-slate-700 mb-1">Status</label>
            <select 
              value={status}
              onChange={e => updateStatus(e.target.value as any)}
              className="input-field"
              disabled={isLocked}
            >
              <option value="Draft">Draft</option>
              <option value="Released">Released</option>
              <option value="Effective">Effective</option>
              <option value="Deleted">Deleted</option>
            </select>
          </div>
          <div className="md:col-span-2">
            <label className="block text-sm font-bold text-slate-700 mb-1">Description</label>
            <textarea 
              value={description}
              onChange={e => updateDescription(e.target.value)}
              className="input-field min-h-[100px]" 
              placeholder="Describe the purpose of this workflow..." 
              disabled={isLocked}
            />
          </div>
        </div>

        <div className="pt-6 border-t border-slate-100">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold">Process Steps</h2>
            <button onClick={addStep} disabled={isLocked} className="btn-secondary text-sm flex items-center gap-2">
              <PlusCircle size={18} /> Add Step
            </button>
          </div>

          <div className="space-y-4">
            {steps.map((step, i) => (
              <motion.div 
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                key={i} 
                className="p-6 border border-slate-200 rounded-2xl bg-slate-50/50 relative group"
              >
                <div className="absolute -left-3 top-1/2 -translate-y-1/2 w-8 h-8 bg-pharma-primary text-white rounded-full flex items-center justify-center font-bold text-sm">
                  {i + 1}
                </div>
                
                {/* AI Metadata Display */}
                {(step.confidence || step.source_reference) && (
                  <div className="absolute -top-3 right-4 flex gap-2">
                    {step.confidence && (
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border flex items-center gap-1 bg-white ${
                        step.confidence === 'High' ? 'text-green-600 border-green-200' :
                        step.confidence === 'Medium' ? 'text-amber-600 border-amber-200' :
                        'text-red-600 border-red-200'
                      }`}>
                        <Sparkles size={10} /> {step.confidence} Confidence
                      </span>
                    )}
                    {step.source_reference && (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold border border-slate-200 text-slate-500 bg-white flex items-center gap-1" title={step.source_reference}>
                        <HelpCircle size={10} /> Source: {step.source_reference.substring(0, 20)}{step.source_reference.length > 20 ? '...' : ''}
                      </span>
                    )}
                  </div>
                )}

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="md:col-span-2">
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Step Name</label>
                    <input 
                      value={step.name}
                      onChange={e => updateStep(i, { name: e.target.value, config: { ...step.config, label: e.target.value } })}
                      className="input-field" 
                      placeholder="e.g., Material Verification" 
                      disabled={isLocked}
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Responsible Role</label>
                    <select 
                      value={step.responsible_role}
                      onChange={e => updateStep(i, { responsible_role: e.target.value })}
                      className="input-field"
                      disabled={isLocked}
                    >
                      <option>Operator</option>
                      <option>Reviewer</option>
                      <option>QA Approver</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Field Type</label>
                    <select 
                      value={step.type}
                      onChange={e => updateStep(i, { type: e.target.value })}
                      className="input-field"
                      disabled={isLocked}
                    >
                      <option value="multi-field">Multi-Field Layout</option>
                      <option value="text">Single Text Input</option>
                      <option value="number">Single Numeric Value</option>
                      <option value="date">Single Date/Time</option>
                      <option value="dropdown">Single Dropdown</option>
                      <option value="file">Single File Upload</option>
                      <option value="comment">Single Comment Box</option>
                      <option value="calculation">Single Calculation</option>
                      <option value="table">Single Data Table</option>
                    </select>
                  </div>
                  
                  {step.type === 'multi-field' && (
                    <div className="md:col-span-3 space-y-4 pt-4 border-t border-slate-100">
                      <div className="flex items-center justify-between">
                        <h4 className="text-xs font-bold text-slate-400 uppercase">Step Fields / Layout</h4>
                        <button 
                          onClick={() => addFieldToStep(i)}
                          disabled={isLocked}
                          className="text-xs font-bold text-pharma-primary flex items-center gap-1 hover:underline disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                          <Plus size={14} /> Add Field to Step
                        </button>
                      </div>
                      <div className="grid grid-cols-1 gap-4">
                        <DndContext 
                          sensors={sensors}
                          collisionDetection={closestCenter}
                          onDragEnd={(event) => handleDragEnd(i, event)}
                        >
                          <SortableContext 
                            items={(step.config?.fields || []).map(f => f.id)}
                            strategy={verticalListSortingStrategy}
                          >
                            {(step.config?.fields || []).map((field, fi) => (
                              <SortableField 
                                key={field.id}
                                field={field}
                                onChange={(updates: any) => updateFieldInStep(i, fi, updates)}
                                onDelete={() => deleteFieldFromStep(i, fi)}
                                disabled={isLocked}
                              />
                            ))}
                          </SortableContext>
                        </DndContext>
                        {(step.config?.fields || []).length === 0 && (
                          <div className="text-center py-6 bg-white border border-dashed border-slate-200 rounded-xl text-slate-400 text-xs">
                            No fields added yet. Add fields to create a "paper layout" for this step.
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  {step.type === 'dropdown' && (
                    <div className="md:col-span-2">
                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Options (comma separated)</label>
                      <input 
                        onChange={e => updateStep(i, { config: { ...step.config, options: e.target.value.split(',').map(s => s.trim()) } })}
                        className="input-field" 
                        placeholder="Option 1, Option 2, Option 3" 
                        disabled={isLocked}
                      />
                    </div>
                  )}

                  {step.type === 'calculation' && (
                    <div className="md:col-span-2">
                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Formula (e.g. &#123;&#123;1&#125;&#125; + &#123;&#123;2&#125;&#125;)</label>
                      <input 
                        value={step.config?.formula}
                        onChange={e => updateStep(i, { config: { ...step.config, formula: e.target.value } })}
                        className="input-field" 
                        placeholder="Use {{step_index}} to reference values" 
                        disabled={isLocked}
                      />
                    </div>
                  )}

                  {step.type === 'table' && (
                    <div className="md:col-span-3">
                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Table Configuration</label>
                      <TableConfigurator 
                        config={step.config?.tableConfig} 
                        onChange={(tc) => updateStep(i, { config: { ...step.config, tableConfig: tc } })}
                        disabled={isLocked}
                      />
                    </div>
                  )}

                  <div className="flex items-center gap-2">
                    <input 
                      type="checkbox" 
                      checked={step.config?.reasonMandatory}
                      onChange={e => updateStep(i, { config: { ...step.config, reasonMandatory: e.target.checked } })}
                      disabled={isLocked}
                    />
                    <label className="text-xs font-bold text-slate-500 uppercase">Reason Mandatory for Edits</label>
                  </div>
                </div>
                {!isLocked && (
                  <button 
                    onClick={() => setConfirmModal({
                      isOpen: true,
                      title: 'Delete Step',
                      message: `Are you sure you want to delete step ${i + 1}: "${step.name || 'Untitled Step'}"? This action cannot be undone.`,
                      onConfirm: () => {
                        const newSteps = steps.filter((_, idx) => idx !== i);
                        updateStepsAndSave(newSteps);
                      }
                    })}
                    className="absolute -right-2 -top-2 w-8 h-8 bg-white border border-slate-200 text-red-500 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all hover:bg-red-50"
                  >
                    <X size={16} />
                  </button>
                )}
              </motion.div>
            ))}
            {steps.length === 0 && (
              <div className="text-center py-12 border-2 border-dashed border-slate-200 rounded-2xl text-slate-400">
                Click "Add Step" to begin designing your process.
              </div>
            )}
          </div>
        </div>
      </div>

      {confirmModal && (
        <ConfirmationModal
          isOpen={confirmModal.isOpen}
          onClose={() => setConfirmModal(null)}
          onConfirm={confirmModal.onConfirm}
          title={confirmModal.title}
          message={confirmModal.message}
        />
      )}
    </div>
  );
};

// --- Table Executor ---

const TableExecutor = ({ config, value, onChange, disabled, allSteps, allData }: { config: any, value: any, onChange: (v: any) => void, disabled?: boolean, allSteps: any[], allData: any[] }) => {
  const rows = config?.rows || 3;
  const cols = config?.cols || 3;
  const cells = config?.cells || {};
  const [localData, setLocalData] = useState<any>(value || {});
  const [recalcCounter, setRecalcCounter] = useState(0);

  // Sync with parent value when it changes (e.g. step change)
  useEffect(() => {
    setLocalData(value || {});
    setRecalcCounter(0);
  }, [value]);

  const evaluateFormula = (formula: string, currentTableData: any) => {
    if (!formula || !formula.startsWith('=')) return formula;
    let evalStr = formula.substring(1).toUpperCase();

    // 1. Replace cell references (e.g., A1, B2) within the same table
    const cellRefRegex = /\b([A-Z]+)(\d+)\b/g;
    evalStr = evalStr.replace(cellRefRegex, (match, colStr, rowStr) => {
      const colIndex = colStr.split('').reduce((acc: number, char: string) => acc * 26 + char.charCodeAt(0) - 64, 0) - 1;
      const rowIndex = parseInt(rowStr) - 1;
      const key = `${rowIndex}-${colIndex}`;
      
      const val = currentTableData[key] || cells[key]?.value || 0;
      return isNaN(parseFloat(val)) ? "0" : val;
    });

    // 2. Replace step references (e.g., {{1}}, {{2}})
    const stepRefRegex = /\{\{(\d+)\}\}/g;
    evalStr = evalStr.replace(stepRefRegex, (match, stepIdxStr) => {
      const stepIdx = parseInt(stepIdxStr) - 1;
      const step = allSteps[stepIdx];
      const data = allData.find(d => d.step_id === step?.id);
      const val = data?.data?.value || 0;
      return isNaN(parseFloat(val)) ? "0" : val;
    });

    // 3. Replace cross-step table cell references (e.g., {{1.A1}})
    const crossStepCellRefRegex = /\{\{(\d+)\.([A-Z]+)(\d+)\}\}/g;
    evalStr = evalStr.replace(crossStepCellRefRegex, (match, stepIdxStr, colStr, rowStr) => {
      const stepIdx = parseInt(stepIdxStr) - 1;
      const step = allSteps[stepIdx];
      const data = allData.find(d => d.step_id === step?.id);
      
      const colIndex = colStr.split('').reduce((acc: number, char: string) => acc * 26 + char.charCodeAt(0) - 64, 0) - 1;
      const rowIndex = parseInt(rowStr) - 1;
      const key = `${rowIndex}-${colIndex}`;
      
      const val = data?.data?.[key] || step?.config?.tableConfig?.cells?.[key]?.value || 0;
      return isNaN(parseFloat(val)) ? "0" : val;
    });

    try {
      // Basic math evaluation
      return safeEval(evalStr);
    } catch (e) {
      return '#ERR';
    }
  };

  useEffect(() => {
    // Recalculate all formulas when localData changes
    if (recalcCounter > 10) return; // Safety limit for circular refs

    const newData = { ...localData };
    let changed = false;
    
    Object.keys(cells).forEach(key => {
      const cell = cells[key];
      if (cell.formula) {
        const newVal = evaluateFormula(cell.formula, localData);
        if (newData[key] !== newVal) {
          newData[key] = newVal;
          changed = true;
        }
      }
    });

    if (changed) {
      setRecalcCounter(prev => prev + 1);
      setLocalData(newData);
      onChange(newData);
    }
  }, [localData, cells, allSteps, allData, recalcCounter]);

  const handleCellChange = (key: string, val: string) => {
    if (disabled) return;
    const newData = { ...localData, [key]: val };
    setLocalData(newData);
    onChange(newData);
  };

  return (
    <div className="overflow-x-auto">
      <table className="border-collapse border border-slate-300 w-full min-w-[600px]">
        <tbody>
          {Array.from({ length: rows }).map((_, ri) => (
            <tr key={ri}>
              {Array.from({ length: cols }).map((_, ci) => {
                const key = `${ri}-${ci}`;
                const cellConfig = cells[key] || {};
                if (cellConfig.isMerged) return null;
                
                const isFormula = !!cellConfig.formula;
                const displayValue = localData[key] !== undefined ? localData[key] : (cellConfig.value || '');

                return (
                  <td 
                    key={ci} 
                    rowSpan={cellConfig.rowSpan || 1}
                    colSpan={cellConfig.colSpan || 1}
                    style={{ backgroundColor: cellConfig.color || 'transparent' }}
                    className="border border-slate-300 p-0 relative min-w-[100px]"
                  >
                    <div className="text-[8px] font-bold text-slate-400 absolute top-0.5 left-1 uppercase pointer-events-none">
                      {String.fromCharCode(65 + ci)}{ri + 1}
                    </div>
                    {isFormula || disabled ? (
                      <div className={`w-full h-10 px-2 pt-3 text-sm text-center font-medium ${isFormula ? 'text-pharma-accent bg-slate-50/50' : ''}`}>
                        {displayValue}
                      </div>
                    ) : (
                      <input 
                        value={displayValue}
                        onChange={e => handleCellChange(key, e.target.value)}
                        className="w-full h-10 px-2 pt-3 text-sm text-center border-none outline-none focus:ring-2 focus:ring-pharma-accent/30 bg-transparent"
                        placeholder="..."
                      />
                    )}
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

const InstanceList = ({ user, onOpenInstance }: { user: User, onOpenInstance: (id: number) => void }) => {
  const [instances, setInstances] = useState<Instance[]>([]);
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    api.get('/instances').then(res => res.data).then(setInstances);
  }, []);

  const filtered = (Array.isArray(instances) ? instances : []).filter(i => {
    if (filter === 'all') return true;
    return i.status === filter;
  });

  return (
    <div className="space-y-6">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Active Tasks</h1>
          <p className="text-slate-500">Manage and execute ongoing workflow instances.</p>
        </div>
        <div className="flex bg-white border border-slate-200 rounded-xl p-1 overflow-x-auto">
          {['all', 'Scheduled', 'Executing', 'Work in Process', 'Under Review', 'QA Review', 'Released', 'Quarantine', 'Archived'].map(f => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-4 py-2 rounded-lg text-sm font-medium capitalize transition-all whitespace-nowrap flex items-center gap-1 ${
                filter === f ? 'bg-pharma-primary text-white shadow-sm' : 'text-slate-500 hover:bg-slate-50'
              }`}
            >
              {f}
              <HelpTooltip 
                text={`Filter tasks by ${f} status.`} 
                guideLink="instances" 
                className={filter === f ? "text-white/40 hover:text-white" : ""} 
              />
            </button>
          ))}
        </div>
      </header>

      <div className="glass-panel overflow-hidden">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-50 border-b border-slate-200">
              <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Batch #</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Product</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Status</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Started By</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Last Update</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {filtered.map((inst) => (
              <tr key={inst.id} className="hover:bg-slate-50/50 transition-all">
                <td className="px-6 py-4 font-mono text-sm text-slate-500">{inst.batch_number}</td>
                <td className="px-6 py-4">
                  <p className="font-bold text-slate-800">{inst.product_name}</p>
                  <p className="text-[10px] text-slate-400 uppercase">{inst.workflow_name}</p>
                </td>
                <td className="px-6 py-4">
                  <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${getStatusColor(inst.status)}`}>
                    {inst.status}
                  </span>
                </td>
                <td className="px-6 py-4 text-sm text-slate-600">{inst.creator_name}</td>
                <td className="px-6 py-4 text-sm text-slate-500">
                  {inst.status === 'Scheduled' && inst.scheduled_at ? (
                    <span className="flex items-center gap-1 text-purple-600 font-medium">
                      <Clock size={14} /> {new Date(inst.scheduled_at).toLocaleString()}
                    </span>
                  ) : (
                    new Date(inst.updated_at).toLocaleDateString()
                  )}
                </td>
                <td className="px-6 py-4 text-right">
                  <div className="flex items-center justify-end gap-4">
                    <button 
                      onClick={async (e) => {
                        e.stopPropagation();
                        try {
                          const res = await api.get(`/instances/${inst.id}/audit-report`);
                          const content = `AUDIT REPORT: ${inst.batch_number}
Product: ${inst.product_name}
Generated: ${new Date().toLocaleString()}

--------------------------------------------------------------------------------
${Array.isArray(res.data) ? res.data.map((log: any) => 
  `[${new Date(log.timestamp).toLocaleString()}] ${log.user_name} (${log.user_role}): ${log.action}
${log.details ? `Details: ${log.details}` : ''}`
).join('\n\n--------------------------------------------------------------------------------\n\n') : 'No audit logs found.'}
`;
                          const blob = new Blob([content], { type: 'text/plain' });
                          const url = URL.createObjectURL(blob);
                          const a = document.createElement('a');
                          a.href = url;
                          a.download = `Batch_${inst.batch_number}_Audit_Report.txt`;
                          a.click();
                        } catch (err) {
                          toast.error('Failed to download audit report');
                        }
                      }}
                      className="text-slate-400 hover:text-pharma-accent transition-colors"
                      title="Download Audit Report"
                    >
                      <Download size={16} />
                    </button>
                    <button 
                      onClick={() => onOpenInstance(inst.id)}
                      className="text-pharma-accent font-bold text-sm hover:underline flex items-center gap-1"
                    >
                      Open <ChevronRight size={16} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
            {filtered.length === 0 && (
              <tr>
                <td colSpan={6} className="px-6 py-12 text-center text-slate-400">
                  No instances found matching the filter.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

const InstanceExecution = ({ instanceId, user, onBack }: { instanceId: number, user: User, onBack: () => void }) => {
  const [instance, setInstance] = useState<Instance | null>(null);
  const [activeStepId, setActiveStepId] = useState<number | null>(null);
  const [expandedStepIds, setExpandedStepIds] = useState<Set<number>>(new Set());
  const [formData, setFormData] = useState<any>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [reviewComment, setReviewComment] = useState('');
  const [finalStatus, setFinalStatus] = useState('Under Review');
  const [isNa, setIsNa] = useState(false);
  const [naReason, setNaReason] = useState('');
  const [editStepId, setEditStepId] = useState<number | null>(null);
  const [editReason, setEditReason] = useState('');
  const [editValue, setEditValue] = useState<any>(null);
  const [isSignatureModalOpen, setIsSignatureModalOpen] = useState(false);
  const [isDeviationModalOpen, setIsDeviationModalOpen] = useState(false);
  const [signatureMeaning, setSignatureMeaning] = useState<'Executed' | 'Reviewed' | 'Approved' | 'Verified'>('Executed');
  const [pendingAction, setPendingAction] = useState<any>(null);

  const refresh = async () => {
    try {
      const res = await api.get(`/instances/${instanceId}`);
      setInstance(res.data);
      if (!activeStepId && res.data.steps?.length > 0) {
        setActiveStepId(res.data.steps[0].id);
      }
    } catch (err) {
      toast.error('Failed to refresh instance data');
    }
  };

  useEffect(() => {
    refresh();
  }, [instanceId]);

  if (!instance) return <div className="p-12 text-center">Loading instance...</div>;

  const currentStep = instance.steps?.find(s => s.id === activeStepId) || instance.steps?.[0];
  const isReviewer = user.role === 'Reviewer' || user.role === 'QA Approver' || user.role === 'Admin';
  const isMyTurn = currentStep?.responsible_role === user.role || user.role === 'Admin';

  const toggleExpand = (stepId: number) => {
    setExpandedStepIds(prev => {
      const next = new Set(prev);
      if (next.has(stepId)) next.delete(stepId);
      else next.add(stepId);
      return next;
    });
  };

  const expandAll = () => {
    if (!instance?.steps) return;
    setExpandedStepIds(new Set(instance.steps.map(s => s.id)));
  };

  const collapseAll = () => {
    setExpandedStepIds(new Set());
  };

  const downloadAuditReportExcel = async () => {
    if (!instance) return;
    try {
      const res = await api.get(`/instances/${instanceId}/audit-report`);
      const auditTrail = res.data;
      
      const header = [
        ['BATCH AUDIT REPORT'],
        [`Batch Number: ${instance.batch_number}`],
        [`Product: ${instance.product_name}`],
        [`Workflow: ${instance.workflow_name}`],
        [`Generated On: ${new Date().toLocaleString()}`],
        [] // Empty row
      ];

      const tableHeader = ['Timestamp', 'User', 'Role', 'Action', 'Step', 'Details', 'Reason'];
      const tableData = (Array.isArray(auditTrail) ? auditTrail : []).map((log: any) => {
        const step = instance.steps?.find(s => s.id === log.target_id);
        return [
          new Date(log.timestamp).toLocaleString(),
          log.user_name,
          log.user_role,
          log.action,
          step?.name || `Step ${log.target_id}`,
          log.details || '',
          log.reason || ''
        ];
      });

      const ws = XLSX.utils.aoa_to_sheet([...header, tableHeader, ...tableData]);
      
      // Column widths
      ws['!cols'] = [
        { wch: 20 }, // Timestamp
        { wch: 20 }, // User
        { wch: 15 }, // Role
        { wch: 15 }, // Action
        { wch: 30 }, // Step
        { wch: 40 }, // Details
        { wch: 30 }  // Reason
      ];

      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, "Audit Trail");
      XLSX.writeFile(wb, `Batch_${instance.batch_number}_Audit_Report.xlsx`);
    } catch (err) {
      toast.error('Failed to download audit report (Excel)');
    }
  };

  const downloadAuditReportPDF = async () => {
    if (!instance) return;
    try {
      const res = await api.get(`/instances/${instanceId}/audit-report`);
      const auditTrail = res.data;
      
      const doc = new jsPDF('l', 'mm', 'a4');
      const pageWidth = doc.internal.pageSize.getWidth();
      const pageHeight = doc.internal.pageSize.getHeight();

      // Header
      doc.setFontSize(18);
      doc.setTextColor(43, 108, 176);
      doc.text('BATCH AUDIT REPORT', 14, 22);
      
      doc.setFontSize(10);
      doc.setTextColor(100);
      doc.text(`Batch Number: ${instance.batch_number}`, 14, 30);
      doc.text(`Product: ${instance.product_name}`, 14, 35);
      doc.text(`Workflow: ${instance.workflow_name}`, 14, 40);
      doc.text(`Generated On: ${new Date().toLocaleString()}`, 14, 45);
      
      doc.setDrawColor(200);
      doc.line(14, 50, pageWidth - 14, 50);

      const tableData = (Array.isArray(auditTrail) ? auditTrail : []).map((log: any) => {
        const step = instance.steps?.find(s => s.id === log.target_id);
        return [
          new Date(log.timestamp).toLocaleString(),
          log.user_name,
          log.user_role,
          log.action,
          step?.name || log.target_id,
          log.details || '',
          log.reason || ''
        ];
      });

      autoTable(doc, {
        startY: 55,
        head: [['Timestamp', 'User', 'Role', 'Action', 'Step', 'Details', 'Reason']],
        body: tableData,
        theme: 'grid',
        styles: { fontSize: 8, cellPadding: 2 },
        headStyles: { fillColor: [43, 108, 176], textColor: [255, 255, 255], fontStyle: 'bold' },
        alternateRowStyles: { fillColor: [245, 247, 250] },
        margin: { top: 55, bottom: 20 },
        didDrawPage: (data: any) => {
          // Footer
          doc.setFontSize(8);
          doc.setTextColor(150);
          doc.text('GMP CONFIDENTIAL DOCUMENT', 14, pageHeight - 10);
          doc.text(`Page ${data.pageNumber}`, pageWidth - 25, pageHeight - 10);
        }
      });

      doc.save(`Batch_${instance.batch_number}_Audit_Report.pdf`);
    } catch (err) {
      toast.error('Failed to download audit report (PDF)');
    }
  };

  const downloadStepData = (stepId: number, format: 'excel' | 'pdf') => {
    if (!instance) return;
    const step = instance.steps?.find(s => s.id === stepId);
    if (!step) return;
    const stepVersions = instance.data?.filter(d => d.step_id === stepId) || [];
    
    if (format === 'excel') {
      const header = [
        ['STEP EXECUTION HISTORY'],
        [`Batch Number: ${instance.batch_number}`],
        [`Step: ${step.name}`],
        [`Role: ${step.responsible_role}`],
        [`Generated On: ${new Date().toLocaleString()}`],
        []
      ];
      const tableHeader = ['Version', 'Timestamp', 'User', 'Status', 'Data', 'Reason'];
      const tableData = stepVersions.map(v => [
        `v${v.version}`,
        new Date(v.submitted_at).toLocaleString(),
        v.submitted_by_name || 'Unknown',
        v.is_na ? 'N/A' : 'Completed',
        JSON.stringify(v.data),
        v.na_reason || '-'
      ]);

      const ws = XLSX.utils.aoa_to_sheet([...header, tableHeader, ...tableData]);
      ws['!cols'] = [{wch: 10}, {wch: 20}, {wch: 20}, {wch: 15}, {wch: 50}, {wch: 30}];
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, "Step History");
      XLSX.writeFile(wb, `Step_${stepId}_History.xlsx`);
    } else {
      const doc = new jsPDF();
      const pageWidth = doc.internal.pageSize.getWidth();
      const pageHeight = doc.internal.pageSize.getHeight();

      doc.setFontSize(18);
      doc.setTextColor(43, 108, 176);
      doc.text('STEP EXECUTION HISTORY', 14, 22);
      
      doc.setFontSize(10);
      doc.setTextColor(100);
      doc.text(`Batch Number: ${instance.batch_number}`, 14, 30);
      doc.text(`Step: ${step.name}`, 14, 35);
      doc.text(`Role: ${step.responsible_role}`, 14, 40);
      
      doc.setDrawColor(200);
      doc.line(14, 45, pageWidth - 14, 45);

      const tableData = stepVersions.map(v => [
        `v${v.version}`,
        new Date(v.submitted_at).toLocaleString(),
        v.submitted_by_name || 'Unknown',
        v.is_na ? `N/A: ${v.na_reason}` : JSON.stringify(v.data)
      ]);

      autoTable(doc, {
        startY: 50,
        head: [['Ver', 'Timestamp', 'User', 'Data']],
        body: tableData,
        theme: 'grid',
        styles: { fontSize: 8, cellPadding: 2 },
        headStyles: { fillColor: [43, 108, 176], textColor: [255, 255, 255] },
        didDrawPage: (data: any) => {
          doc.setFontSize(8);
          doc.setTextColor(150);
          doc.text('GMP CONFIDENTIAL DOCUMENT', 14, pageHeight - 10);
          doc.text(`Page ${data.pageNumber}`, pageWidth - 25, pageHeight - 10);
        }
      });

      doc.save(`Step_${stepId}_History.pdf`);
    }
  };

  const downloadBatchRecord = () => {
    if (!instance) return;
    const content = `BATCH RECORD: ${instance.batch_number}
Product: ${instance.product_name}
Status: ${instance.status}
Started: ${new Date(instance.started_at).toLocaleString()}
${instance.completed_at ? `Completed: ${new Date(instance.completed_at).toLocaleString()}` : ''}

EXECUTION DATA:
${(instance.steps || []).map((step, i) => {
  const stepVersions = instance.data?.filter(d => d.step_id === step.id) || [];
  return `
STEP ${i + 1}: ${step.name}
${(Array.isArray(stepVersions) ? stepVersions : []).map(v => `
  Version ${v.version} (${new Date(v.submitted_at).toLocaleString()})
  By: ${v.submitted_by_name}
  ${v.is_na ? `N/A: ${v.na_reason}` : `Data: ${JSON.stringify(v.data, null, 2)}`}
`).join('')}
`;
}).join('\n')}
`;
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Batch_${instance.batch_number}_Record.txt`;
    a.click();
  };

  const openSignature = (meaning: 'Executed' | 'Reviewed' | 'Approved' | 'Verified', action: any) => {
    setSignatureMeaning(meaning);
    setPendingAction(action);
    setIsSignatureModalOpen(true);
  };

  const handleSignatureSuccess = async (signature: any) => {
    if (pendingAction.type === 'submit') {
      await finalizeSubmit();
    } else if (pendingAction.type === 'edit') {
      await finalizeEdit();
    } else if (pendingAction.type === 'review') {
      await finalizeReview(pendingAction.payload);
    }
    setPendingAction(null);
  };

  const finalizeSubmit = async () => {
    if (!currentStep) return;
    setIsSubmitting(true);
    try {
      await api.post(`/instances/${instanceId}/submit`, { 
        stepId: currentStep.id, 
        data: formData, 
        userId: user.id,
        userRole: user.role,
        is_na: isNa,
        na_reason: naReason,
        stepNumber: instance.current_step_index + 1
      });
      toast.success("Step signed and submitted");
      setFormData({});
      setIsNa(false);
      setNaReason('');
      refresh();
    } catch (e) {
      toast.error("Submission failed");
    } finally {
      setIsSubmitting(false);
    }
  };

  const finalizeEdit = async () => {
    if (!editStepId || !editReason) return toast.error("Reason for change is mandatory.");
    setIsSubmitting(true);
    try {
      await api.post(`/instances/${instanceId}/submit`, { 
        stepId: editStepId, 
        data: editValue, 
        userId: user.id,
        userRole: user.role,
        reason: editReason,
        stepNumber: (instance.steps?.findIndex(s => s.id === editStepId) ?? -1) + 1
      });
      toast.success("Step modification signed and saved");
      setEditStepId(null);
      setEditReason('');
      setEditValue(null);
      refresh();
    } catch (e) {
      toast.error("Failed to update step");
    } finally {
      setIsSubmitting(false);
    }
  };

  const finalizeReview = async (action: string) => {
    setIsSubmitting(true);
    try {
      await api.post(`/instances/${instanceId}/review`, { 
        action, 
        comment: reviewComment, 
        finalStatus,
        userId: user.id,
        userRole: user.role
      });
      toast.success(`Record ${action === 'approve' ? 'approved' : 'sent for correction'}`);
      refresh();
    } catch (e) {
      toast.error("Review action failed");
    } finally {
      setIsSubmitting(false);
    }
  };

  const exportPDF = () => {
    const doc = new jsPDF('l', 'mm', 'a4');
    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();

    // Header
    doc.setFontSize(20);
    doc.setTextColor(43, 108, 176);
    doc.text('BATCH RECORD SUMMARY', 14, 22);
    
    doc.setFontSize(10);
    doc.setTextColor(100);
    doc.text(`Batch Number: ${instance.batch_number || 'N/A'}`, 14, 32);
    doc.text(`Product: ${instance.product_name || 'N/A'}`, 14, 38);
    doc.text(`Status: ${instance.status || 'N/A'}`, 14, 44);
    doc.text(`Generated On: ${new Date().toLocaleString()}`, 14, 50);
    
    doc.setDrawColor(200);
    doc.line(14, 55, pageWidth - 14, 55);

    const tableData = (instance.steps || []).map((step, i) => {
      const data = instance.data?.find(d => d.step_id === step.id);
      let entryText = '-';
      if (data?.is_na) {
        entryText = `N/A: ${data.na_reason}`;
      } else if (data?.data) {
        if (step.type === 'multi-field') {
          entryText = Object.entries(data.data)
            .map(([key, val]) => {
              const field = step.config?.fields?.find((f: any) => f.id === key);
              return `${field?.name || key}: ${val}`;
            })
            .join('\n');
        } else if (typeof data.data.value === 'object') {
          entryText = 'Table Data';
        } else {
          entryText = String(data.data.value || '-');
        }
      }
      
      return [
        i + 1,
        step.name,
        step.responsible_role,
        entryText,
        data?.submitted_by_name || '-',
        data?.submitted_at ? new Date(data.submitted_at).toLocaleString() : '-'
      ];
    });

    autoTable(doc, {
      startY: 60,
      head: [['#', 'Step Name', 'Role', 'Entry', 'User', 'Timestamp']],
      body: tableData,
      theme: 'grid',
      styles: { fontSize: 8, cellPadding: 2 },
      headStyles: { fillColor: [43, 108, 176], textColor: [255, 255, 255] },
      didDrawPage: (data: any) => {
        doc.setFontSize(8);
        doc.setTextColor(150);
        doc.text('GMP CONFIDENTIAL DOCUMENT', 14, pageHeight - 10);
        doc.text(`Page ${data.pageNumber}`, pageWidth - 25, pageHeight - 10);
      }
    });

    doc.save(`${instance.batch_number || 'Batch'}_Record_Summary.pdf`);
  };

  const calculateValue = (formula: string) => {
    try {
      let evalStr = formula;
      
      // 1. Handle cross-step table cell references: {{1.A1}}
      const crossStepCellRefRegex = /\{\{(\d+)\.([A-Z]+)(\d+)\}\}/g;
      evalStr = evalStr.replace(crossStepCellRefRegex, (match, stepIdxStr, colStr, rowStr) => {
        const stepIdx = parseInt(stepIdxStr) - 1;
        const step = instance.steps?.[stepIdx];
        const data = instance.data?.find(d => d.step_id === step?.id);
        
        const colIndex = colStr.split('').reduce((acc: number, char: string) => acc * 26 + char.charCodeAt(0) - 64, 0) - 1;
        const rowIndex = parseInt(rowStr) - 1;
        const key = `${rowIndex}-${colIndex}`;
        
        const val = data?.data?.[key] || step?.config?.tableConfig?.cells?.[key]?.value || 0;
        return isNaN(parseFloat(val)) ? "0" : val;
      });

      // 2. Handle field references within steps: {{1.field_id}} or {{1.variable_name}}
      const fieldRefRegex = /\{\{(\d+)\.([a-zA-Z0-9_]+)\}\}/g;
      evalStr = evalStr.replace(fieldRefRegex, (match, stepIdxStr, fieldRef) => {
        const stepIdx = parseInt(stepIdxStr) - 1;
        const step = instance.steps?.[stepIdx];
        const data = instance.data?.find(d => d.step_id === step?.id);
        
        // Try direct field ID first
        let val = data?.data?.[fieldRef];
        
        // If not found, try variableName
        if (val === undefined) {
          const field = step?.config?.fields?.find((f: any) => f.variableName === fieldRef);
          if (field) val = data?.data?.[field.id];
        }
        
        return isNaN(parseFloat(val || 0)) ? "0" : val;
      });

      // 3. Handle simple step references: {{1}}
      const matches = evalStr.match(/\{\{(\d+)\}\}/g);
      if (matches) {
        matches.forEach(m => {
          const idx = parseInt(m.replace(/[\{\}]/g, '')) - 1;
          const step = instance.steps?.[idx];
          const data = instance.data?.find(d => d.step_id === step?.id);
          const val = data?.data?.value || 0;
          evalStr = evalStr.replace(m, val.toString());
        });
      }

      // 4. Handle variable references in current step: {{variable_name}}
      const varRefRegex = /\{\{([a-zA-Z0-9_]+)\}\}/g;
      evalStr = evalStr.replace(varRefRegex, (match, varName) => {
        // Skip if it's a digit (handled by simple step ref)
        if (/^\d+$/.test(varName)) return match;
        
        const currentStep = instance.steps?.[instance.current_step_index];
        const field = currentStep?.config?.fields?.find((f: any) => f.variableName === varName);
        const val = formData[field?.id || ''] || 0;
        return isNaN(parseFloat(val)) ? "0" : val;
      });
      
      return safeEval(evalStr);
    } catch (e) {
      return 'Error';
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8">
      <header className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button onClick={onBack} className="p-2 hover:bg-slate-100 rounded-lg transition-all">
            <RotateCcw size={20} className="text-slate-500" />
          </button>
          <div>
            <h1 className="text-3xl font-bold text-slate-900">{instance.product_name}</h1>
            <p className="text-slate-500">Batch: <span className="font-mono font-bold">{instance.batch_number}</span> • Status: <span className={`px-2 py-0.5 rounded text-xs font-bold uppercase ${instance.status === 'Work in Process' ? 'bg-blue-100 text-blue-700' : 'bg-amber-100 text-amber-700'}`}>{instance.status}</span></p>
          </div>
        </div>
        <div className="flex gap-3">
          <button 
            onClick={() => setIsDeviationModalOpen(true)}
            className="px-4 py-2 bg-red-50 text-red-600 rounded-xl font-bold text-sm flex items-center gap-2 hover:bg-red-100 transition-all"
          >
            <AlertCircle size={18} /> Report Deviation
          </button>
          <button onClick={downloadBatchRecord} className="btn-secondary flex items-center gap-2">
            <Download size={18} /> Download Record
            <HelpTooltip text="Download the complete electronic batch record (EBR) in text format for offline review." guideLink="reporting" />
          </button>
          <button onClick={exportPDF} className="btn-secondary flex items-center gap-2">
            <FileText size={18} /> Export PDF
            <HelpTooltip text="Export the current batch record as a formatted PDF document with headers and footers." guideLink="reporting" />
          </button>
        </div>
      </header>

      <ElectronicSignatureModal 
        isOpen={isSignatureModalOpen}
        onClose={() => setIsSignatureModalOpen(false)}
        onSuccess={handleSignatureSuccess}
        batchId={instanceId}
        stepId={currentStep?.id || 0}
        meaning={signatureMeaning}
      />

      <DeviationModal 
        isOpen={isDeviationModalOpen}
        onClose={() => setIsDeviationModalOpen(false)}
        batchId={instanceId}
        stepId={activeStepId || 0}
      />

      <div className="space-y-6">
        {instance.status === 'Under Review' && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="glass-panel p-8 space-y-6 border-l-4 border-l-amber-500"
          >
            <h2 className="text-xl font-bold">Review & Approval</h2>
            <p className="text-slate-500">All steps have been completed. Please review the data and provide your decision.</p>
            
            {isReviewer ? (
              <div className="space-y-4">
                <textarea 
                  value={reviewComment}
                  onChange={e => setReviewComment(e.target.value)}
                  className="input-field min-h-[100px]" 
                  placeholder="Add review comments or justification..." 
                />
                <div className="grid grid-cols-3 gap-4">
                  <button 
                    onClick={() => openSignature('Approved', { type: 'review', payload: 'approve' })}
                    className="bg-emerald-500 text-white p-3 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-emerald-600 transition-all"
                  >
                    <ShieldCheck size={18} /> Approve
                  </button>
                  <button 
                    onClick={() => openSignature('Reviewed', { type: 'review', payload: 'correction' })}
                    className="bg-amber-500 text-white p-3 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-amber-600 transition-all"
                  >
                    <RotateCcw size={18} /> Correction
                  </button>
                  <button 
                    onClick={() => openSignature('Reviewed', { type: 'review', payload: 'reject' })}
                    className="bg-red-500 text-white p-3 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-red-600 transition-all"
                  >
                    <Ban size={18} /> Reject
                  </button>
                </div>
              </div>
            ) : (
              <div className="bg-slate-50 p-6 rounded-xl text-slate-500 text-center">
                <Clock className="mx-auto mb-2 opacity-30" size={32} />
                <p>Waiting for Reviewer/QA to approve this record.</p>
              </div>
            )}
          </motion.div>
        )}

        <div className="glass-panel p-8 space-y-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <h2 className="text-xl font-bold">Execution Steps</h2>
              <div className="flex items-center gap-2">
                <button 
                  onClick={expandAll}
                  className="p-1.5 hover:bg-slate-100 rounded-lg text-slate-500 transition-all"
                  title="Expand All"
                >
                  <Maximize2 size={16} />
                </button>
                <button 
                  onClick={collapseAll}
                  className="p-1.5 hover:bg-slate-100 rounded-lg text-slate-500 transition-all"
                  title="Collapse All"
                >
                  <Minimize2 size={16} />
                </button>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="flex items-center bg-slate-100 rounded-xl p-1">
                <button 
                  onClick={downloadAuditReportPDF}
                  className="px-3 py-1.5 text-[10px] font-bold text-slate-600 hover:bg-white hover:shadow-sm rounded-lg transition-all flex items-center gap-1"
                >
                  <FileText size={12} /> Audit PDF
                  <HelpTooltip text="Download a detailed audit trail of all actions taken on this batch in PDF format." guideLink="audit" />
                </button>
                <button 
                  onClick={downloadAuditReportExcel}
                  className="px-3 py-1.5 text-[10px] font-bold text-slate-600 hover:bg-white hover:shadow-sm rounded-lg transition-all flex items-center gap-1"
                >
                  <FileSpreadsheet size={12} /> Audit Excel
                  <HelpTooltip text="Download a detailed audit trail of all actions taken on this batch in Excel format." guideLink="audit" />
                </button>
              </div>
            </div>
          </div>

          <div className="space-y-4 relative before:absolute before:left-4 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-100">
            {instance.steps?.map((step, i) => {
              const stepVersions = instance.data?.filter(d => d.step_id === step.id) || [];
              const isCompleted = stepVersions.length > 0;
              const isActive = activeStepId === step.id;
              const isExpanded = expandedStepIds.has(step.id) || isActive;
              const isStepMyTurn = step.responsible_role === user.role || user.role === 'Admin';
              const isCurrentActive = isActive && instance.status === 'Work in Process';

              return (
                <div key={step.id} className="relative pl-10">
                  <div 
                    onClick={() => {
                      setActiveStepId(step.id);
                      if (!expandedStepIds.has(step.id)) toggleExpand(step.id);
                    }}
                    className={`absolute left-0 top-1 w-8 h-8 rounded-full flex items-center justify-center z-10 cursor-pointer transition-all ${
                      isCompleted ? 'bg-emerald-500 text-white shadow-sm' : isActive ? 'bg-pharma-accent text-white shadow-lg scale-110' : 'bg-slate-100 text-slate-400'
                    } ${isActive ? 'ring-4 ring-pharma-accent/20' : ''}`}
                  >
                    {isCompleted ? <Check size={16} /> : <span>{i + 1}</span>}
                  </div>
                  
                  <div className={`glass-panel border-slate-200 overflow-hidden transition-all ${isActive ? 'ring-2 ring-pharma-accent shadow-xl transform scale-[1.01]' : 'hover:border-slate-300'}`}>
                    <div className={`p-4 flex items-center justify-between ${isActive ? 'bg-pharma-accent/5' : 'bg-slate-50/50'}`}>
                      <div className="flex items-center gap-3">
                        <button 
                          onClick={() => toggleExpand(step.id)}
                          className="p-1 hover:bg-slate-200 rounded transition-all"
                        >
                          {isExpanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                        </button>
                        <div>
                          <button 
                            onClick={() => setActiveStepId(step.id)}
                            className={`font-bold text-left hover:underline ${isCompleted ? 'text-slate-800' : isActive ? 'text-pharma-accent' : 'text-slate-400'}`}
                          >
                            {step.name}
                          </button>
                          <p className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">
                            {step.responsible_role}
                          </p>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        {isCompleted && user.role === 'Admin' && instance.status === 'Work in Process' && (
                          <button 
                            onClick={() => {
                              setEditStepId(step.id);
                              setEditValue(stepVersions[0].data);
                            }}
                            className="p-2 text-pharma-accent hover:bg-pharma-accent/10 rounded-lg transition-all"
                            title="Edit Step"
                          >
                            <Edit3 size={14} />
                          </button>
                        )}
                        <div className="flex items-center bg-white border border-slate-200 rounded-lg p-0.5">
                          <button 
                            onClick={() => downloadStepData(step.id, 'pdf')}
                            className="p-1.5 text-slate-400 hover:text-pharma-accent transition-all"
                            title="Download PDF"
                          >
                            <FileDown size={14} />
                          </button>
                          <button 
                            onClick={() => downloadStepData(step.id, 'excel')}
                            className="p-1.5 text-slate-400 hover:text-pharma-accent transition-all"
                            title="Download Excel"
                          >
                            <FileSpreadsheet size={14} />
                          </button>
                        </div>
                      </div>
                    </div>

                    {isExpanded && (
                      <div className="p-6 space-y-6 bg-white">
                        {/* Execution Form Inline */}
                        {isActive && instance.status === 'Work in Process' && (
                          <div className="p-6 bg-pharma-accent/5 rounded-2xl border border-pharma-accent/10 space-y-6">
                            <div className="flex items-center justify-between">
                              <h4 className="text-sm font-bold text-pharma-accent uppercase tracking-widest">Execution Form</h4>
                              {!isStepMyTurn && (
                                <span className="text-[10px] font-bold text-amber-600 bg-amber-50 px-2 py-1 rounded">
                                  Waiting for {step.responsible_role}
                                </span>
                              )}
                            </div>

                            {isStepMyTurn && (
                              <div className="space-y-4">
                                <div className="flex items-center gap-2">
                                  <input 
                                    type="checkbox" 
                                    id={`is_na_${step.id}`} 
                                    checked={isNa} 
                                    onChange={e => setIsNa(e.target.checked)} 
                                  />
                                  <label htmlFor={`is_na_${step.id}`} className="text-sm font-bold text-slate-700">Mark as N/A</label>
                                </div>

                                {isNa ? (
                                  <div>
                                    <label className="block text-sm font-bold text-slate-700 mb-1">Reason for N/A</label>
                                    <textarea 
                                      className="input-field" 
                                      placeholder="Explain why this step is not applicable..." 
                                      value={naReason}
                                      onChange={e => setNaReason(e.target.value)}
                                    />
                                  </div>
                                ) : (
                                  <>
                                    {step.type === 'multi-field' && (
                                      <div className="grid grid-cols-1 md:grid-cols-6 gap-6 p-6 bg-white rounded-2xl border border-slate-200 shadow-sm">
                                        {step.config?.fields?.map((field: any) => {
                                          const widthClass = field.config?.width === 'half' ? 'md:col-span-3' : 
                                                           field.config?.width === 'third' ? 'md:col-span-2' : 
                                                           'md:col-span-6';
                                          return (
                                            <div key={field.id} className={`${widthClass} space-y-2`}>
                                              <label className="block text-sm font-bold text-slate-700 flex items-center justify-between">
                                                <span>{field.name}</span>
                                                {field.variableName && <span className="text-[10px] font-mono text-slate-400">ID: {field.variableName}</span>}
                                              </label>
                                              {field.type === 'text' && (
                                                <input 
                                                  className="input-field" 
                                                  placeholder="Enter text..." 
                                                  value={formData[field.id] || ''}
                                                  onChange={e => setFormData({ ...formData, [field.id]: e.target.value })}
                                                />
                                              )}
                                              {field.type === 'number' && (
                                                <input 
                                                  type="number" 
                                                  className="input-field" 
                                                  placeholder="Enter numeric value..." 
                                                  value={formData[field.id] || ''}
                                                  onChange={e => setFormData({ ...formData, [field.id]: e.target.value })}
                                                />
                                              )}
                                              {field.type === 'date' && (
                                                <input 
                                                  type="datetime-local" 
                                                  className="input-field" 
                                                  value={formData[field.id] || ''}
                                                  onChange={e => setFormData({ ...formData, [field.id]: e.target.value })}
                                                />
                                              )}
                                              {field.type === 'dropdown' && (
                                                <select 
                                                  className="input-field"
                                                  value={formData[field.id] || ''}
                                                  onChange={e => setFormData({ ...formData, [field.id]: e.target.value })}
                                                >
                                                  <option value="">Select an option...</option>
                                                  {field.config?.options?.map((opt: string) => <option key={opt} value={opt}>{opt}</option>)}
                                                </select>
                                              )}
                                              {field.type === 'comment' && (
                                                <textarea 
                                                  className="input-field min-h-[80px]" 
                                                  placeholder="Add comments..." 
                                                  value={formData[field.id] || ''}
                                                  onChange={e => setFormData({ ...formData, [field.id]: e.target.value })}
                                                />
                                              )}
                                              {field.type === 'calculation' && (
                                                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                                                  <p className="text-[10px] font-bold text-slate-400 uppercase">Calculated</p>
                                                  <p className="text-lg font-bold text-pharma-accent">
                                                    {calculateValue(field.config?.formula || '')}
                                                  </p>
                                                  <button 
                                                    onClick={() => setFormData({ ...formData, [field.id]: calculateValue(field.config?.formula || '') })}
                                                    className="text-[10px] text-pharma-accent font-bold hover:underline"
                                                  >
                                                    Capture Value
                                                  </button>
                                                </div>
                                              )}
                                              {field.type === 'table' && (
                                                <div className="border border-slate-100 rounded-xl overflow-hidden">
                                                  <TableExecutor 
                                                    config={field.config?.tableConfig}
                                                    value={formData[field.id] || {}}
                                                    onChange={(val) => setFormData({ ...formData, [field.id]: val })}
                                                    allSteps={instance.steps || []}
                                                    allData={instance.data || []}
                                                  />
                                                </div>
                                              )}
                                            </div>
                                          );
                                        })}
                                      </div>
                                    )}
                                    {step.type === 'text' && (
                                      <input 
                                        className="input-field" 
                                        placeholder="Enter text..." 
                                        onChange={e => setFormData({ ...formData, value: e.target.value })}
                                      />
                                    )}
                                    {step.type === 'number' && (
                                      <input 
                                        type="number" 
                                        className="input-field" 
                                        placeholder="Enter numeric value..." 
                                        onChange={e => setFormData({ ...formData, value: e.target.value })}
                                      />
                                    )}
                                    {step.type === 'date' && (
                                      <input 
                                        type="datetime-local" 
                                        className="input-field" 
                                        onChange={e => setFormData({ ...formData, value: e.target.value })}
                                      />
                                    )}
                                    {step.type === 'dropdown' && (
                                      <select 
                                        className="input-field"
                                        onChange={e => setFormData({ ...formData, value: e.target.value })}
                                      >
                                        <option value="">Select an option...</option>
                                        {step.config?.options?.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                                      </select>
                                    )}
                                    {step.type === 'table' && (
                                      <div className="space-y-4">
                                        <label className="block text-sm font-bold text-slate-700 mb-1">Data Entry Table</label>
                                        <TableExecutor 
                                          config={step.config?.tableConfig}
                                          value={formData}
                                          onChange={(v) => setFormData(v)}
                                          allSteps={instance.steps || []}
                                          allData={instance.data || []}
                                        />
                                      </div>
                                    )}
                                    {step.type === 'comment' && (
                                      <textarea 
                                        className="input-field min-h-[100px]" 
                                        placeholder="Add your comments here..." 
                                        onChange={e => setFormData({ ...formData, value: e.target.value })}
                                      />
                                    )}
                                    {step.type === 'calculation' && (
                                      <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
                                        <p className="text-xs font-bold text-slate-500 uppercase mb-2">Calculated Result</p>
                                        <p className="text-2xl font-bold text-pharma-accent">
                                          {calculateValue(step.config?.formula || '')}
                                        </p>
                                        <button 
                                          onClick={() => setFormData({ ...formData, value: calculateValue(step.config?.formula || '') })}
                                          className="text-xs text-pharma-accent font-bold mt-2 hover:underline"
                                        >
                                          Capture Result
                                        </button>
                                      </div>
                                    )}
                                    {step.type === 'file' && (
                                      <div 
                                        onClick={() => document.getElementById(`file-upload-${step.id}`)?.click()}
                                        className="p-8 border-2 border-dashed border-slate-200 rounded-2xl text-center hover:border-pharma-accent transition-all cursor-pointer"
                                      >
                                        <Upload className="mx-auto mb-2 text-slate-400" size={32} />
                                        <p className="text-sm font-bold text-slate-600">Click to upload or drag and drop</p>
                                        <p className="text-xs text-slate-400 mt-1">PDF, PNG, JPG up to 10MB</p>
                                        <input 
                                          id={`file-upload-${step.id}`}
                                          type="file" 
                                          className="hidden" 
                                          onChange={e => setFormData({ ...formData, value: e.target.files?.[0]?.name })} 
                                        />
                                      </div>
                                    )}
                                  </>
                                )}

                                <button 
                                  onClick={finalizeSubmit}
                                  disabled={isSubmitting}
                                  className="btn-primary w-full flex items-center justify-center gap-2 mt-4"
                                >
                                  <ShieldCheck size={18} /> {isSubmitting ? 'Submitting...' : 'Submit Step'}
                                  <HelpTooltip text="Sign and submit this step. This will record your electronic signature and move the batch to the next step." guideLink="ebr" />
                                </button>
                              </div>
                            )}
                          </div>
                        )}

                        {/* Revision History */}
                        <div className="space-y-4">
                          <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Revision History</h4>
                          {stepVersions.length === 0 && !isActive && (
                            <p className="text-sm text-slate-400 italic">No data recorded for this step yet.</p>
                          )}
                          {stepVersions.map((versionData, vIdx) => (
                            <div key={versionData.id} className={`p-4 bg-slate-50 rounded-xl border border-slate-100 ${vIdx > 0 ? 'opacity-60 border-dashed' : ''}`}>
                              <div className="flex items-center justify-between mb-3">
                                <div className="flex items-center gap-2">
                                  <span className="px-2 py-0.5 bg-slate-200 text-slate-600 rounded text-[10px] font-bold">
                                    v{versionData.version}
                                  </span>
                                  <span className="text-[10px] font-bold text-slate-400 uppercase">
                                    {vIdx === 0 ? 'Current Version' : `Revision ${stepVersions.length - vIdx}`}
                                  </span>
                                </div>
                                <span className="text-[10px] text-slate-400">
                                  {new Date(versionData.submitted_at).toLocaleString()}
                                </span>
                              </div>
                              
                              {versionData.is_na ? (
                                <div className="flex items-center gap-2 text-amber-600 font-bold text-sm">
                                  <Ban size={14} /> Marked as N/A: {versionData.na_reason}
                                </div>
                              ) : (
                                <div className="bg-white p-4 rounded-lg border border-slate-100 shadow-sm">
                                  {step.type === 'multi-field' ? (
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                      {Object.entries(versionData.data).map(([key, val]: [string, any]) => {
                                        const field = step.config?.fields?.find((f: any) => f.id === key);
                                        return (
                                          <div key={key} className="space-y-1">
                                            <p className="text-[10px] font-bold text-slate-400 uppercase">{field?.name || key}</p>
                                            <p className="text-sm font-medium text-slate-700">{val?.toString() || '-'}</p>
                                          </div>
                                        );
                                      })}
                                    </div>
                                  ) : step.type === 'table' ? (
                                    <div className="overflow-x-auto">
                                      <TableExecutor 
                                        config={step.config?.tableConfig}
                                        value={versionData.data}
                                        onChange={() => {}}
                                        disabled={true}
                                        allSteps={instance.steps || []}
                                        allData={instance.data || []}
                                      />
                                    </div>
                                  ) : (
                                    <p className="text-slate-700 font-medium">
                                      {step.type === 'calculation' ? calculateValue(step.config?.formula || '') : (versionData.data.value || '-')}
                                    </p>
                                  )}
                                </div>
                              )}
                              <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between">
                                <p className="text-[10px] text-slate-400">
                                  Submitted by: <span className="font-bold text-slate-600">{versionData.submitted_by_name}</span>
                                </p>
                                {versionData.reason && (
                                  <p className="text-[10px] text-amber-600 italic">
                                    Reason: {versionData.reason as string}
                                  </p>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}

            {/* Final Review Section */}
            {instance.status === 'Work in Process' && instance.steps?.every(s => instance.data?.some(d => d.step_id === s.id)) && (
              <div className="relative pl-10 pt-8">
                <div className="absolute left-0 top-9 w-8 h-8 rounded-full bg-amber-500 text-white flex items-center justify-center z-10 shadow-lg">
                  <ShieldCheck size={18} />
                </div>
                <div className="glass-panel border-amber-200 bg-amber-50/30 p-8 space-y-6">
                  <div>
                    <h3 className="text-xl font-bold text-slate-900">Final Batch Review & Sign-off</h3>
                    <p className="text-sm text-slate-500">All process steps have been completed. Please perform the final review and designate the batch status.</p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="block text-sm font-bold text-slate-700">Final Disposition</label>
                      <select 
                        className="input-field"
                        value={finalStatus}
                        onChange={e => setFinalStatus(e.target.value)}
                      >
                        <option value="Under Review">Pending Review</option>
                        <option value="QA Review">QA Review</option>
                        <option value="Released">Released</option>
                        <option value="Quarantine">Quarantine</option>
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="block text-sm font-bold text-slate-700">Review Comments</label>
                      <textarea 
                        className="input-field min-h-[80px]"
                        placeholder="Enter final review notes..."
                        value={reviewComment}
                        onChange={e => setReviewComment(e.target.value)}
                      />
                    </div>
                  </div>

                  <div className="flex justify-end">
                    <button 
                      onClick={() => openSignature('Approved', { type: 'review', payload: 'Approve' })}
                      className="btn-pharma px-8 py-3 flex items-center gap-2 shadow-lg hover:shadow-pharma-accent/20 transition-all"
                    >
                      <PenTool size={18} /> Sign & Finalize Batch
                      <HelpTooltip text="Perform the final QA sign-off for this batch. This will update the batch status and move it to the selected disposition." guideLink="quality" />
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      <AnimatePresence>
        {editStepId && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[100] flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="glass-panel p-8 max-w-md w-full space-y-6"
            >
              <h2 className="text-2xl font-bold">Edit Submitted Step</h2>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-1">New Value</label>
                  {(() => {
                    const stepDef = instance.steps?.find(s => s.id === editStepId);
                    if (stepDef?.type === 'number') {
                      return (
                        <input 
                          type="number"
                          className="input-field" 
                          value={editValue?.value || ''}
                          onChange={e => setEditValue({ ...editValue, value: e.target.value })}
                        />
                      );
                    } else if (stepDef?.type === 'date') {
                      return (
                        <input 
                          type="datetime-local"
                          className="input-field" 
                          value={editValue?.value || ''}
                          onChange={e => setEditValue({ ...editValue, value: e.target.value })}
                        />
                      );
                    } else if (stepDef?.type === 'dropdown') {
                      return (
                        <select 
                          className="input-field"
                          value={editValue?.value || ''}
                          onChange={e => setEditValue({ ...editValue, value: e.target.value })}
                        >
                          <option value="">Select Option</option>
                          {stepDef.config?.options?.map((opt: string) => (
                            <option key={opt} value={opt}>{opt}</option>
                          ))}
                        </select>
                      );
                    } else if (stepDef?.type === 'multi-field') {
                      return (
                        <div className="space-y-4 max-h-[40vh] overflow-y-auto p-2">
                          {stepDef.config?.fields?.map((field: any) => (
                            <div key={field.id}>
                              <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">{field.name}</label>
                              <input 
                                className="input-field"
                                value={editValue?.[field.id] || ''}
                                onChange={e => setEditValue({ ...editValue, [field.id]: e.target.value })}
                              />
                            </div>
                          ))}
                        </div>
                      );
                    } else if (stepDef?.type === 'table') {
                      return (
                        <div className="border border-slate-100 rounded-xl overflow-hidden scale-[0.8] origin-top">
                          <TableExecutor 
                            config={stepDef.config?.tableConfig}
                            value={editValue}
                            onChange={setEditValue}
                            allSteps={instance.steps || []}
                            allData={instance.data || []}
                          />
                        </div>
                      );
                    }
                    return (
                      <input 
                        className="input-field" 
                        value={editValue?.value || ''}
                        onChange={e => setEditValue({ ...editValue, value: e.target.value })}
                      />
                    );
                  })()}
                </div>
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-1">Reason for Change</label>
                  <textarea 
                    className="input-field" 
                    placeholder="Mandatory justification for GMP compliance..." 
                    value={editReason}
                    onChange={e => setEditReason(e.target.value)}
                  />
                </div>
              </div>
              <div className="flex gap-4">
                <button onClick={() => setEditStepId(null)} className="btn-secondary flex-1">Cancel</button>
                <button 
                  onClick={() => openSignature('Executed', { type: 'edit' })} 
                  disabled={isSubmitting}
                  className="btn-primary flex-1"
                >
                  {isSubmitting ? 'Signing...' : 'Sign & Update Step'}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

const CleaningVerificationModal = ({ isOpen, onClose, equipment, onVerified, user }: { isOpen: boolean, onClose: () => void, equipment: any, onVerified: () => void, user: User }) => {
  const [cleaningAgent, setCleaningAgent] = useState('');
  const [swabResult, setSwabResult] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [showSignature, setShowSignature] = useState(false);

  const handleVerify = async () => {
    if (!cleaningAgent || !swabResult) return toast.error("Please fill all verification details.");
    setShowSignature(true);
  };

  const onSigned = async (signature: string) => {
    setIsSaving(true);
    try {
      await api.post(`/inventory/equipment/verify-cleaning`, {
        id: equipment.id,
        cleaningAgent,
        swabResult,
        signature,
        userId: user.id
      });
      toast.success("Cleaning verified and documented!");
      onVerified();
    } catch (e) {
      toast.error("Failed to verify cleaning.");
    } finally {
      setIsSaving(false);
      setShowSignature(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white rounded-3xl shadow-2xl max-w-lg w-full p-8 space-y-6"
      >
        <div className="flex justify-between items-center">
          <h2 className="text-2xl font-bold text-slate-900">Cleaning Verification</h2>
          <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded-full"><X size={20} /></button>
        </div>

        <div className="p-4 bg-amber-50 border border-amber-100 rounded-2xl flex items-start gap-3">
          <AlertCircle className="text-amber-600 shrink-0" size={20} />
          <p className="text-sm text-amber-800">
            Confirming cleaning for <strong>{equipment.name}</strong>. This action is subject to 21 CFR Part 11 compliance.
          </p>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Cleaning Agent Used</label>
            <input 
              value={cleaningAgent}
              onChange={e => setCleaningAgent(e.target.value)}
              className="input-field" 
              placeholder="e.g., 70% IPA, Purified Water" 
            />
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Swab / Visual Inspection Result</label>
            <select 
              value={swabResult}
              onChange={e => setSwabResult(e.target.value)}
              className="input-field"
            >
              <option value="">-- Select Result --</option>
              <option value="Pass">Pass (Visually Clean & Swab Negative)</option>
              <option value="Fail">Fail (Residue Detected)</option>
            </select>
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Verification Document (Optional)</label>
            <div className="border-2 border-dashed border-slate-200 rounded-2xl p-6 text-center hover:border-pharma-accent transition-all cursor-pointer">
              <Upload className="mx-auto text-slate-400 mb-2" size={24} />
              <p className="text-xs text-slate-500 font-bold">Upload Swab Test Report</p>
            </div>
          </div>
        </div>

        <div className="flex gap-4 pt-4">
          <button onClick={onClose} className="btn-secondary flex-1 py-3">Cancel</button>
          <button 
            onClick={handleVerify} 
            disabled={isSaving}
            className="btn-primary flex-1 py-3 flex items-center justify-center gap-2"
          >
            {isSaving ? 'Processing...' : <><ShieldCheck size={20} /> Verify & Sign</>}
          </button>
        </div>
      </motion.div>

      <ElectronicSignatureModal 
        isOpen={showSignature}
        onClose={() => setShowSignature(false)}
        onSign={onSigned}
        action={`Cleaning Verification for ${equipment.name}`}
      />
    </div>
  );
};

const MaterialMovementModal = ({ isOpen, onClose, material, onMove, user }: { isOpen: boolean, onClose: () => void, material: Material | null, onMove: () => void, user: User }) => {
  const [warehouse, setWarehouse] = useState('');
  const [bin, setBin] = useState('');
  const [status, setStatus] = useState('');
  const [quantity, setQuantity] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (material) {
      setWarehouse(material.warehouse_location || '');
      setBin(material.bin_location || '');
      setStatus(material.status);
      setQuantity(material.quantity);
    }
  }, [material]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!material) return;
    setIsSubmitting(true);
    try {
      const res = await api.post('/inventory/move', {
        materialId: material.id,
        warehouse,
        bin,
        status,
        quantity,
        userId: user.id,
        userRole: user.role
      });
      if (res.status === 200) {
        toast.success('Material moved successfully');
        onMove();
        onClose();
      } else {
        toast.error('Failed to move material');
      }
    } catch (err) {
      toast.error('Error moving material');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isOpen || !material) return null;

  return (
    <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-[250] flex items-center justify-center p-6">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white w-full max-w-md rounded-3xl shadow-2xl overflow-hidden"
      >
        <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-pharma-primary text-white">
          <h2 className="text-xl font-bold">Move Material</h2>
          <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full transition-colors"><X size={24} /></button>
        </div>
        <form onSubmit={handleSubmit} className="p-8 space-y-6">
          <div className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Material</label>
              <p className="font-bold text-slate-900">{material.name} ({material.sku})</p>
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase mb-1">New Warehouse</label>
              <input value={warehouse} onChange={e => setWarehouse(e.target.value)} className="input-field" placeholder="e.g., WH-01" />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase mb-1">New Bin</label>
              <input value={bin} onChange={e => setBin(e.target.value)} className="input-field" placeholder="e.g., BIN-A1" />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase mb-1">New Status</label>
              <select value={status} onChange={e => setStatus(e.target.value)} className="input-field">
                <option>Available</option>
                <option>Quarantined</option>
                <option>Rejected</option>
                <option>Expired</option>
                <option>In Use</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Quantity to Move</label>
              <input type="number" value={quantity} onChange={e => setQuantity(Number(e.target.value))} className="input-field" max={material.quantity} />
            </div>
          </div>
          <button type="submit" disabled={isSubmitting} className="btn-primary w-full py-4">
            {isSubmitting ? 'Moving...' : 'Confirm Movement'}
          </button>
        </form>
      </motion.div>
    </div>
  );
};

const Inventory = ({ user }: { user: User }) => {
  const [data, setData] = useState<{ materials: Material[], equipment: Equipment[] } | null>(null);
  const [activeSubTab, setActiveSubTab] = useState<'materials' | 'equipment'>('materials');
  const [selectedItem, setSelectedItem] = useState<any>(null);
  const [movingMaterial, setMovingMaterial] = useState<Material | null>(null);

  const refresh = () => {
    api.get('/inventory').then(res => res.data).then(setData);
  };

  useEffect(() => {
    refresh();
  }, []);

  const [cleaningEquipment, setCleaningEquipment] = useState<any>(null);

  const updateEquipmentStatus = async (id: number, status: string) => {
    if (!user.permissions?.can_edit_inventory && user.role !== 'Admin') {
      return toast.error("You do not have permission to edit inventory.");
    }
    if (status === 'Cleaned') {
      const equip = data?.equipment.find((e: any) => e.id === id);
      if (equip) setCleaningEquipment(equip);
      return;
    }
    try {
      await api.post('/inventory/equipment/status', { id, status, userId: user.id, userRole: user.role });
      toast.success(`Equipment marked as ${status}`);
      refresh();
    } catch (e) {
      toast.error("Failed to update status");
    }
  };

  const generateLabel = (item: any) => {
    setSelectedItem(item);
  };

  if (!data) return <div className="p-12 text-center text-slate-400">Loading inventory...</div>;

  return (
    <div className="space-y-8">
      <BarcodeModal 
        item={selectedItem} 
        isOpen={!!selectedItem} 
        onClose={() => setSelectedItem(null)} 
      />
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-slate-900">Inventory & Assets</h1>
          <p className="text-sm text-slate-500">Advanced inventory tracking and asset lifecycle management.</p>
        </div>
        <div className="flex bg-slate-100 p-1 rounded-xl self-start md:self-auto">
          <button 
            onClick={() => setActiveSubTab('materials')}
            className={cn("px-4 py-2 rounded-lg text-sm font-bold transition-all", activeSubTab === 'materials' ? "bg-white shadow-sm text-pharma-primary" : "text-slate-500")}
          >
            Materials
          </button>
          <button 
            onClick={() => setActiveSubTab('equipment')}
            className={cn("px-4 py-2 rounded-lg text-sm font-bold transition-all", activeSubTab === 'equipment' ? "bg-white shadow-sm text-pharma-primary" : "text-slate-500")}
          >
            Equipment
          </button>
        </div>
      </header>

      {activeSubTab === 'materials' ? (
        <div className="glass-panel overflow-x-auto">
          <table className="w-full text-left border-collapse min-w-[800px]">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200">
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Material / SKU</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Lot / Expiry</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Stock Level</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Status</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {(data.materials || []).map(m => (
                <tr key={m.id} className="hover:bg-slate-50/50 transition-all">
                  <td className="px-6 py-4">
                    <p className="font-bold text-slate-800">{m.name}</p>
                    <p className="text-xs text-slate-400 font-mono">{m.sku}</p>
                  </td>
                  <td className="px-6 py-4">
                    <p className="text-sm text-slate-600 font-mono">{m.lot_number}</p>
                    <p className={cn("text-[10px] font-bold uppercase", new Date(m.expiry_date) < new Date() ? "text-red-500" : "text-slate-400")}>
                      Exp: {m.expiry_date}
                    </p>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-bold text-slate-700">{m.quantity} {m.unit}</span>
                      {m.quantity <= m.reorder_point && (
                        <span className="px-1.5 py-0.5 bg-amber-100 text-amber-700 rounded text-[10px] font-bold">LOW</span>
                      )}
                    </div>
                    <div className="w-24 h-1.5 bg-slate-100 rounded-full mt-1 overflow-hidden">
                      <div 
                        className={cn("h-full transition-all", m.quantity <= m.reorder_point ? "bg-amber-500" : "bg-emerald-500")}
                        style={{ width: `${Math.min(100, (m.quantity / (m.reorder_point * 2)) * 100)}%` }}
                      />
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className={cn(
                      "px-2 py-1 rounded text-[10px] font-bold uppercase",
                      m.status === 'Available' || m.status === 'Approved' ? "bg-emerald-100 text-emerald-700" : "bg-slate-100 text-slate-700"
                    )}>
                      {m.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <button 
                        onClick={() => setMovingMaterial(m)} 
                        className="p-2 text-slate-400 hover:text-pharma-accent transition-colors" 
                        title="Move Material"
                      >
                        <ArrowRightLeft size={18} />
                      </button>
                      <button 
                        onClick={() => generateLabel(m)} 
                        className="p-2 text-slate-400 hover:text-pharma-accent transition-colors" 
                        title="Print Barcode"
                      >
                        <QrCode size={18} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {(data.equipment || []).map(e => (
            <div key={e.id} className="glass-panel p-6 space-y-4">
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="font-bold text-slate-800">{e.name}</h3>
                  <p className="text-xs text-slate-400 font-mono">{e.asset_id}</p>
                </div>
                <span className={cn(
                  "px-2 py-1 rounded text-[10px] font-bold uppercase",
                  e.status === 'Cleaned' && "bg-emerald-100 text-emerald-700",
                  e.status === 'In Use' && "bg-blue-100 text-blue-700",
                  e.status === 'Dirty' && "bg-amber-100 text-amber-700",
                  e.status === 'Out of Service' && "bg-red-100 text-red-700"
                )}>
                  {e.status}
                </span>
              </div>
              
              <div className="grid grid-cols-2 gap-2">
                {['Cleaned', 'In Use', 'Dirty', 'Out of Service'].map(s => (
                  <button 
                    key={s}
                    onClick={() => updateEquipmentStatus(e.id, s)}
                    className={cn(
                      "py-1.5 text-[10px] font-bold border rounded-lg transition-all",
                      e.status === s ? "bg-slate-800 text-white border-slate-800" : "text-slate-500 border-slate-200 hover:border-slate-400"
                    )}
                  >
                    {s}
                  </button>
                ))}
              </div>

              <div className="pt-4 border-t border-slate-50 space-y-2">
                <div className="flex justify-between text-[10px]">
                  <span className="text-slate-400 uppercase font-bold">Last Calibration</span>
                  <span className="text-slate-700 font-mono">{e.last_calibration}</span>
                </div>
                <div className="flex justify-between text-[10px]">
                  <span className="text-slate-400 uppercase font-bold">Next Calibration</span>
                  <span className={cn("font-mono", new Date(e.next_calibration) < new Date() ? "text-red-500 font-bold" : "text-slate-700")}>
                    {e.next_calibration}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
      <CleaningVerificationModal 
        isOpen={!!cleaningEquipment} 
        onClose={() => setCleaningEquipment(null)} 
        equipment={cleaningEquipment} 
        onVerified={() => {
          setCleaningEquipment(null);
          refresh();
        }}
        user={user}
      />
      <MaterialMovementModal 
        isOpen={!!movingMaterial} 
        onClose={() => setMovingMaterial(null)} 
        material={movingMaterial} 
        onMove={refresh}
        user={user}
      />
    </div>
  );
};

import { CustomizableDashboard } from './components/CustomizableDashboard';
import { WarehouseOperations } from './components/WarehouseOperations';

const SupplyChain = ({ user }: { user: User }) => {
  const [activeTab, setActiveTab] = useState<'warehouses' | 'boms' | 'purchasing' | 'shipping' | 'scheduling' | 'warehouse-ops'>('warehouses');
  const [data, setData] = useState<any>(null);
  const [isSchedulingModalOpen, setIsSchedulingModalOpen] = useState(false);

  useEffect(() => {
    const endpoints: Record<string, string> = {
      warehouses: '/warehouses',
      boms: '/boms',
      purchasing: '/purchase-orders',
      shipping: '/shipments',
      scheduling: '/instances?status=Scheduled'
    };
    api.get(endpoints[activeTab]).then(res => res.data).then(setData);
  }, [activeTab]);

  return (
    <div className="space-y-8">
      <header>
        <h1 className="text-3xl font-bold text-slate-900">Supply Chain Management</h1>
        <p className="text-slate-500">Manage warehouses, BOMs, procurement, and logistics.</p>
      </header>

      <div className="flex border-b border-slate-200 gap-8">
        {[
          { id: 'warehouses', label: 'Warehouses', icon: Warehouse },
          { id: 'boms', label: 'BOMs', icon: Layers },
          { id: 'purchasing', label: 'Purchasing', icon: ShoppingCart },
          { id: 'shipping', label: 'Shipping', icon: Truck },
          { id: 'scheduling', label: 'Scheduling', icon: Clock },
          { id: 'warehouse-ops', label: 'Warehouse Ops', icon: Package },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={cn(
              "flex items-center gap-2 pb-4 text-sm font-bold transition-all border-b-2",
              activeTab === tab.id ? "border-pharma-accent text-pharma-primary" : "border-transparent text-slate-400 hover:text-slate-600"
            )}
          >
            <tab.icon size={18} />
            {tab.label}
          </button>
        ))}
      </div>

      <div className="glass-panel p-6 min-h-[400px]">
        {!data ? (
          <div className="h-full flex items-center justify-center text-slate-400">Loading {activeTab}...</div>
        ) : (
          <div className="space-y-6">
            {activeTab === 'warehouses' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {(data?.warehouses || []).map((wh: WarehouseType) => (
                  <div key={wh.id} className="p-6 border border-slate-100 rounded-2xl space-y-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="text-lg font-bold text-slate-800">{wh.name}</h3>
                        <p className="text-sm text-slate-500">{wh.location}</p>
                      </div>
                      <span className="px-2 py-1 bg-emerald-100 text-emerald-700 rounded text-[10px] font-bold uppercase">Active</span>
                    </div>
                    <div className="space-y-2">
                      <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Bin Locations</p>
                      <div className="flex flex-wrap gap-2">
                        {(data?.bins || []).filter((b: Bin) => b.warehouse_id === wh.id).map((bin: Bin) => (
                          <div key={bin.id} className={cn(
                            "px-3 py-1.5 rounded-lg text-xs font-mono border",
                            bin.is_allergen_zone ? "bg-amber-50 border-amber-200 text-amber-700" : "bg-slate-50 border-slate-200 text-slate-600"
                          )}>
                            {bin.name} ({bin.zone})
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {activeTab === 'boms' && (
              <div className="space-y-4">
                {(Array.isArray(data) ? data : []).map((bom: BOM) => (
                  <div key={bom.id} className="p-4 border border-slate-100 rounded-xl flex items-center justify-between hover:bg-slate-50 transition-all cursor-pointer">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 bg-indigo-50 text-indigo-600 rounded-lg flex items-center justify-center">
                        <Layers size={20} />
                      </div>
                      <div>
                        <p className="font-bold text-slate-800">{bom.product_name}</p>
                        <p className="text-xs text-slate-400">Version {bom.version} • Created {new Date(bom.created_at).toLocaleDateString()}</p>
                      </div>
                    </div>
                    <span className="px-2 py-1 bg-blue-100 text-blue-700 rounded text-[10px] font-bold uppercase">{bom.status}</span>
                  </div>
                ))}
              </div>
            )}

            {activeTab === 'purchasing' && (
              <div className="space-y-4">
                {(Array.isArray(data) ? data : []).map((po: PurchaseOrder) => (
                  <div key={po.id} className="p-4 border border-slate-100 rounded-xl flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 bg-emerald-50 text-emerald-600 rounded-lg flex items-center justify-center">
                        <ShoppingCart size={20} />
                      </div>
                      <div>
                        <p className="font-bold text-slate-800">{po.po_number}</p>
                        <p className="text-xs text-slate-400">{po.vendor_name} • ${po.total_amount?.toLocaleString() || '0'}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className={cn(
                        "px-2 py-1 rounded text-[10px] font-bold uppercase",
                        po.status === 'Open' ? "bg-blue-100 text-blue-700" : "bg-slate-100 text-slate-700"
                      )}>
                        {po.status}
                      </span>
                      <button className="p-2 text-slate-400 hover:text-pharma-accent"><Eye size={18} /></button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {activeTab === 'shipping' && (
              <div className="space-y-4">
                {(Array.isArray(data) ? data : []).map((shp: Shipment) => (
                  <div key={shp.id} className="p-4 border border-slate-100 rounded-xl flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 bg-slate-100 text-slate-600 rounded-lg flex items-center justify-center">
                        <Truck size={20} />
                      </div>
                      <div>
                        <p className="font-bold text-slate-800">{shp.shipment_number}</p>
                        <p className="text-xs text-slate-400">{shp.customer_name} • {shp.carrier}</p>
                      </div>
                    </div>
                    <span className={cn(
                      "px-2 py-1 rounded text-[10px] font-bold uppercase",
                      shp.status === 'Shipped' ? "bg-emerald-100 text-emerald-700" : "bg-amber-100 text-amber-700"
                    )}>
                      {shp.status}
                    </span>
                  </div>
                ))}
              </div>
            )}

            {activeTab === 'scheduling' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h3 className="text-lg font-bold">Production Schedule</h3>
                  <button onClick={() => setIsSchedulingModalOpen(true)} className="btn-primary flex items-center gap-2">
                    <Plus size={18} /> Schedule Batch
                    <HelpTooltip text="Schedule a new production batch for a released workflow. Assign batch numbers and scheduled dates." guideLink="scheduling" />
                  </button>
                </div>
                <div className="space-y-4">
                  {(Array.isArray(data) ? data : []).map((batch: Instance) => (
                    <div key={batch.id} className="p-4 border border-slate-100 rounded-xl flex items-center justify-between bg-white shadow-sm">
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 bg-blue-50 text-blue-600 rounded-lg flex items-center justify-center">
                          <Clock size={20} />
                        </div>
                        <div>
                          <p className="font-bold text-slate-800">{batch.batch_number}</p>
                          <p className="text-xs text-slate-500">{batch.workflow_name} • {batch.product_name}</p>
                          <p className="text-xs text-slate-400 mt-1">Scheduled: {batch.scheduled_at ? new Date(batch.scheduled_at).toLocaleString() : 'N/A'}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="px-2 py-1 bg-blue-100 text-blue-700 rounded text-[10px] font-bold uppercase">Scheduled</span>
                        <button className="p-2 text-slate-400 hover:text-pharma-accent"><Edit3 size={18} /></button>
                      </div>
                    </div>
                  ))}
                  {(Array.isArray(data) ? data : []).length === 0 && (
                    <div className="text-center py-12 text-slate-400 italic">No batches scheduled.</div>
                  )}
                </div>
              </div>
            )}
            {activeTab === 'warehouse-ops' && (
              <WarehouseOperations user={user} />
            )}
          </div>
        )}
      </div>
      <BatchSchedulingModal 
        isOpen={isSchedulingModalOpen} 
        onClose={() => setIsSchedulingModalOpen(false)} 
        onSchedule={() => api.get('/instances?status=Scheduled').then(res => res.data).then(setData)}
      />
    </div>
  );
};

const BatchSchedulingModal = ({ isOpen, onClose, onSchedule }: { isOpen: boolean, onClose: () => void, onSchedule: () => void }) => {
  const [workflows, setWorkflows] = useState<Workflow[]>([]);
  const [equipment, setEquipment] = useState<Equipment[]>([]);
  const [selectedWorkflow, setSelectedWorkflow] = useState<number | null>(null);
  const [selectedEquipment, setSelectedEquipment] = useState<number | null>(null);
  const [batchNumber, setBatchNumber] = useState('');
  const [productName, setProductName] = useState('');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [plant, setPlant] = useState('Plant 01');
  const [building, setBuilding] = useState('Building A');
  const [room, setRoom] = useState('Room 101');
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (isOpen) {
      api.get('/workflows?status=Released').then(res => res.data).then(setWorkflows);
      api.get('/equipment').then(res => res.data).then(setEquipment);
      setBatchNumber(`BN-${Date.now().toString().slice(-6)}`);
    }
  }, [isOpen]);

  const handleSchedule = async () => {
    // Validation removed as per user request to allow blank fields
    setIsSaving(true);
    try {
      const scheduledAt = date && time ? `${date}T${time}` : null;
      await api.post('/instances', { 
        workflowId: selectedWorkflow || 0, 
        batchNumber, 
        productName, 
        scheduledAt,
        equipmentId: selectedEquipment || 0,
        plant,
        building,
        room,
        status: 'Scheduled'
      });
      toast.success("Batch scheduled successfully!");
      onSchedule();
      onClose();
    } catch (e) {
      toast.error("Failed to schedule batch.");
    } finally {
      setIsSaving(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white rounded-3xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-8 space-y-6"
      >
        <div className="flex justify-between items-center">
          <h2 className="text-2xl font-bold text-slate-900">Schedule Production Batch</h2>
          <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded-full"><X size={20} /></button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Select EBR (Released)</label>
              <select 
                className="input-field"
                value={selectedWorkflow || ''}
                onChange={e => {
                  const id = Number(e.target.value);
                  setSelectedWorkflow(id);
                  const wf = workflows.find(w => w.id === id);
                  if (wf) setProductName(wf.name);
                }}
              >
                <option value="">-- Select Workflow --</option>
                {(Array.isArray(workflows) ? workflows : []).map(wf => <option key={wf.id} value={wf.id}>{wf.name} (v{wf.version})</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Batch Number</label>
              <input value={batchNumber} onChange={e => setBatchNumber(e.target.value)} className="input-field" />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Product Name</label>
              <input value={productName} onChange={e => setProductName(e.target.value)} className="input-field" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Date</label>
                <input type="date" value={date} onChange={e => setDate(e.target.value)} className="input-field" />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Time</label>
                <input type="time" value={time} onChange={e => setTime(e.target.value)} className="input-field" />
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Plant</label>
              <select value={plant} onChange={e => setPlant(e.target.value)} className="input-field">
                <option>Plant 01</option>
                <option>Plant 02</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Building</label>
              <select value={building} onChange={e => setBuilding(e.target.value)} className="input-field">
                <option>Building A</option>
                <option>Building B</option>
                <option>Building C</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Room</label>
              <input value={room} onChange={e => setRoom(e.target.value)} className="input-field" placeholder="e.g., Room 101" />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Primary Equipment</label>
              <select 
                className="input-field"
                value={selectedEquipment || ''}
                onChange={e => setSelectedEquipment(Number(e.target.value))}
              >
                <option value="">-- Select Equipment --</option>
                {Array.isArray(equipment) && equipment.map(e => (
                  <option key={e.id} value={e.id} disabled={e.status !== 'Cleaned'}>
                    {e.name} ({e.status})
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        <div className="flex gap-4 pt-4">
          <button onClick={onClose} className="btn-secondary flex-1 py-3">Cancel</button>
          <button 
            onClick={handleSchedule} 
            disabled={isSaving}
            className="btn-primary flex-1 py-3 flex items-center justify-center gap-2"
          >
            {isSaving ? 'Scheduling...' : <><Calendar size={20} /> Schedule Batch</>}
          </button>
        </div>
      </motion.div>
    </div>
  );
};

import { QARelease } from './components/QARelease';

const QualityQC = ({ user }: { user: User }) => {
  const [activeTab, setActiveTab] = useState<'inspections' | 'maintenance' | 'deviations' | 'qa-release'>('inspections');
  const [data, setData] = useState<any>(null);

  useEffect(() => {
    const endpoints: Record<string, string> = {
      inspections: '/inspections',
      maintenance: '/maintenance',
      deviations: '/deviations'
    };
    if (endpoints[activeTab]) {
      api.get(endpoints[activeTab]).then(res => res.data).then(setData).catch(() => setData([]));
    } else {
      setData([]);
    }
  }, [activeTab]);

  return (
    <div className="space-y-8">
      <header>
        <h1 className="text-3xl font-bold text-slate-900">Quality & Compliance</h1>
        <p className="text-slate-500">QC inspections, equipment maintenance, deviations, and validation records.</p>
      </header>

      <div className="flex border-b border-slate-200 gap-8 overflow-x-auto custom-scrollbar">
        {[
          { id: 'inspections', label: 'QC Inspections', icon: ShieldCheck },
          { id: 'maintenance', label: 'Maintenance Logs', icon: Wrench },
          { id: 'deviations', label: 'Deviations & CAPA', icon: AlertTriangle },
          { id: 'qa-release', label: 'QA Release', icon: CheckCircle2 },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={cn(
              "flex items-center gap-2 pb-4 text-sm font-bold transition-all border-b-2 whitespace-nowrap",
              activeTab === tab.id ? "border-pharma-accent text-pharma-primary" : "border-transparent text-slate-400 hover:text-slate-600"
            )}
          >
            <tab.icon size={18} />
            {tab.label}
          </button>
        ))}
      </div>

      <div className="glass-panel p-6 min-h-[400px]">
        {!data ? (
          <div className="h-full flex items-center justify-center text-slate-400">Loading {activeTab}...</div>
        ) : (
          <div className="space-y-4">
            {activeTab === 'inspections' ? (
              (Array.isArray(data) ? data : []).map((insp: Inspection) => (
                <div key={insp.id} className="p-4 border border-slate-100 rounded-xl flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className={cn(
                      "w-10 h-10 rounded-lg flex items-center justify-center",
                      insp.status === 'Passed' ? "bg-emerald-50 text-emerald-600" : "bg-red-50 text-red-600"
                    )}>
                      <ShieldCheck size={20} />
                    </div>
                    <div>
                      <p className="font-bold text-slate-800">{insp.target_type} Inspection</p>
                      <p className="text-xs text-slate-500">Inspector: {insp.inspector_name} • {new Date(insp.created_at).toLocaleDateString()}</p>
                      <p className="text-xs text-slate-400 italic mt-1">"{insp.results}"</p>
                    </div>
                  </div>
                  <span className={cn(
                    "px-2 py-1 rounded text-[10px] font-bold uppercase",
                    insp.status === 'Passed' ? "bg-emerald-100 text-emerald-700" : "bg-red-100 text-red-700"
                  )}>
                    {insp.status}
                  </span>
                </div>
              ))
            ) : activeTab === 'maintenance' ? (
              (Array.isArray(data) ? data : []).map((log: MaintenanceLog) => (
                <div key={log.id} className="p-4 border border-slate-100 rounded-xl flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 bg-slate-100 text-slate-600 rounded-lg flex items-center justify-center">
                      <Wrench size={20} />
                    </div>
                    <div>
                      <p className="font-bold text-slate-800">{log.equipment_name}</p>
                      <p className="text-xs text-slate-500">{log.type} • Performed by {log.performed_by}</p>
                      <p className="text-xs text-slate-400 mt-1">{log.description}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-[10px] font-bold text-slate-400 uppercase">Next Due</p>
                    <p className="text-sm font-mono text-slate-700">{log.next_due_date}</p>
                  </div>
                </div>
              ))
            ) : activeTab === 'deviations' ? (
              <div className="space-y-4">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-lg font-bold text-slate-800">Deviations & CAPA</h3>
                  <button className="btn-primary flex items-center gap-2 text-sm py-2">
                    <Plus size={16} /> Log Deviation
                  </button>
                </div>
                {data.length === 0 ? (
                  <div className="text-center py-12 text-slate-500">
                    <AlertTriangle size={48} className="mx-auto mb-4 text-slate-300" />
                    <p className="text-lg font-medium">No deviations found.</p>
                    <p className="text-sm">All processes are running within acceptable parameters.</p>
                  </div>
                ) : (
                  (Array.isArray(data) ? data : []).map((dev: any) => (
                    <div key={dev.id} className="p-4 border border-slate-100 rounded-xl flex items-start justify-between bg-white shadow-sm hover:shadow-md transition-all">
                      <div className="flex items-start gap-4">
                        <div className={cn(
                          "w-10 h-10 rounded-lg flex items-center justify-center shrink-0 mt-1",
                          dev.severity === 'Critical' ? "bg-red-50 text-red-600" : 
                          dev.severity === 'Major' ? "bg-amber-50 text-amber-600" : 
                          "bg-blue-50 text-blue-600"
                        )}>
                          <AlertTriangle size={20} />
                        </div>
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-mono text-xs font-bold text-slate-500">{dev.id}</span>
                            <span className={cn(
                              "px-2 py-0.5 rounded text-[10px] font-bold uppercase",
                              dev.status === 'Open' ? "bg-amber-100 text-amber-700" : 
                              dev.status === 'Under Investigation' ? "bg-blue-100 text-blue-700" :
                              "bg-emerald-100 text-emerald-700"
                            )}>
                              {dev.status}
                            </span>
                            <span className={cn(
                              "px-2 py-0.5 rounded text-[10px] font-bold uppercase border",
                              dev.severity === 'Critical' ? "border-red-200 text-red-600" : 
                              dev.severity === 'Major' ? "border-amber-200 text-amber-600" : 
                              "border-blue-200 text-blue-600"
                            )}>
                              {dev.severity}
                            </span>
                          </div>
                          <p className="font-bold text-slate-800">{dev.title}</p>
                          <p className="text-xs text-slate-500 mt-1">Reported by {dev.reported_by} on {new Date(dev.created_at).toLocaleDateString()}</p>
                          <p className="text-sm text-slate-600 mt-2 line-clamp-2">{dev.description}</p>
                          
                          {dev.capa_id && (
                            <div className="mt-3 p-2 bg-slate-50 rounded border border-slate-100 flex items-center gap-2">
                              <ShieldCheck size={14} className="text-emerald-600" />
                              <span className="text-xs font-medium text-slate-700">Linked CAPA: <span className="font-mono">{dev.capa_id}</span></span>
                            </div>
                          )}
                        </div>
                      </div>
                      <button className="btn-secondary text-xs py-1.5 px-3 whitespace-nowrap">
                        View Details
                      </button>
                    </div>
                  ))
                )}
              </div>
            ) : (
              <QARelease user={user} />
            )}
          </div>
        )}
      </div>
    </div>
  );
};

const Reports = ({ user, onOpenInstance }: { user: User, onOpenInstance: (id: number) => void }) => {
  const [instances, setInstances] = useState<Instance[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [isLoading, setIsLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [activeTab, setActiveTab] = useState<'records' | 'cost'>('records');

  useEffect(() => {
    setIsLoading(true);
    api.get(`/instances?page=${page}&limit=50`)
      .then(res => res.data)
      .then(data => {
        setInstances(data.data);
        setTotal(data.total);
      })
      .finally(() => setIsLoading(false));
  }, [page]);

  const filtered = (Array.isArray(instances) ? instances : []).filter(inst => {
    const pName = inst.product_name || '';
    const bNum = inst.batch_number || '';
    const matchesSearch = pName.toLowerCase().includes(search.toLowerCase()) || 
                         bNum.toLowerCase().includes(search.toLowerCase());
    const matchesDate = (!dateFrom || new Date(inst.created_at) >= new Date(dateFrom)) &&
                       (!dateTo || new Date(inst.created_at) <= new Date(dateTo));
    return matchesSearch && matchesDate;
  });

  const exportExcel = () => {
    const today = new Date().toISOString().split('T')[0];
    const dataToExport = (filtered || []).length > 0 ? filtered : [{}];
    const ws = XLSX.utils.json_to_sheet(dataToExport.map(i => ({
      'Batch Number': i.batch_number || 'N/A',
      'Product': i.product_name || 'N/A',
      'Workflow': i.workflow_name || 'N/A',
      'Status': i.status || 'N/A',
      'Started By': i.creator_name || 'N/A',
      'Created At': i.created_at ? new Date(i.created_at).toLocaleString() : 'N/A',
      'Updated At': i.updated_at ? new Date(i.updated_at).toLocaleString() : 'N/A'
    })));
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Batch Records");
    XLSX.writeFile(wb, `Batch_Records_Report_${today}.xlsx`);
  };

  return (
    <div className="space-y-8">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Reports & Analytics</h1>
          <p className="text-slate-500">Generate and export batch record reports.</p>
        </div>
        <div className="flex gap-4">
          <div className="flex bg-slate-100 p-1 rounded-xl">
            <button 
              onClick={() => setActiveTab('records')}
              className={cn("px-4 py-2 rounded-lg text-sm font-bold transition-all", activeTab === 'records' ? "bg-white shadow-sm text-pharma-primary" : "text-slate-500")}
            >
              Batch Records
            </button>
            <button 
              onClick={() => setActiveTab('cost')}
              className={cn("px-4 py-2 rounded-lg text-sm font-bold transition-all", activeTab === 'cost' ? "bg-white shadow-sm text-pharma-primary" : "text-slate-500")}
            >
              Cost Analysis
            </button>
          </div>
          <button onClick={exportExcel} className="btn-primary flex items-center gap-2">
            <FileSpreadsheet size={20} /> Export to Excel
          </button>
        </div>
      </header>

      {activeTab === 'records' ? (
        <>
          <div className="glass-panel p-6 grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Search Records</label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                <input 
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                  className="input-field pl-10" 
                  placeholder="Batch # or Product..." 
                />
              </div>
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase mb-1">From Date</label>
              <input type="date" value={dateFrom} onChange={e => setDateFrom(e.target.value)} className="input-field" />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase mb-1">To Date</label>
              <input type="date" value={dateTo} onChange={e => setDateTo(e.target.value)} className="input-field" />
            </div>
          </div>

          {isLoading ? (
            <div className="space-y-4">
              {[1,2,3,4,5].map(i => <Skeleton key={i} className="h-16" />)}
            </div>
          ) : (
            <>
              <div className="glass-panel overflow-hidden">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200">
                      <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Batch Number</th>
                      <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Product</th>
                      <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Status</th>
                      <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Created At</th>
                      <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filtered.map((inst) => (
                      <tr key={inst.id} className="hover:bg-slate-50/50 transition-all">
                        <td className="px-6 py-4 font-bold text-slate-900">{inst.batch_number}</td>
                        <td className="px-6 py-4 text-sm text-slate-600">{inst.product_name}</td>
                        <td className="px-6 py-4">
                          <span className={cn(
                            "px-2 py-1 rounded text-[10px] font-bold uppercase",
                            getStatusColor(inst.status)
                          )}>
                            {inst.status}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-sm text-slate-500">{new Date(inst.created_at).toLocaleDateString()}</td>
                        <td className="px-6 py-4 text-right">
                          <button 
                            onClick={() => onOpenInstance(inst.id)}
                            className="text-pharma-primary hover:underline text-xs font-bold"
                          >
                            View Record
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <Pagination current={page} total={total} limit={50} onPageChange={setPage} />
            </>
          )}
        </>
      ) : (
        <CostAnalysis />
      )}
    </div>
  );
};
const AuditTrail = () => {
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [isLoading, setIsLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [actionFilter, setActionFilter] = useState('all');
  const [selectedLog, setSelectedLog] = useState<AuditLog | null>(null);

  useEffect(() => {
    setIsLoading(true);
    api.get(`/audit?page=${page}&limit=50`)
      .then(res => res.data)
      .then(data => {
        setLogs(data.data);
        setTotal(data.total);
      })
      .finally(() => setIsLoading(false));
  }, [page]);

  const actions = ['all', ...Array.from(new Set((Array.isArray(logs) ? logs : []).map(l => String(l.action))))];

  const filtered = (Array.isArray(logs) ? logs : []).filter(l => {
    const matchesSearch = l.details.toLowerCase().includes(search.toLowerCase()) || 
                         l.user_name.toLowerCase().includes(search.toLowerCase());
    const matchesAction = actionFilter === 'all' || l.action === actionFilter;
    return matchesSearch && matchesAction;
  });

  const exportPDF = () => {
    const doc = new jsPDF();
    const today = new Date().toISOString().split('T')[0];
    doc.text("System Audit Trail", 14, 15);
    autoTable(doc, {
      startY: 20,
      head: [['Timestamp', 'User', 'Role', 'Action', 'Step', 'Reason']],
      body: (filtered || []).map(l => [
        l.timestamp ? new Date(l.timestamp).toLocaleString() : 'N/A',
        l.user_name || 'N/A',
        l.user_role || '-',
        l.details || 'N/A',
        l.step_number || '-',
        l.reason || '-'
      ]),
    });
    doc.save(`Audit_Trail_${today}.pdf`);
  };

  return (
    <div className="space-y-6">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">System Audit Trail</h1>
          <p className="text-slate-500">Traceable record of all system modifications and workflow actions.</p>
        </div>
        <button onClick={exportPDF} className="btn-secondary flex items-center gap-2">
          <Download size={18} /> Export PDF
        </button>
      </header>

      <div className="glass-panel p-6 grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Search Logs</label>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input 
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="input-field pl-10" 
              placeholder="Search by user or action..." 
            />
          </div>
        </div>
        <div>
          <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Filter by Action</label>
          <select 
            value={actionFilter}
            onChange={e => setActionFilter(e.target.value)}
            className="input-field capitalize"
          >
            {actions.map((a: string) => <option key={a} value={a}>{a.replace(/_/g, ' ')}</option>)}
          </select>
        </div>
      </div>

      {isLoading ? (
        <div className="space-y-4">
          {[1,2,3,4,5].map(i => <Skeleton key={i} className="h-16" />)}
        </div>
      ) : (
        <>
          <div className="glass-panel overflow-hidden">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200">
                  <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Timestamp</th>
                  <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">User</th>
                  <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Action</th>
                  <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Step</th>
                  <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Reason</th>
                  <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase text-right">Details</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filtered.map((log) => (
                  <tr key={log.id} className="hover:bg-slate-50/50 transition-all">
                    <td className="px-6 py-4 text-sm font-mono text-slate-500">{new Date(log.timestamp).toLocaleString()}</td>
                    <td className="px-6 py-4">
                      <p className="font-bold text-slate-800 text-sm">{log.user_name}</p>
                      <p className="text-[10px] text-slate-400 uppercase">{log.user_role}</p>
                    </td>
                    <td className="px-6 py-4">
                      <span className="px-2 py-1 bg-slate-100 rounded text-[10px] font-bold uppercase tracking-tight">
                        {log.action.replace(/_/g, ' ')}
                      </span>
                      <p className="text-xs text-slate-600 mt-1">{log.details}</p>
                    </td>
                    <td className="px-6 py-4 text-sm text-slate-500">{log.step_number || '-'}</td>
                    <td className="px-6 py-4 text-sm text-slate-500 italic">{log.reason || '-'}</td>
                    <td className="px-6 py-4 text-right">
                      {(log.old_value || log.new_value) && (
                        <button 
                          onClick={() => setSelectedLog(log)}
                          className="text-pharma-accent hover:underline text-xs font-bold"
                        >
                          View Diff
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <Pagination current={page} total={total} limit={50} onPageChange={setPage} />
        </>
      )}

      <AnimatePresence>
        {selectedLog && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[200] flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="glass-panel p-8 max-w-2xl w-full space-y-6"
            >
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold">Audit Detail</h2>
                <button onClick={() => setSelectedLog(null)} className="p-2 hover:bg-slate-100 rounded-full">
                  <X size={20} />
                </button>
              </div>
              
              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-2">
                  <p className="text-xs font-bold text-slate-500 uppercase">Old Value</p>
                  <div className="p-4 bg-red-50 text-red-700 rounded-xl font-mono text-xs overflow-auto max-h-64 whitespace-pre-wrap border border-red-100">
                    {selectedLog.old_value ? (
                      (() => {
                        try {
                          return JSON.stringify(JSON.parse(selectedLog.old_value), null, 2);
                        } catch {
                          return selectedLog.old_value;
                        }
                      })()
                    ) : 'None'}
                  </div>
                </div>
                <div className="space-y-2">
                  <p className="text-xs font-bold text-slate-500 uppercase">New Value</p>
                  <div className="p-4 bg-emerald-50 text-emerald-700 rounded-xl font-mono text-xs overflow-auto max-h-64 whitespace-pre-wrap border border-emerald-100">
                    {selectedLog.new_value ? (
                      (() => {
                        try {
                          return JSON.stringify(JSON.parse(selectedLog.new_value), null, 2);
                        } catch {
                          return selectedLog.new_value;
                        }
                      })()
                    ) : 'None'}
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-100 flex justify-between text-sm text-slate-500">
                <span>Action: {selectedLog.action}</span>
                <span>Reason: {selectedLog.reason || 'N/A'}</span>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

const Login = ({ onLogin }: { onLogin: (user: User, token: string) => void }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [showReset, setShowReset] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');
    try {
      const res = await api.post('/auth/login', { username, password, companySubdomain: 'demo' });
      if (res.status === 200) {
        const data = res.data;
        onLogin(data.user, data.token);
      } else {
        setError(res.data.error || 'Invalid credentials');
      }
    } catch (err) {
      setError('Connection error');
    } finally {
      setIsLoading(false);
    }
  };

  if (showReset) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-pharma-bg p-6">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="w-full max-w-md glass-panel p-8"
        >
          <PasswordReset onBack={() => setShowReset(false)} />
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-pharma-bg p-6">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-md glass-panel p-8 space-y-8"
      >
        <div className="text-center">
          <div className="w-16 h-16 bg-pharma-primary rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-xl shadow-pharma-primary/20">
            <FileText className="text-white w-8 h-8" />
          </div>
          <h1 className="text-2xl font-bold text-slate-900">PharmaFlow EBR</h1>
          <p className="text-slate-500">Electronic Batch Record Management System</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-bold text-slate-700 mb-1">Username</label>
            <input 
              value={username}
              onChange={e => setUsername(e.target.value)}
              className="input-field" 
              placeholder="e.g., admin" 
              required
            />
          </div>
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block text-sm font-bold text-slate-700">Password</label>
              <button 
                type="button"
                onClick={() => setShowReset(true)}
                className="text-xs font-bold text-pharma-accent hover:underline"
              >
                Forgot Password?
              </button>
            </div>
            <input 
              type="password"
              value={password}
              onChange={e => setPassword(e.target.value)}
              className="input-field" 
              placeholder="••••••••" 
            />
          </div>
          {error && <p className="text-red-500 text-sm font-medium">{error}</p>}
          <button type="submit" className="btn-primary w-full py-3 text-lg mt-4">
            Sign In
          </button>
        </form>

        <div className="pt-6 border-t border-slate-100">
          <p className="text-xs text-center text-slate-400 mb-4">Demo Credentials:</p>
          <div className="grid grid-cols-2 gap-2">
            {[
              { u: 'admin', p: 'Admin_Pharma_99!_Secure', r: 'Admin' },
              { u: 'operator', p: 'Operator_Pharma_77!_Work', r: 'Operator' },
              { u: 'reviewer', p: 'Reviewer_Pharma_55!_Check', r: 'Reviewer' },
              { u: 'qa', p: 'QA_Pharma_33!_Approve', r: 'QA' }
            ].map(cred => (
              <button 
                key={cred.u}
                onClick={() => { setUsername(cred.u); setPassword(cred.p); }}
                className="p-2 text-[10px] bg-slate-50 border border-slate-100 rounded-lg hover:bg-slate-100 text-left"
              >
                <span className="font-bold">{cred.r}:</span> {cred.u}/{cred.p}
              </button>
            ))}
          </div>
        </div>
      </motion.div>
    </div>
  );
};

// --- Main App ---

export default function App() {
  const [user, setUser] = useState<User | null>(null);

  // --- AI Error Reporting Pipeline ---
  useEffect(() => {
    const reportError = async (error: any, stack?: string, source: string = 'frontend') => {
      try {
        const errorMsg = error?.message || String(error);
        
        // Ignore benign Vite WebSocket errors and common network errors, and rate limits
        if (
          errorMsg.includes('failed to connect to websocket') ||
          errorMsg.includes('closed without opened') ||
          errorMsg.includes('WebSocket connection to') ||
          errorMsg.includes('NetworkError when attempting to fetch resource') ||
          errorMsg.includes('Failed to fetch') ||
          errorMsg.includes('Load failed') ||
          errorMsg.includes('429') ||
          errorMsg.includes('Too many requests')
        ) {
          return;
        }

        const errorStack = stack || error?.stack;

        // 1. Backend Analysis (Claude)
        let claudeAnalysis = "Claude analysis skipped.";
        try {
          const analyzeResponse = await fetch('/api/errors/analyze', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              error: errorMsg,
              stack: errorStack,
              context: {
                url: window.location.href,
                userAgent: navigator.userAgent,
                timestamp: new Date().toISOString()
              },
              source
            })
          });

          if (analyzeResponse.ok) {
            const contentType = analyzeResponse.headers.get("content-type");
            if (contentType && contentType.includes("application/json")) {
              const data = await analyzeResponse.json();
              claudeAnalysis = data.claudeAnalysis;
            }
          }
        } catch (e) {
          console.error("Failed to get Claude analysis:", e);
        }

        // 2. Frontend Implementation Steps (Gemini)
        let geminiSteps = "Gemini steps skipped (no API key).";
        const GEMINI_API_KEY = process.env.GEMINI_API_KEY || process.env.API_KEY;
        
        if (GEMINI_API_KEY) {
          try {
            const ai = new GoogleGenAI({ apiKey: GEMINI_API_KEY });
            const geminiResponse = await ai.models.generateContent({
              model: "gemini-3-flash-preview",
              contents: `Based on this error analysis from Claude, provide step-by-step implementation instructions for a developer to fix it in Google AI Studio.
              Analysis: ${claudeAnalysis}
              Original Error: ${errorMsg}`
            });
            geminiSteps = geminiResponse.text || "No steps generated.";
          } catch (geminiErr) {
            console.error('Gemini Failure:', geminiErr);
            geminiSteps = `Gemini failed: ${geminiErr instanceof Error ? geminiErr.message : String(geminiErr)}`;
          }
        }

        // 3. Backend Notification (Email + Logging)
        await fetch('/api/errors/notify', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            error: errorMsg,
            claudeAnalysis,
            geminiSteps
          })
        });

      } catch (err) {
        console.error('Failed to process error report:', err);
      }
    };

    const handleGlobalError = (event: ErrorEvent) => {
      reportError(event.error || event.message, event.error?.stack, 'frontend_global');
    };

    const handlePromiseRejection = (event: PromiseRejectionEvent) => {
      reportError(event.reason, event.reason?.stack, 'frontend_promise');
    };

    window.addEventListener('error', handleGlobalError);
    window.addEventListener('unhandledrejection', handlePromiseRejection);

    return () => {
      window.removeEventListener('error', handleGlobalError);
      window.removeEventListener('unhandledrejection', handlePromiseRejection);
    };
  }, []);
  const [token, setToken] = useState<string | null>(localStorage.getItem('pharmaflow_token'));
  const [activeTab, setActiveTab] = useState('dashboard');
  const [dashboardMode, setDashboardMode] = useState<'standard' | 'customizable'>('standard');
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [sidebarWidth, setSidebarWidth] = useState(256);

  useEffect(() => {
    const handleOpenGuide = () => {
      setActiveTab('guide');
    };
    window.addEventListener('open-guide', handleOpenGuide);
    return () => window.removeEventListener('open-guide', handleOpenGuide);
  }, []);
  const [selectedInstanceId, setSelectedInstanceId] = useState<number | null>(null);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [notifications, setNotifications] = useState([
    { id: 1, title: 'Low Stock', message: 'API-9921 is below threshold', type: 'warning' },
    { id: 2, title: 'Batch Complete', message: 'BN-1122 has been released', type: 'success' }
  ]);

  useEffect(() => {
    const savedUser = localStorage.getItem('pharmaflow_user');
    if (savedUser && savedUser !== 'undefined' && token) {
      try {
        setUser(JSON.parse(savedUser));
      } catch (e) {
        console.error('Failed to parse saved user:', e);
        localStorage.removeItem('pharmaflow_user');
        localStorage.removeItem('pharmaflow_token');
        setToken(null);
      }
    }
  }, []);

  const handleLogin = (u: User, t: string) => {
    setUser(u);
    setToken(t);
    localStorage.setItem('pharmaflow_token', t);
    localStorage.setItem('pharmaflow_user', JSON.stringify(u));
    localStorage.setItem('pharmaflow_company_id', u.company_id.toString());
  };

  const handleLogout = () => {
    setUser(null);
    setToken(null);
    localStorage.removeItem('pharmaflow_token');
    localStorage.removeItem('pharmaflow_user');
    localStorage.removeItem('pharmaflow_company_id');
  };

  const handleStartWorkflow = async (workflowId: number, batchNumber: string, productName: string, scheduledAt?: string) => {
    if (!user) return;
    const res = await api.post('/instances', { workflowId, userId: user.id, batchNumber, productName, scheduledAt });
    const data = res.data;
    if (!scheduledAt) {
      setSelectedInstanceId(data.id);
      setActiveTab('instance-execution');
    } else {
      toast.success(`Batch ${batchNumber} scheduled for ${new Date(scheduledAt).toLocaleString()}`);
      setActiveTab('instances');
    }
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setIsSearchOpen(true);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  if (!user) {
    return <Login onLogin={handleLogin} />;
  }

  return (
    <div className="flex min-h-screen bg-pharma-bg overflow-x-hidden">
      <Toaster position="top-right" richColors />
      <Sidebar 
        user={user} 
        activeTab={activeTab} 
        setActiveTab={(t) => {
          setActiveTab(t);
          setSelectedInstanceId(null);
        }} 
        onLogout={handleLogout} 
        isMobileOpen={isSidebarOpen}
        setIsMobileOpen={setIsSidebarOpen}
        isCollapsed={isSidebarCollapsed}
        setIsCollapsed={setIsSidebarCollapsed}
        width={sidebarWidth}
        setWidth={setSidebarWidth}
      />
      
      <SettingsMenu user={user} isOpen={isSettingsOpen} onClose={() => setIsSettingsOpen(false)} />
      <GlobalSearch isOpen={isSearchOpen} onClose={() => setIsSearchOpen(false)} onSelect={(tab, id) => {
        setActiveTab(tab);
        if (id && tab === 'instances') setSelectedInstanceId(id);
      }} />
      <AIAssistant context={{ user, activeTab }} />
      
      <main className={cn(
        "flex-1 p-4 md:p-10 transition-all duration-300 min-w-0",
        isSidebarCollapsed ? "lg:ml-[80px]" : "lg:ml-[var(--sidebar-width)]"
      )} style={{ "--sidebar-width": `${sidebarWidth}px` } as React.CSSProperties}>
        <div className="max-w-7xl mx-auto space-y-8">
          {/* Top Bar */}
          <div className="flex items-center justify-between lg:justify-end gap-4">
            <button 
              onClick={() => setIsSidebarOpen(true)}
              className="p-2 bg-white shadow-sm rounded-xl text-slate-600 lg:hidden"
            >
              <Menu size={24} />
            </button>
            
            <div className="flex items-center gap-4">
              {/* Dashboard View Toggle */}
              {activeTab === 'dashboard' && (
                <div className="flex items-center bg-white p-1 rounded-2xl border border-slate-100 shadow-sm mr-2">
                  <button 
                    onClick={() => setDashboardMode('standard')}
                    className={cn(
                      "px-3 md:px-4 py-1.5 rounded-xl text-[9px] md:text-[10px] font-bold uppercase tracking-wider transition-all",
                      dashboardMode === 'standard' 
                        ? "bg-pharma-primary text-white shadow-lg shadow-pharma-primary/20" 
                        : "text-slate-500 hover:text-pharma-primary"
                    )}
                  >
                    Standard
                  </button>
                  <button 
                    onClick={() => setDashboardMode('customizable')}
                    className={cn(
                      "px-3 md:px-4 py-1.5 rounded-xl text-[9px] md:text-[10px] font-bold uppercase tracking-wider transition-all",
                      dashboardMode === 'customizable' 
                        ? "bg-pharma-primary text-white shadow-lg shadow-pharma-primary/20" 
                        : "text-slate-500 hover:text-pharma-primary"
                    )}
                  >
                    Customizable
                  </button>
                </div>
              )}

              {/* Search Bar - Second from right */}
              <button 
                onClick={() => setIsSearchOpen(true)}
                className="flex items-center gap-3 px-4 py-2 bg-white border border-slate-100 rounded-2xl text-slate-400 hover:border-pharma-accent transition-all shadow-sm group"
              >
                <Search size={18} className="group-hover:text-pharma-accent transition-colors" />
                <span className="text-sm font-medium hidden md:inline">Search system...</span>
                <kbd className="hidden md:inline-flex items-center gap-1 px-1.5 py-0.5 bg-slate-50 border border-slate-200 rounded text-[10px] font-bold text-slate-400">
                  ⌘K
                </kbd>
              </button>

              {/* Settings and Notifications - Far right corner */}
              <div className="flex items-center gap-3">
                <div className="flex flex-col items-center gap-1">
                  <button 
                    onClick={() => setIsSettingsOpen(true)}
                    className="p-2 bg-white shadow-sm rounded-xl text-slate-600 hover:text-pharma-accent transition-colors"
                  >
                    <Settings size={20} />
                  </button>
                  
                  {/* Notification Bell - "under the setting menu" */}
                  <div className="relative group">
                    <button 
                      onClick={() => setIsNotificationsOpen(!isNotificationsOpen)}
                      className="relative"
                    >
                      <motion.div 
                        animate={notifications.length > 0 ? {
                          rotate: [0, -10, 10, -10, 10, 0],
                        } : {}}
                        transition={{ repeat: Infinity, duration: 1.5, repeatDelay: 3 }}
                        className="w-8 h-8 bg-pharma-primary text-white rounded-xl flex items-center justify-center shadow-lg shadow-pharma-primary/20 hover:bg-pharma-primary/90 transition-colors"
                      >
                        <Bell size={14} />
                      </motion.div>
                      {notifications.length > 0 && (
                        <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 text-white text-[8px] font-bold rounded-full flex items-center justify-center border-2 border-white">
                          {notifications.length}
                        </span>
                      )}
                    </button>

                    <AnimatePresence>
                      {isNotificationsOpen && (
                        <motion.div 
                          initial={{ opacity: 0, y: 10, scale: 0.95 }}
                          animate={{ opacity: 1, y: 0, scale: 1 }}
                          exit={{ opacity: 0, y: 10, scale: 0.95 }}
                          className="absolute right-0 mt-2 w-64 bg-white rounded-2xl shadow-2xl border border-slate-100 overflow-hidden z-[100]"
                        >
                          <div className="p-4 border-b border-slate-50 bg-slate-50/50 flex items-center justify-between">
                            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">Notifications</h3>
                            <button 
                              onClick={() => setNotifications([])}
                              className="text-[10px] text-pharma-accent font-bold hover:underline"
                            >
                              Clear all
                            </button>
                          </div>
                          <div className="max-h-64 overflow-y-auto custom-scrollbar">
                            {notifications.length > 0 ? (
                              (Array.isArray(notifications) ? notifications : []).map(n => (
                                <div key={n.id} className="p-4 border-b border-slate-50 hover:bg-slate-50 transition-colors cursor-pointer">
                                  <p className="text-xs font-bold text-slate-900">{n.title}</p>
                                  <p className="text-[10px] text-slate-500 mt-0.5">{n.message}</p>
                                </div>
                              ))
                            ) : (
                              <div className="p-8 text-center">
                                <Bell size={24} className="mx-auto text-slate-200 mb-2" />
                                <p className="text-xs text-slate-400">No new notifications</p>
                              </div>
                            )}
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <AnimatePresence mode="wait">
            {activeTab === 'dashboard' && (
              <motion.div key="dashboard" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                {dashboardMode === 'standard' ? (
                  <Dashboard user={user} onStartWorkflow={handleStartWorkflow} setActiveTab={setActiveTab} />
                ) : (
                  <CustomizableDashboard user={user} />
                )}
              </motion.div>
            )}
            {activeTab === 'workflows' && (
              <motion.div key="workflows" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <WorkflowBuilder user={user} />
              </motion.div>
            )}
            {activeTab === 'instances' && (
              <motion.div key="instances" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <InstanceList user={user} onOpenInstance={(id) => {
                  setSelectedInstanceId(id);
                  setActiveTab('instance-execution');
                }} />
              </motion.div>
            )}
            {activeTab === 'weighing-workflow' && (
              <motion.div key="weighing-workflow" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <WeighingModule user={user} />
              </motion.div>
            )}
            {activeTab === 'genealogy' && (
              <motion.div key="genealogy" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <MaterialGenealogy />
              </motion.div>
            )}
            {activeTab === 'weighing' && (
              <motion.div key="weighing" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <WeighingDispensing user={user} />
              </motion.div>
            )}
            {activeTab === 'instance-execution' && selectedInstanceId && (
              <motion.div key="execution" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <InstanceExecution 
                  instanceId={selectedInstanceId} 
                  user={user} 
                  onBack={() => setActiveTab('instances')} 
                />
              </motion.div>
            )}
            {activeTab === 'reports' && (
              <motion.div key="reports" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <ReportingCenter user={user} />
              </motion.div>
            )}
            {activeTab === 'master-data' && (
              <motion.div key="master-data" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <MasterDataPanel />
              </motion.div>
            )}
            {activeTab === 'inventory' && (
              <motion.div key="inventory" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <Inventory user={user} />
              </motion.div>
            )}
            {activeTab === 'supply-chain' && (
              <motion.div key="supply-chain" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <SupplyChain user={user} />
              </motion.div>
            )}
            {activeTab === 'quality' && (
              <motion.div key="quality" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <QualityQC user={user} />
              </motion.div>
            )}
            {activeTab === 'audit' && (
              <motion.div key="audit" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <AuditTrail />
              </motion.div>
            )}
            {activeTab === 'ai_insights' && (
              <motion.div key="ai_insights" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <AIInsights />
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
}
