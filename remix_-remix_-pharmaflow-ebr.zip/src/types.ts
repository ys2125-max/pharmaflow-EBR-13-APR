export type Role = 'Admin' | 'Operator' | 'Reviewer' | 'QA Approver';

export type InstanceStatus = 
  | 'Draft' 
  | 'Imported' 
  | 'Under Review' 
  | 'Released' 
  | 'Executing' 
  | 'Completed' 
  | 'Discontinued' 
  | 'Archived'
  | 'Scheduled'
  | 'Work in Process'
  | 'QA Review'
  | 'Quarantine';

export interface User {
  id: number;
  company_id: number;
  username: string;
  role: Role;
  full_name: string;
  email?: string;
  phone?: string;
  is_active: boolean;
  permissions?: Permissions;
}

export interface Permissions {
  role?: Role;
  can_edit_workflows: number;
  can_edit_inventory: number;
  can_edit_quality: number;
  can_edit_audit: number;
  can_edit_settings: number;
  can_perform_weighing: number;
}

export interface WorkflowField {
  id: string;
  name: string;
  variableName?: string;
  type: 'text' | 'number' | 'date' | 'dropdown' | 'file' | 'comment' | 'calculation' | 'table';
  config: {
    label: string;
    options?: string[];
    required?: boolean;
    formula?: string;
    tableConfig?: any;
    width?: 'full' | 'half' | 'third';
  };
}

export interface WorkflowStep {
  id?: number;
  name: string;
  type: 'multi-field' | 'text' | 'number' | 'date' | 'dropdown' | 'file' | 'comment' | 'calculation' | 'table';
  step_order: number;
  confidence?: 'High' | 'Medium' | 'Low';
  source_reference?: string;
  config: {
    label: string;
    fields?: WorkflowField[];
    options?: string[];
    required?: boolean;
    formula?: string; // For calculations: e.g. "{{step_1}} + {{step_2}}"
    tableConfig?: any; // For table builder
    reasonMandatory?: boolean; // Admin control for editing
  };
  responsible_role: Role;
}

export interface Workflow {
  id: number;
  company_id: number;
  product_id?: number;
  name: string;
  description: string;
  version: number;
  status: 'Draft' | 'Released' | 'Effective' | 'Deleted';
  is_latest: boolean;
  created_at: string;
  updated_at?: string;
  steps?: WorkflowStep[];
}

export interface Instance {
  id: number;
  workflow_id: number;
  workflow_name: string;
  batch_number: string;
  product_name: string;
  status: InstanceStatus;
  current_step_index: number;
  created_by: number;
  creator_name: string;
  created_at: string;
  updated_at: string;
  scheduled_at?: string;
  started_at?: string;
  completed_at?: string;
  steps?: WorkflowStep[];
  data?: InstanceData[];
}

export interface InstanceData {
  id: number;
  instance_id: number;
  step_id: number;
  data: any;
  reason?: string;
  is_na: boolean;
  na_reason?: string;
  submitted_by: number;
  submitted_by_name?: string;
  submitted_at: string;
  version: number;
}

export interface AuditLog {
  id: number;
  user_id: number;
  user_name: string;
  user_role: string;
  action: string;
  target_type: string;
  target_id: number;
  old_value?: string;
  new_value?: string;
  reason?: string;
  step_number?: number;
  details: string;
  timestamp: string;
  timezone: string;
}

export interface Stats {
  totalWorkflows: number;
  activeInstances: number;
  pendingReviews: number;
  completedInstances: number;
}

export interface Warehouse {
  id: number;
  name: string;
  location: string;
  is_active: boolean;
}

export interface Bin {
  id: number;
  warehouse_id: number;
  warehouse_name?: string;
  name: string;
  zone: string;
  priority: number;
  is_allergen_zone: boolean;
}

export interface Material {
  id: number;
  name: string;
  sku: string;
  code: string;
  upc?: string;
  lot_number: string;
  quantity: number;
  unit: string;
  expiry_date: string;
  status: 'Approved' | 'Quarantined' | 'Rejected' | 'Expired' | 'Available';
  warehouse_id?: number;
  bin_id?: number;
  warehouse_location?: string;
  bin_location?: string;
  reorder_point: number;
  reorder_qty: number;
  vendor_id?: string;
  potency?: number;
  storage_conditions?: string;
  tolerance_range?: number; // e.g., 0.05 for 5%
  required_stages?: string[];
  assigned_equipment?: number[];
  parent_lot_id?: number;
}

export interface WeighingTransaction {
  id: number;
  material_id: number;
  material_name: string;
  lot_number: string;
  unique_id: string; // QR/RFID
  equipment_id: number;
  equipment_name: string;
  tare_weight: number;
  gross_weight: number;
  net_weight: number;
  unit: string;
  environmental_conditions?: string;
  photo_url?: string;
  operator_id: number;
  operator_name: string;
  timestamp: string;
  signature?: string;
  status: 'Pending' | 'In Progress' | 'Completed' | 'Rejected';
  stage: number;
  batch_id?: number;
  batch_number?: string;
  comments?: string;
}

export interface GenealogyNode {
  id: number;
  type: 'Lot' | 'Dispensing' | 'Batch';
  label: string;
  details: string;
  timestamp: string;
  children?: GenealogyNode[];
}

export interface Equipment {
  id: number;
  name: string;
  asset_id: string;
  status: 'Cleaned' | 'In Use' | 'Dirty' | 'Out of Service';
  last_calibration: string;
  next_calibration: string;
}

export interface BOM {
  id: number;
  product_name: string;
  version: string;
  status: 'Draft' | 'Active' | 'Obsolete';
  created_at: string;
  items?: BOMItem[];
}

export interface BOMItem {
  id: number;
  bom_id: number;
  material_id: number;
  material_name?: string;
  material_sku?: string;
  child_bom_id?: number;
  quantity: number;
  unit: string;
}

export interface PurchaseOrder {
  id: number;
  po_number: string;
  vendor_name: string;
  status: 'Draft' | 'Open' | 'Received' | 'Closed';
  total_amount: number;
  created_at: string;
  items?: POItem[];
}

export interface POItem {
  id: number;
  po_id: number;
  material_id: number;
  material_name?: string;
  quantity: number;
  received_quantity: number;
  unit_price: number;
}

export interface Inspection {
  id: number;
  target_type: 'Material' | 'Batch' | 'Equipment';
  target_id: number;
  inspector_id: number;
  inspector_name?: string;
  status: 'Pending' | 'Passed' | 'Failed';
  results: string;
  created_at: string;
}

export interface MaintenanceLog {
  id: number;
  equipment_id: number;
  equipment_name?: string;
  type: 'Preventive' | 'Corrective' | 'Calibration';
  description: string;
  performed_by: string;
  next_due_date: string;
  created_at: string;
}

export interface Shipment {
  id: number;
  shipment_number: string;
  customer_name: string;
  carrier: 'UPS' | 'FedEx' | 'USPS';
  tracking_number?: string;
  status: 'Pending' | 'Picked' | 'Packed' | 'Shipped';
  label_url?: string;
  created_at: string;
}

export interface WeighingSession {
  id: number;
  instance_id: number;
  material_id: number;
  material_name?: string;
  target_weight: number;
  gross_weight: number;
  tare_weight: number;
  net_weight: number;
  status: 'In Progress' | 'Completed';
  operator_id: number;
  operator_name?: string;
  timestamp: string;
}

export interface FinancialTransaction {
  id: number;
  type: 'Purchase' | 'Sale' | 'Waste' | 'Labor';
  category: 'Material' | 'Equipment' | 'Service';
  amount: number;
  description: string;
  timestamp: string;
}
