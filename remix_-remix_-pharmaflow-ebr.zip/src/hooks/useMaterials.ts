import { useState, useEffect } from 'react';
import api from '../services/api';
import { Material } from '../types';
import { toast } from 'sonner';

export const useMaterials = () => {
  const [materials, setMaterials] = useState<Material[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchMaterials = async () => {
    setLoading(true);
    try {
      const res = await api.get('/materials');
      setMaterials(res.data);
    } catch (err) {
      toast.error('Failed to fetch materials');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMaterials();
  }, []);

  return { materials, loading, refetch: fetchMaterials };
};
