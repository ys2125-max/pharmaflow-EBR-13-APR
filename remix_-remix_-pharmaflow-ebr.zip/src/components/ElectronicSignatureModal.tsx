import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ShieldCheck, X, Loader2 } from 'lucide-react';
import api from '../services/api';
import { toast } from 'sonner';

interface ElectronicSignatureModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: (signature: any) => void;
  onSign?: (signature: string) => void;
  batchId?: number;
  stepId?: number;
  meaning?: 'Executed' | 'Reviewed' | 'Approved' | 'Verified';
  action?: string; // display label e.g. "Cleaning Verification for Scale-01"
}

export const ElectronicSignatureModal: React.FC<ElectronicSignatureModalProps> = ({
  isOpen, onClose, onSuccess, onSign, batchId, stepId, meaning = 'Executed', action
}) => {
  const [password, setPassword] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      const res = await api.post('/auth/verify-signature', {
        password, meaning, batchId, stepId
      });
      toast.success('Electronic Signature Applied');
      if (onSuccess) onSuccess(res.data.signature);
      if (onSign) onSign(res.data.signature || password);
      onClose();
    } catch (err: any) {
      toast.error(err.response?.data?.error || 'Signature failed');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[200] flex items-center justify-center p-4">
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="bg-white rounded-3xl shadow-2xl max-w-md w-full p-8 space-y-6"
          >
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-emerald-100 text-emerald-600 rounded-xl flex items-center justify-center">
                  <ShieldCheck size={24} />
                </div>
                <h3 className="text-xl font-bold text-slate-900">Electronic Signature</h3>
              </div>
              <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded-full transition-colors">
                <X size={20} />
              </button>
            </div>

            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100 space-y-2">
              <p className="text-sm text-slate-600">
                By signing this record, I confirm that I have <span className="font-bold text-pharma-primary">{action || meaning?.toLowerCase()}</span> this step in accordance with standard operating procedures.
              </p>
              <p className="text-xs text-slate-400 italic">
                This signature is legally equivalent to a handwritten signature.
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-1">Confirm Password</label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="input-field"
                  placeholder="Enter your password to sign"
                  required
                  autoFocus
                />
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="btn-primary w-full py-3 flex items-center justify-center gap-2"
              >
                {isSubmitting ? <Loader2 className="animate-spin" size={20} /> : <ShieldCheck size={20} />}
                Sign Record
              </button>
            </form>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
