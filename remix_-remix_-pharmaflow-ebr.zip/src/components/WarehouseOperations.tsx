import React, { useState, useEffect } from 'react';
import { Package, Truck, ClipboardCheck, ArrowRightLeft, Search, CheckCircle, AlertTriangle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import api from '../services/api';
import { toast } from 'sonner';
import { cn } from '../lib/utils';
import { ElectronicSignatureModal } from './ElectronicSignatureModal';

export const WarehouseOperations = ({ user }: { user: any }) => {
  const [activeTab, setActiveTab] = useState<'receiving' | 'staging' | 'dispatch' | 'cycle-count'>('receiving');
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [signatureReq, setSignatureReq] = useState<{ action: string, payload: any } | null>(null);

  // Form states
  const [receiveForm, setReceiveForm] = useState({ po_id: '', material_id: '', quantity: '', lot_number: '', expiry_date: '', vendor_id: '' });
  const [stageForm, setStageForm] = useState({ inventory_id: '', batch_id: '', quantity: '' });
  const [dispatchForm, setDispatchForm] = useState({ inventory_id: '', quantity: '', destination: '' });
  const [cycleCountForm, setCycleCountForm] = useState({ inventory_id: '', physical_quantity: '', reason: '' });

  const fetchData = async () => {
    setLoading(true);
    try {
      // Fetch necessary data for dropdowns (materials, inventory, POs, etc.)
      const [invRes, matRes] = await Promise.all([
        api.get('/inventory'),
        api.get('/materials')
      ]);
      setData({
        inventory: invRes.data.materials || [],
        materials: matRes.data.data || []
      });
    } catch (err) {
      toast.error('Failed to load warehouse data');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleReceive = async (e: React.FormEvent) => {
    e.preventDefault();
    setSignatureReq({ action: 'receive', payload: receiveForm });
  };

  const handleStage = async (e: React.FormEvent) => {
    e.preventDefault();
    setSignatureReq({ action: 'stage', payload: stageForm });
  };

  const handleDispatch = async (e: React.FormEvent) => {
    e.preventDefault();
    setSignatureReq({ action: 'dispatch', payload: dispatchForm });
  };

  const handleCycleCount = async (e: React.FormEvent) => {
    e.preventDefault();
    setSignatureReq({ action: 'cycle-count', payload: cycleCountForm });
  };

  const processAction = async (signature: any) => {
    if (!signatureReq) return;
    const { action, payload } = signatureReq;
    const dataWithSig = { ...payload, signature };

    try {
      if (action === 'receive') {
        await api.post('/warehouse/receive-material', dataWithSig);
        toast.success('Material received successfully and placed in Quarantine.');
        setReceiveForm({ po_id: '', material_id: '', quantity: '', lot_number: '', expiry_date: '', vendor_id: '' });
      } else if (action === 'stage') {
        await api.post('/warehouse/stage-material', dataWithSig);
        toast.success('Material staged successfully.');
        setStageForm({ inventory_id: '', batch_id: '', quantity: '' });
      } else if (action === 'dispatch') {
        await api.post('/warehouse/dispatch', dataWithSig);
        toast.success('Goods dispatched successfully.');
        setDispatchForm({ inventory_id: '', quantity: '', destination: '' });
      } else if (action === 'cycle-count') {
        const res = await api.post('/warehouse/cycle-count', dataWithSig);
        toast.success(`Cycle count recorded. Discrepancy: ${res.data.discrepancy}`);
        setCycleCountForm({ inventory_id: '', physical_quantity: '', reason: '' });
      }
      fetchData();
    } catch (err: any) {
      toast.error(err.response?.data?.error || `Failed to ${action}`);
    } finally {
      setSignatureReq(null);
    }
  };

  return (
    <div className="space-y-6">
      {signatureReq && (
        <ElectronicSignatureModal
          isOpen={true}
          onClose={() => setSignatureReq(null)}
          onSign={processAction}
          action={`Warehouse Operation: ${signatureReq.action}`}
        />
      )}
      <div className="flex border-b border-slate-200 gap-8">
        {[
          { id: 'receiving', label: 'Goods Receipt', icon: Package },
          { id: 'staging', label: 'Staging', icon: ArrowRightLeft },
          { id: 'dispatch', label: 'Dispatch', icon: Truck },
          { id: 'cycle-count', label: 'Cycle Count', icon: ClipboardCheck },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={cn(
              "flex items-center gap-2 pb-4 text-sm font-bold transition-all border-b-2",
              activeTab === tab.id ? "border-pharma-accent text-pharma-primary" : "border-transparent text-slate-400 hover:text-slate-600"
            )}
          >
            <tab.icon size={18} />
            {tab.label}
          </button>
        ))}
      </div>

      <div className="glass-panel p-6">
        {activeTab === 'receiving' && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="max-w-2xl">
            <h3 className="text-lg font-bold mb-4 flex items-center gap-2"><Package className="text-blue-500" /> Receive Materials</h3>
            <form onSubmit={handleReceive} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">PO Number</label>
                  <input required type="number" value={receiveForm.po_id} onChange={e => setReceiveForm({...receiveForm, po_id: e.target.value})} className="input-field" placeholder="e.g., 1001" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Vendor ID</label>
                  <input required type="number" value={receiveForm.vendor_id} onChange={e => setReceiveForm({...receiveForm, vendor_id: e.target.value})} className="input-field" placeholder="e.g., 1" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Material</label>
                  <select required value={receiveForm.material_id} onChange={e => setReceiveForm({...receiveForm, material_id: e.target.value})} className="input-field">
                    <option value="">Select Material...</option>
                    {data?.materials.map((m: any) => (
                      <option key={m.id} value={m.id}>{m.name} ({m.item_code})</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Quantity</label>
                  <input required type="number" step="0.01" value={receiveForm.quantity} onChange={e => setReceiveForm({...receiveForm, quantity: e.target.value})} className="input-field" placeholder="0.00" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Lot Number</label>
                  <input required value={receiveForm.lot_number} onChange={e => setReceiveForm({...receiveForm, lot_number: e.target.value})} className="input-field" placeholder="e.g., LOT-123" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Expiry Date</label>
                  <input required type="date" value={receiveForm.expiry_date} onChange={e => setReceiveForm({...receiveForm, expiry_date: e.target.value})} className="input-field" />
                </div>
              </div>
              <button type="submit" className="btn-primary w-full">Receive & Quarantine</button>
            </form>
          </motion.div>
        )}

        {activeTab === 'staging' && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="max-w-2xl">
            <h3 className="text-lg font-bold mb-4 flex items-center gap-2"><ArrowRightLeft className="text-purple-500" /> Stage Materials for Production</h3>
            <form onSubmit={handleStage} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Select Inventory (Approved Only)</label>
                <select required value={stageForm.inventory_id} onChange={e => setStageForm({...stageForm, inventory_id: e.target.value})} className="input-field">
                  <option value="">Select Inventory...</option>
                  {data?.inventory.filter((i: any) => i.status === 'APPROVED').map((i: any) => (
                    <option key={i.id} value={i.id}>{i.material_name} - Lot: {i.lot_number} (Qty: {i.quantity})</option>
                  ))}
                </select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Target Batch ID</label>
                  <input required type="number" value={stageForm.batch_id} onChange={e => setStageForm({...stageForm, batch_id: e.target.value})} className="input-field" placeholder="e.g., 101" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Quantity to Stage</label>
                  <input required type="number" step="0.01" value={stageForm.quantity} onChange={e => setStageForm({...stageForm, quantity: e.target.value})} className="input-field" placeholder="0.00" />
                </div>
              </div>
              <button type="submit" className="btn-primary w-full bg-purple-600 hover:bg-purple-700">Stage Material</button>
            </form>
          </motion.div>
        )}

        {activeTab === 'dispatch' && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="max-w-2xl">
            <h3 className="text-lg font-bold mb-4 flex items-center gap-2"><Truck className="text-emerald-500" /> Dispatch Finished Goods</h3>
            <form onSubmit={handleDispatch} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Select Finished Good (Approved Only)</label>
                <select required value={dispatchForm.inventory_id} onChange={e => setDispatchForm({...dispatchForm, inventory_id: e.target.value})} className="input-field">
                  <option value="">Select Inventory...</option>
                  {data?.inventory.filter((i: any) => i.status === 'APPROVED').map((i: any) => (
                    <option key={i.id} value={i.id}>{i.material_name} - Lot: {i.lot_number} (Qty: {i.quantity})</option>
                  ))}
                </select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Dispatch Quantity</label>
                  <input required type="number" step="0.01" value={dispatchForm.quantity} onChange={e => setDispatchForm({...dispatchForm, quantity: e.target.value})} className="input-field" placeholder="0.00" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Destination</label>
                  <input required value={dispatchForm.destination} onChange={e => setDispatchForm({...dispatchForm, destination: e.target.value})} className="input-field" placeholder="e.g., Distribution Center A" />
                </div>
              </div>
              <button type="submit" className="btn-primary w-full bg-emerald-600 hover:bg-emerald-700">Dispatch Goods</button>
            </form>
          </motion.div>
        )}

        {activeTab === 'cycle-count' && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="max-w-2xl">
            <h3 className="text-lg font-bold mb-4 flex items-center gap-2"><ClipboardCheck className="text-amber-500" /> Cycle Count Adjustment</h3>
            <form onSubmit={handleCycleCount} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Select Inventory Item</label>
                <select required value={cycleCountForm.inventory_id} onChange={e => setCycleCountForm({...cycleCountForm, inventory_id: e.target.value})} className="input-field">
                  <option value="">Select Inventory...</option>
                  {data?.inventory.map((i: any) => (
                    <option key={i.id} value={i.id}>{i.material_name} - Lot: {i.lot_number} (System Qty: {i.quantity})</option>
                  ))}
                </select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Actual Physical Quantity</label>
                  <input required type="number" step="0.01" value={cycleCountForm.physical_quantity} onChange={e => setCycleCountForm({...cycleCountForm, physical_quantity: e.target.value})} className="input-field" placeholder="0.00" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Reason for Discrepancy</label>
                  <input required value={cycleCountForm.reason} onChange={e => setCycleCountForm({...cycleCountForm, reason: e.target.value})} className="input-field" placeholder="e.g., Spillage, Counting Error" />
                </div>
              </div>
              <button type="submit" className="btn-primary w-full bg-amber-600 hover:bg-amber-700">Record Cycle Count</button>
            </form>
          </motion.div>
        )}
      </div>
    </div>
  );
};
