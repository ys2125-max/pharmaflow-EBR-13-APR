import React, { useState, useEffect } from 'react';
import { Layers, ChevronRight, Package, ClipboardList, Database, History, Search, Filter, Download } from 'lucide-react';
import { motion } from 'motion/react';
import api from '../services/api';
import { cn } from '../lib/utils';
import { GenealogyNode } from '../types';

export const MaterialGenealogy = () => {
  const [genealogy, setGenealogy] = useState<GenealogyNode[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchGenealogy();
  }, []);

  const fetchGenealogy = async () => {
    setLoading(true);
    try {
      const res = await api.get('/inventory/genealogy');
      setGenealogy(res.data);
    } catch (e) {
      // Mock data for demo
      setGenealogy([
        {
          id: 1,
          type: 'Lot',
          label: 'API-LOT-9921',
          details: 'Active Pharmaceutical Ingredient - Batch 01',
          timestamp: '2026-03-01T10:00:00Z',
          children: [
            {
              id: 2,
              type: 'Dispensing',
              label: 'WEIGH-102',
              details: 'Dispensed 45.000 kg for Batch BN-1122',
              timestamp: '2026-03-05T14:30:00Z',
              children: [
                {
                  id: 3,
                  type: 'Batch',
                  label: 'BN-1122',
                  details: 'Paracetamol 500mg - Compression Stage',
                  timestamp: '2026-03-06T08:00:00Z'
                }
              ]
            },
            {
              id: 4,
              type: 'Dispensing',
              label: 'WEIGH-105',
              details: 'Dispensed 12.500 kg for Batch BN-1123',
              timestamp: '2026-03-05T16:00:00Z',
              children: [
                {
                  id: 5,
                  type: 'Batch',
                  label: 'BN-1123',
                  details: 'Paracetamol 500mg - Granulation Stage',
                  timestamp: '2026-03-07T09:00:00Z'
                }
              ]
            }
          ]
        },
        {
          id: 6,
          type: 'Lot',
          label: 'EXC-LOT-4412',
          details: 'Excipient - Microcrystalline Cellulose',
          timestamp: '2026-02-15T11:00:00Z',
          children: [
            {
              id: 7,
              type: 'Dispensing',
              label: 'WEIGH-108',
              details: 'Dispensed 120.000 kg for Batch BN-1122',
              timestamp: '2026-03-05T15:00:00Z',
              children: [
                {
                  id: 8,
                  type: 'Batch',
                  label: 'BN-1122',
                  details: 'Paracetamol 500mg - Compression Stage',
                  timestamp: '2026-03-06T08:00:00Z'
                }
              ]
            }
          ]
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const filterGenealogy = (nodes: GenealogyNode[]): GenealogyNode[] => {
    if (!searchQuery) return nodes;
    const query = searchQuery.toLowerCase();
    
    return nodes.filter(node => {
      const matchesSelf = 
        node.label.toLowerCase().includes(query) || 
        node.details.toLowerCase().includes(query);
      
      const filteredChildren = node.children ? filterGenealogy(node.children) : [];
      
      if (matchesSelf || filteredChildren.length > 0) {
        // If self matches or any child matches, keep this node
        // If children match, we only show the matching children branch
        if (filteredChildren.length > 0) {
          node.children = filteredChildren;
        }
        return true;
      }
      return false;
    });
  };

  const filteredGenealogy = filterGenealogy(JSON.parse(JSON.stringify(genealogy)));

  const renderNode = (node: GenealogyNode, level = 0) => {
    const Icon = node.type === 'Lot' ? Database : node.type === 'Dispensing' ? Layers : ClipboardList;
    const colorClass = node.type === 'Lot' ? "bg-blue-50 text-blue-600 border-blue-100" : node.type === 'Dispensing' ? "bg-amber-50 text-amber-600 border-amber-100" : "bg-emerald-50 text-emerald-600 border-emerald-100";

    return (
      <div key={node.id} className="space-y-4">
        <motion.div 
          initial={{ opacity: 0, x: -10 }}
          animate={{ opacity: 1, x: 0 }}
          className={cn(
            "flex items-center gap-4 p-4 rounded-2xl border transition-all hover:shadow-md bg-white",
            level > 0 && "ml-12 relative before:absolute before:left-[-24px] before:top-1/2 before:w-6 before:h-px before:bg-slate-200"
          )}
        >
          <div className={cn("w-12 h-12 rounded-xl flex items-center justify-center border shrink-0", colorClass)}>
            <Icon size={24} />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between">
              <h4 className="font-bold text-slate-900 truncate">{node.label}</h4>
              <span className="text-[10px] font-bold text-slate-400 uppercase">{new Date(node.timestamp).toLocaleDateString()}</span>
            </div>
            <p className="text-xs text-slate-500 truncate">{node.details}</p>
          </div>
          <button className="p-2 hover:bg-slate-50 rounded-lg text-slate-400 transition-colors">
            <Search size={16} />
          </button>
        </motion.div>
        
        {node.children && node.children.length > 0 && (
          <div className="relative before:absolute before:left-[23px] before:top-0 before:bottom-0 before:w-px before:bg-slate-200">
            {node.children.map(child => renderNode(child, level + 1))}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-8">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Material Genealogy</h1>
          <p className="text-slate-500">Full traceability from raw material lots to finished batch records.</p>
        </div>
        <div className="flex gap-3">
          <button className="btn-secondary flex items-center gap-2">
            <Download size={18} /> Export Trace Map
          </button>
          <button className="btn-primary flex items-center gap-2">
            <History size={18} /> Full Audit Log
          </button>
        </div>
      </header>

      <div className="glass-panel p-6 flex items-center gap-4 bg-slate-50/50">
        <div className="relative flex-1">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
          <input 
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="input-field pl-12 bg-white"
            placeholder="Search by Lot Number, Batch ID, or Material Code..."
          />
        </div>
        <button className="btn-secondary flex items-center gap-2">
          <Filter size={18} /> Filters
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <div className="lg:col-span-3 space-y-6">
          {loading ? (
            <div className="p-20 text-center text-slate-400">Building genealogy map...</div>
          ) : (
            <div className="space-y-6">
              {filteredGenealogy.map(node => renderNode(node))}
              {filteredGenealogy.length === 0 && (
                <div className="p-20 text-center text-slate-400 italic">No matching lots or batches found.</div>
              )}
            </div>
          )}
        </div>

        <div className="space-y-6">
          <div className="glass-panel p-6 space-y-6">
            <h3 className="text-sm font-bold text-slate-500 uppercase">Traceability Stats</h3>
            <div className="space-y-4">
              <div className="p-4 bg-blue-50 rounded-2xl">
                <p className="text-[10px] font-bold text-blue-400 uppercase">Active Parent Lots</p>
                <p className="text-2xl font-bold text-blue-700">24</p>
              </div>
              <div className="p-4 bg-amber-50 rounded-2xl">
                <p className="text-[10px] font-bold text-amber-400 uppercase">Dispensing Events</p>
                <p className="text-2xl font-bold text-amber-700">142</p>
              </div>
              <div className="p-4 bg-emerald-50 rounded-2xl">
                <p className="text-[10px] font-bold text-emerald-400 uppercase">Batches Linked</p>
                <p className="text-2xl font-bold text-emerald-700">18</p>
              </div>
            </div>
          </div>

          <div className="glass-panel p-6 space-y-4">
            <h3 className="text-sm font-bold text-slate-500 uppercase">Legend</h3>
            <div className="space-y-3">
              <div className="flex items-center gap-3 text-xs">
                <div className="w-8 h-8 bg-blue-50 text-blue-600 rounded-lg flex items-center justify-center border border-blue-100">
                  <Database size={16} />
                </div>
                <span className="font-bold text-slate-700">Parent Lot</span>
              </div>
              <div className="flex items-center gap-3 text-xs">
                <div className="w-8 h-8 bg-amber-50 text-amber-600 rounded-lg flex items-center justify-center border border-amber-100">
                  <Layers size={16} />
                </div>
                <span className="font-bold text-slate-700">Dispensing / Weighing</span>
              </div>
              <div className="flex items-center gap-3 text-xs">
                <div className="w-8 h-8 bg-emerald-50 text-emerald-600 rounded-lg flex items-center justify-center border border-emerald-100">
                  <ClipboardList size={16} />
                </div>
                <span className="font-bold text-slate-700">Batch Record</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
