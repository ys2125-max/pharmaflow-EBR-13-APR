import React, { useState, useEffect } from 'react';
import { Sparkles, TrendingUp, AlertTriangle, Calendar, Activity, Zap, ShieldCheck } from 'lucide-react';
import api from '../services/api';
import { motion } from 'motion/react';
import { cn } from '../lib/utils';

export const AIInsights = () => {
  const [insights, setInsights] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchInsights();
  }, []);

  const fetchInsights = async () => {
    setLoading(true);
    try {
      // In a real app, this would call a specialized AI endpoint
      const res = await api.get('/ai/insights');
      setInsights(res.data);
    } catch (err) {
      // Fallback mock insights for demo
      setInsights([
        {
          id: 1,
          type: 'maintenance',
          title: 'Predictive Maintenance Alert',
          description: 'Fluid Bed Dryer (FBD-02) showing abnormal vibration patterns. Failure predicted within 48-72 hours of operation.',
          severity: 'high',
          icon: Wrench,
          recommendation: 'Schedule bearing inspection and lubrication before next batch.'
        },
        {
          id: 2,
          type: 'scheduling',
          title: 'Schedule Optimization',
          description: 'Current schedule has 4 hours of idle time in Room 102. AI suggests moving Batch BN-9921 to start earlier.',
          severity: 'medium',
          icon: Calendar,
          recommendation: 'Optimize schedule to increase throughput by 12%.'
        },
        {
          id: 3,
          type: 'deviation',
          title: 'Anomalous Process Trend',
          description: 'Batch BN-1122: Inlet air temperature is trending towards the upper limit (72°C). Historical data suggests potential yield loss.',
          severity: 'high',
          icon: AlertTriangle,
          recommendation: 'Adjust PID controller parameters or check heater element.'
        },
        {
          id: 4,
          type: 'optimization',
          title: 'Yield Optimization',
          description: 'Analysis of last 50 batches suggests that reducing mixing time by 5 minutes at 45 RPM increases granule uniformity.',
          severity: 'low',
          icon: TrendingUp,
          recommendation: 'Update Master Batch Record v2.4 with optimized parameters.'
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const getIcon = (insight: any) => {
    if (typeof insight.icon === 'function' || typeof insight.icon === 'object') return insight.icon;
    
    const iconMap: Record<string, any> = {
      'Activity': Activity,
      'TrendingUp': TrendingUp,
      'AlertTriangle': AlertTriangle,
      'Calendar': Calendar,
      'Zap': Zap,
      'ShieldCheck': ShieldCheck,
      'Wrench': Activity // Fallback
    };
    
    return iconMap[insight.iconType] || iconMap[insight.icon] || Sparkles;
  };

  return (
    <div className="space-y-6">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 flex items-center gap-3">
            <Sparkles className="text-pharma-accent" size={32} />
            AI Manufacturing Insights
          </h1>
          <p className="text-slate-500">Predictive analytics and process optimization powered by Gemini.</p>
        </div>
        <button onClick={fetchInsights} className="btn-secondary flex items-center gap-2">
          <Activity size={18} /> Refresh Analysis
        </button>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {Array.isArray(insights) && insights.map((insight, i) => {
          const Icon = getIcon(insight);
          return (
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              key={insight.id} 
              className="glass-panel p-6 space-y-4 relative overflow-hidden group"
            >
              <div className={cn(
                "absolute top-0 right-0 w-24 h-24 -mr-8 -mt-8 opacity-5 transition-transform group-hover:scale-110",
                insight.severity === 'high' ? "text-red-500" : insight.severity === 'medium' ? "text-amber-500" : "text-blue-500"
              )}>
                <Icon size={96} />
              </div>

              <div className="flex items-start gap-4">
                <div className={cn(
                  "w-12 h-12 rounded-2xl flex items-center justify-center shrink-0",
                  insight.severity === 'high' ? "bg-red-50 text-red-600" : insight.severity === 'medium' ? "bg-amber-50 text-amber-600" : "bg-blue-50 text-blue-600"
                )}>
                  <Icon size={24} />
                </div>
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold text-slate-800">{insight.title}</h3>
                    <span className={cn(
                      "px-1.5 py-0.5 rounded text-[8px] font-bold uppercase",
                      insight.severity === 'high' ? "bg-red-100 text-red-700" : insight.severity === 'medium' ? "bg-amber-100 text-amber-700" : "bg-blue-100 text-blue-700"
                    )}>
                      {insight.severity} Priority
                    </span>
                  </div>
                  <p className="text-sm text-slate-600 leading-relaxed">{insight.description}</p>
                </div>
              </div>

              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100">
                <div className="flex items-center gap-2 mb-1">
                  <Zap className="text-pharma-accent" size={14} />
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">AI Recommendation</span>
                </div>
                <p className="text-xs text-slate-700 font-medium">{insight.recommendation}</p>
              </div>

              <div className="flex gap-3">
                <button className="btn-primary flex-1 py-2 text-xs">Apply Optimization</button>
                <button className="btn-secondary flex-1 py-2 text-xs">Create Deviation</button>
              </div>
            </motion.div>
          );
        })}
      </div>

      <div className="glass-panel p-8 bg-pharma-primary text-white overflow-hidden relative">
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full -mr-32 -mt-32 blur-3xl" />
        <div className="relative z-10 space-y-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center">
              <ShieldCheck size={24} />
            </div>
            <div>
              <h2 className="text-xl font-bold">AI Batch Review Assistant</h2>
              <p className="text-blue-100 text-sm">Automated review of critical process parameters (CPPs) and quality attributes.</p>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-white/5 p-4 rounded-2xl border border-white/10">
              <p className="text-xs text-blue-200 font-bold uppercase mb-2">Batches Pending Review</p>
              <p className="text-3xl font-bold">12</p>
            </div>
            <div className="bg-white/5 p-4 rounded-2xl border border-white/10">
              <p className="text-xs text-blue-200 font-bold uppercase mb-2">Auto-Verified Steps</p>
              <p className="text-3xl font-bold">98.4%</p>
            </div>
            <div className="bg-white/5 p-4 rounded-2xl border border-white/10">
              <p className="text-xs text-blue-200 font-bold uppercase mb-2">Flagged Deviations</p>
              <p className="text-3xl font-bold text-amber-300">3</p>
            </div>
          </div>

          <button className="w-full py-3 bg-pharma-accent text-pharma-primary font-bold rounded-2xl hover:bg-white transition-all">
            Start Intelligent Batch Review
          </button>
        </div>
      </div>
    </div>
  );
};

// Mock icons for the insights
const Wrench = (props: any) => <Activity {...props} />;
