import React, { useState, useEffect, useRef } from 'react';
import { Scale, QrCode, ShieldCheck, AlertTriangle, Printer, CheckCircle2, RotateCcw, Camera, Activity, Info, Wrench } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { toast } from 'sonner';
import api from '../services/api';
import { cn } from '../lib/utils';
import { Material, Equipment, User, WeighingTransaction } from '../types';
import { ElectronicSignatureModal } from './ElectronicSignatureModal';

import { useMaterials } from '../hooks/useMaterials';

export const WeighingModule = ({ user }: { user: User }) => {
  const [stage, setStage] = useState(1);
  const { materials, loading: materialsLoading } = useMaterials();
  const [scales, setScales] = useState<Equipment[]>([]);
  const [selectedMaterial, setSelectedMaterial] = useState<Material | null>(null);
  const [selectedScale, setSelectedScale] = useState<Equipment | null>(null);
  const [scannedId, setScannedId] = useState('');
  const [weights, setWeights] = useState({ tare: 0, gross: 0, net: 0 });
  const [isWeighing, setIsWeighing] = useState(false);
  const [showSignature, setShowSignature] = useState(false);
  const [comments, setComments] = useState('');

  useEffect(() => {
    // Only fetch equipment if we don't have it (or if we want to refresh)
    api.get('/inventory').then(res => {
      if (res.data) {
        setScales(Array.isArray(res.data.equipment) ? res.data.equipment.filter((e: any) => e.name.toLowerCase().includes('scale')) : []);
      }
    }).catch(err => {
      if (err.response?.status === 429) return; // Silent ignore for 429s in background
      console.error("Failed to fetch inventory for weighing:", err);
      toast.error("Failed to load equipment.");
    });
  }, []);

  const handleScan = () => {
    const material = materials.find(m => m.sku === scannedId || m.lot_number === scannedId);
    if (material) {
      if (material.status !== 'Approved') {
        return toast.error(`Material status is ${material.status}. Cannot proceed.`);
      }
      setSelectedMaterial(material);
      setStage(2);
      toast.success("Material Verified");
    } else {
      toast.error("Invalid Material ID");
    }
  };

  const handleScaleSelect = (scale: Equipment) => {
    if (scale.status !== 'Cleaned') {
      return toast.error("Scale must be in 'Cleaned' status.");
    }
    setSelectedScale(scale);
    setStage(3);
  };

  const startWeighing = () => {
    setIsWeighing(true);
    let g = 0;
    const interval = setInterval(() => {
      g += Math.random() * 2;
      const n = Math.max(0, g - weights.tare);
      setWeights(prev => ({ ...prev, gross: g, net: n }));
      if (g >= 50) { // Simulate target
        clearInterval(interval);
        setIsWeighing(false);
        toast.success("Weight Stabilized");
      }
    }, 100);
  };

  const handleFinalSign = async (signature: string) => {
    try {
      await api.post('/weighing/complete', {
        material_id: selectedMaterial?.id,
        equipment_id: selectedScale?.id,
        tare_weight: weights.tare,
        gross_weight: weights.gross,
        net_weight: weights.net,
        signature,
        comments,
        userId: user.id
      });
      toast.success("Weighing Record Locked & Saved");
      setStage(5);
    } catch (e) {
      toast.error("Failed to save record");
    } finally {
      setShowSignature(false);
    }
  };

  const stages = [
    { id: 1, name: 'Material Selection', icon: QrCode },
    { id: 2, name: 'Equipment Verification', icon: Wrench },
    { id: 3, name: 'Safety Check', icon: ShieldCheck },
    { id: 4, name: 'Container Weighing', icon: Scale },
    { id: 5, name: 'Label & Review', icon: Printer },
  ];

  return (
    <div className="space-y-8">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Precision Weighing Workflow</h1>
          <p className="text-slate-500">Multi-stage pharmaceutical material dispensing with scale integration.</p>
        </div>
        <div className="flex items-center gap-4">
           {stages.map((s) => (
             <div key={s.id} className="flex items-center">
               <div className={cn(
                 "w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all",
                 stage >= s.id ? "bg-pharma-primary text-white" : "bg-slate-100 text-slate-400"
               )}>
                 {stage > s.id ? <CheckCircle2 size={16} /> : s.id}
               </div>
               {s.id < 4 && <div className={cn("w-8 h-0.5 mx-1", stage > s.id ? "bg-pharma-primary" : "bg-slate-100")} />}
             </div>
           ))}
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <AnimatePresence mode="wait">
            {stage === 1 && (
              <motion.div 
                key="stage1"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                className="glass-panel p-12 text-center space-y-8"
              >
                <div className="w-24 h-24 bg-pharma-accent/10 text-pharma-accent rounded-full flex items-center justify-center mx-auto">
                  <QrCode size={48} />
                </div>
                <div className="max-w-sm mx-auto space-y-4">
                  <h2 className="text-2xl font-bold">Scan Material Unique ID</h2>
                  <p className="text-slate-500">Scan the QR code or RFID tag on the material container to verify status and potency.</p>
                  <div className="relative">
                    <input 
                      value={scannedId}
                      onChange={e => setScannedId(e.target.value)}
                      onKeyDown={e => e.key === 'Enter' && handleScan()}
                      className="input-field text-center text-xl tracking-widest font-mono"
                      placeholder="SCAN ID..."
                      autoFocus
                    />
                    <button onClick={handleScan} className="absolute right-2 top-1/2 -translate-y-1/2 p-2 bg-pharma-primary text-white rounded-lg">
                      <ArrowRight size={20} />
                    </button>
                  </div>
                </div>
              </motion.div>
            )}

            {stage === 2 && (
              <motion.div 
                key="stage2"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                className="glass-panel p-8 space-y-6"
              >
                <div className="flex items-center justify-between">
                  <h2 className="text-2xl font-bold">Select Validated Scale</h2>
                  <button onClick={() => setStage(1)} className="text-slate-400 hover:text-slate-600 flex items-center gap-1 text-sm">
                    <RotateCcw size={14} /> Back to Scan
                  </button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {scales.map(scale => (
                    <button
                      key={scale.id}
                      onClick={() => handleScaleSelect(scale)}
                      className={cn(
                        "p-6 rounded-3xl border-2 text-left transition-all space-y-3",
                        selectedScale?.id === scale.id ? "border-pharma-primary bg-pharma-primary/5" : "border-slate-100 hover:border-pharma-accent"
                      )}
                    >
                      <div className="flex justify-between items-start">
                        <Scale size={24} className="text-pharma-primary" />
                        <span className={cn(
                          "px-2 py-0.5 rounded text-[10px] font-bold uppercase",
                          scale.status === 'Cleaned' ? "bg-emerald-100 text-emerald-700" : "bg-red-100 text-red-700"
                        )}>
                          {scale.status}
                        </span>
                      </div>
                      <div>
                        <p className="font-bold text-slate-900">{scale.name}</p>
                        <p className="text-xs text-slate-500">Asset: {scale.asset_id}</p>
                      </div>
                      <div className="pt-2 border-t border-slate-100 flex justify-between text-[10px] font-bold text-slate-400 uppercase">
                        <span>Cal Due: {scale.next_calibration}</span>
                      </div>
                    </button>
                  ))}
                </div>
              </motion.div>
            )}

            {stage === 3 && (
              <motion.div 
                key="stage3"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                className="glass-panel p-12 text-center space-y-8"
              >
                <div className="w-24 h-24 bg-pharma-accent/10 text-pharma-accent rounded-full flex items-center justify-center mx-auto">
                  <ShieldCheck size={48} />
                </div>
                <div className="max-w-sm mx-auto space-y-4">
                  <h2 className="text-2xl font-bold">Safety Check</h2>
                  <p className="text-slate-500">Verify material {selectedMaterial?.name} is approved and you have the correct PPE for this material.</p>
                  <button onClick={() => setStage(4)} className="btn-primary w-full py-4">Confirm Safety Check</button>
                </div>
              </motion.div>
            )}

            {stage === 4 && (
              <motion.div 
                key="stage4"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                className="glass-panel p-8 space-y-8"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-emerald-50 text-emerald-600 rounded-xl flex items-center justify-center">
                      <Activity size={20} />
                    </div>
                    <div>
                      <h2 className="text-xl font-bold">Live Weight Feed</h2>
                      <p className="text-xs text-slate-500">Scale: {selectedScale?.name} | Material: {selectedMaterial?.name}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 bg-emerald-50 text-emerald-700 px-3 py-1 rounded-full text-[10px] font-bold">
                    <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse" />
                    STABLE
                  </div>
                </div>

                <div className="flex flex-col items-center py-12 space-y-8">
                  <div className="text-center">
                    <h3 className="text-7xl font-black text-slate-900 font-mono tracking-tighter">
                      {weights.net.toFixed(3)} <span className="text-2xl text-slate-400">kg</span>
                    </h3>
                    <p className="text-sm font-bold text-emerald-500 uppercase tracking-widest mt-2">Net Weight</p>
                  </div>

                  <div className="grid grid-cols-2 gap-8 w-full max-w-sm">
                    <div className="text-center p-4 bg-slate-50 rounded-2xl">
                      <p className="text-2xl font-bold text-slate-700 font-mono">{weights.gross.toFixed(3)}</p>
                      <p className="text-[10px] font-bold text-slate-400 uppercase">Gross</p>
                    </div>
                    <div className="text-center p-4 bg-slate-50 rounded-2xl">
                      <p className="text-2xl font-bold text-slate-700 font-mono">{weights.tare.toFixed(3)}</p>
                      <p className="text-[10px] font-bold text-slate-400 uppercase">Tare</p>
                    </div>
                  </div>

                  <div className="flex gap-4 w-full max-w-sm">
                    <button 
                      onClick={() => setWeights(prev => ({ ...prev, tare: prev.gross, net: 0 }))}
                      className="btn-secondary flex-1 py-4"
                    >
                      Tare Scale
                    </button>
                    <button 
                      onClick={startWeighing}
                      disabled={isWeighing}
                      className="btn-primary flex-1 py-4 flex items-center justify-center gap-2"
                    >
                      {isWeighing ? <RotateCcw className="animate-spin" size={20} /> : <Scale size={20} />}
                      {isWeighing ? 'Capturing...' : 'Capture Weight'}
                    </button>
                  </div>
                </div>

                <div className="space-y-4 pt-8 border-t border-slate-100">
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Operator Comments</label>
                    <textarea 
                      value={comments}
                      onChange={e => setComments(e.target.value)}
                      className="input-field min-h-[100px]"
                      placeholder="Enter any process observations..."
                    />
                  </div>
                  <button 
                    onClick={() => setShowSignature(true)}
                    className="w-full py-4 bg-pharma-primary text-white rounded-2xl font-bold shadow-xl shadow-pharma-primary/20 hover:scale-[1.02] transition-all flex items-center justify-center gap-2"
                  >
                    <ShieldCheck size={20} /> Review & Sign Record
                  </button>
                </div>
              </motion.div>
            )}

            {stage === 5 && (
              <motion.div 
                key="stage5"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="glass-panel p-12 text-center space-y-8"
              >
                <div className="w-20 h-20 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
                  <CheckCircle2 size={40} />
                </div>
                <div className="space-y-2">
                  <h2 className="text-2xl font-bold">Transaction Complete</h2>
                  <p className="text-slate-500">The weighing record has been locked and added to the batch genealogy.</p>
                </div>

                <div className="max-w-xs mx-auto p-6 bg-white border border-slate-200 rounded-2xl shadow-sm space-y-4 text-left">
                  <div className="flex justify-between items-start">
                    <div className="space-y-1">
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Material Label</p>
                      <p className="font-bold text-slate-900">{selectedMaterial?.name}</p>
                    </div>
                    <QrCode size={32} className="text-slate-300" />
                  </div>
                  <div className="grid grid-cols-2 gap-4 text-[10px]">
                    <div>
                      <p className="text-slate-400 font-bold uppercase">Net Weight</p>
                      <p className="text-sm font-bold text-slate-900">{weights.net.toFixed(3)} kg</p>
                    </div>
                    <div>
                      <p className="text-slate-400 font-bold uppercase">Operator</p>
                      <p className="text-sm font-bold text-slate-900">{user.full_name}</p>
                    </div>
                  </div>
                  <div className="pt-4 border-t border-slate-100">
                    <p className="text-[8px] text-slate-400 font-mono uppercase">ID: {Math.random().toString(36).substring(7).toUpperCase()}</p>
                  </div>
                </div>

                <div className="flex gap-4 max-w-sm mx-auto">
                  <button onClick={() => { setStage(1); setSelectedMaterial(null); setSelectedScale(null); setWeights({ tare: 0, gross: 0, net: 0 }); }} className="btn-secondary flex-1">New Weighing</button>
                  <button className="btn-primary flex-1 flex items-center justify-center gap-2">
                    <Printer size={18} /> Print Label
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <div className="space-y-6">
          <div className="glass-panel p-6 space-y-6">
            <h3 className="text-sm font-bold text-slate-500 uppercase flex items-center gap-2">
              <Info size={16} /> Process Controls
            </h3>
            
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <div className={cn("w-2 h-2 rounded-full mt-1.5", selectedMaterial ? "bg-emerald-500" : "bg-slate-300")} />
                <div>
                  <p className="text-xs font-bold text-slate-700">Material Status Check</p>
                  <p className="text-[10px] text-slate-400">Verifying material is Approved and not Expired.</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className={cn("w-2 h-2 rounded-full mt-1.5", selectedScale ? "bg-emerald-500" : "bg-slate-300")} />
                <div>
                  <p className="text-xs font-bold text-slate-700">Scale Calibration Check</p>
                  <p className="text-[10px] text-slate-400">Ensuring scale is within calibration tolerance.</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className={cn("w-2 h-2 rounded-full mt-1.5", stage >= 3 ? "bg-emerald-500" : "bg-slate-300")} />
                <div>
                  <p className="text-xs font-bold text-slate-700">Environmental Monitoring</p>
                  <p className="text-[10px] text-slate-400">Recording Temp/Humidity during dispensing.</p>
                </div>
              </div>
            </div>

            {selectedMaterial && (
              <div className="p-4 bg-slate-50 rounded-2xl space-y-3">
                <p className="text-[10px] font-bold text-slate-400 uppercase">Material Details</p>
                <div className="space-y-2">
                  <div className="flex justify-between text-xs">
                    <span className="text-slate-500">Potency</span>
                    <span className="font-bold text-slate-900">{selectedMaterial.potency || 100}%</span>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="text-slate-500">Tolerance</span>
                    <span className="font-bold text-slate-900">±{(selectedMaterial.tolerance_range || 0.05) * 100}%</span>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="text-slate-500">Storage</span>
                    <span className="font-bold text-slate-900">{selectedMaterial.storage_conditions || 'Ambient'}</span>
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="glass-panel p-6 bg-pharma-primary text-white overflow-hidden relative">
            <div className="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-full -mr-16 -mt-16 blur-2xl" />
            <div className="relative z-10 space-y-4">
              <div className="flex items-center gap-2">
                <ShieldCheck className="text-pharma-accent" size={20} />
                <h4 className="font-bold text-sm">GMP Compliance</h4>
              </div>
              <p className="text-[10px] text-blue-100 leading-relaxed">
                All weighing data is captured directly from the scale interface and locked upon electronic signature. Tamper-evident audit trails are generated for every value change.
              </p>
            </div>
          </div>
        </div>
      </div>

      <ElectronicSignatureModal 
        isOpen={showSignature}
        onClose={() => setShowSignature(false)}
        onSign={handleFinalSign}
        action={`Weighing & Dispensing of ${selectedMaterial?.name}`}
      />
    </div>
  );
};

const ArrowRight = (props: any) => <Activity {...props} />;
