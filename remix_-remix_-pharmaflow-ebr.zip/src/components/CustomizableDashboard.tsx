import React, { useState, useEffect, useRef } from 'react';
import { ResponsiveGridLayout, useContainerWidth } from 'react-grid-layout';
import { 
  Plus, 
  Settings, 
  Trash2, 
  GripVertical, 
  BarChart3, 
  PieChart as PieChartIcon, 
  LineChart as LineChartIcon,
  Layout,
  Save,
  RotateCcw,
  X,
  RefreshCw,
  MoreVertical,
  Pin,
  PinOff,
  Activity
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  PieChart, Pie, Cell, LineChart, Line, AreaChart, Area 
} from 'recharts';
import api from '../services/api';
import { User } from '../types';
import { toast } from 'sonner';

interface Widget {
  id: string;
  type: 'chart' | 'list' | 'kpi_group' | 'table';
  title: string;
  source: 'global' | 'batches' | 'inventory' | 'production' | 'quality';
  visualization?: 'bar' | 'pie' | 'line' | 'area' | 'list' | 'table';
  config?: any;
  isPinned?: boolean;
}

interface DashboardLayout {
  i: string;
  x: number;
  y: number;
  w: number;
  h: number;
  minW?: number;
  minH?: number;
  static?: boolean;
}

export const CustomizableDashboard = ({ user }: { user: User }) => {
  const [layouts, setLayouts] = useState<{ lg: DashboardLayout[] }>({ lg: [] });
  const [widgets, setWidgets] = useState<Widget[]>([]);
  const [isEditing, setIsEditing] = useState(false);
  const [isAddingWidget, setIsAddingWidget] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [dashboardType, setDashboardType] = useState<'default' | 'role' | 'user'>('default');
  
  const { width, mounted, containerRef } = useContainerWidth();

  // New Widget State
  const [newWidget, setNewWidget] = useState<Partial<Widget>>({
    type: 'chart',
    title: 'New Widget',
    source: 'batches',
    visualization: 'bar'
  });

  useEffect(() => {
    fetchDashboard();
  }, []);

  const fetchDashboard = async () => {
    try {
      setIsLoading(true);
      const res = await api.get('/dashboard/layout');
      const { layout, widgets, type } = res.data;
      
      // Ensure layout items have the required 'i' property for react-grid-layout
      const formattedLayout = (layout || []).map((item: any) => ({
        ...item,
        i: item.i || item.id // Fallback to id if i is missing
      }));

      setLayouts({ lg: formattedLayout });
      setWidgets(widgets || []);
      setDashboardType(type);
    } catch (error) {
      console.error('Failed to fetch dashboard:', error);
      toast.error('Failed to load dashboard');
    } finally {
      setIsLoading(false);
    }
  };

  const saveDashboard = async () => {
    try {
      await api.post('/dashboard/layout', {
        layout: layouts.lg,
        widgets
      });
      toast.success('Dashboard saved successfully');
      setIsEditing(false);
      setDashboardType('user');
    } catch (error) {
      console.error('Failed to save dashboard:', error);
      toast.error('Failed to save dashboard');
    }
  };

  const resetDashboard = async () => {
    if (window.confirm('Are you sure you want to reset your dashboard to default?')) {
      try {
        await api.post('/dashboard/layout', { layout: null, widgets: null });
        fetchDashboard();
        toast.success('Dashboard reset to default');
      } catch (error) {
        toast.error('Failed to reset dashboard');
      }
    }
  };

  const onLayoutChange = (currentLayout: any, allLayouts: any) => {
    if (isEditing) {
      setLayouts(allLayouts);
    }
  };

  const addWidget = () => {
    const id = `widget_${Date.now()}`;
    const widget: Widget = {
      id,
      type: newWidget.type as any,
      title: newWidget.title || 'New Widget',
      source: newWidget.source as any,
      visualization: newWidget.visualization as any,
      config: {}
    };

    const layoutItem: DashboardLayout = {
      i: id,
      x: (layouts.lg.length * 4) % 12,
      y: Infinity, // puts it at the bottom
      w: 4,
      h: 4,
      minW: 2,
      minH: 2
    };

    setWidgets([...widgets, widget]);
    setLayouts({
      lg: [...layouts.lg, layoutItem]
    });
    setIsAddingWidget(false);
  };

  const removeWidget = (id: string) => {
    setWidgets(widgets.filter(w => w.id !== id));
    setLayouts({
      lg: layouts.lg.filter(l => l.i !== id)
    });
  };

  const togglePin = (id: string) => {
    setWidgets(widgets.map(w => 
      w.id === id ? { ...w, isPinned: !w.isPinned } : w
    ));
    setLayouts({
      lg: layouts.lg.map(l => 
        l.i === id ? { ...l, static: !l.static } : l
      )
    });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <RefreshCw className="w-8 h-8 animate-spin text-pharma-accent" />
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-pharma-primary flex items-center gap-2">
            <Layout className="w-6 h-6" />
            Dashboard
            {dashboardType !== 'user' && (
              <span className="text-xs font-normal bg-slate-100 text-slate-500 px-2 py-1 rounded-full">
                {dashboardType === 'role' ? `${user.role} Default` : 'Standard Default'}
              </span>
            )}
          </h1>
          <p className="text-slate-500 text-sm mt-1">
            Monitor your operations and key performance indicators.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {!isEditing ? (
            <>
              <button
                onClick={() => setIsEditing(true)}
                className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 rounded-xl text-sm font-medium hover:bg-slate-50 transition-colors"
              >
                <Settings className="w-4 h-4" />
                Customize
              </button>
              {dashboardType === 'user' && (
                <button
                  onClick={resetDashboard}
                  className="p-2 text-slate-400 hover:text-red-500 transition-colors"
                  title="Reset to Default"
                >
                  <RotateCcw className="w-4 h-4" />
                </button>
              )}
            </>
          ) : (
            <>
              <button
                onClick={() => setIsAddingWidget(true)}
                className="flex items-center gap-2 px-4 py-2 bg-pharma-accent text-white rounded-xl text-sm font-medium hover:bg-pharma-accent/90 transition-colors"
              >
                <Plus className="w-4 h-4" />
                Add Widget
              </button>
              <button
                onClick={saveDashboard}
                className="flex items-center gap-2 px-4 py-2 bg-pharma-primary text-white rounded-xl text-sm font-medium hover:bg-pharma-primary/90 transition-colors"
              >
                <Save className="w-4 h-4" />
                Save Changes
              </button>
              <button
                onClick={() => {
                  setIsEditing(false);
                  fetchDashboard(); // Revert changes
                }}
                className="px-4 py-2 bg-white border border-slate-200 rounded-xl text-sm font-medium hover:bg-slate-50 transition-colors"
              >
                Cancel
              </button>
            </>
          )}
        </div>
      </div>

      {/* Grid */}
      <div 
        ref={containerRef}
        className={cn("min-h-[600px] rounded-3xl transition-all duration-300", isEditing ? "bg-slate-50/50 ring-2 ring-dashed ring-slate-200 p-4" : "")}
      >
        {mounted && (
          <ResponsiveGridLayout
            className="layout"
            layouts={layouts}
            breakpoints={{ lg: 1200, md: 996, sm: 768, xs: 480, xxs: 0 }}
            cols={{ lg: 12, md: 10, sm: 6, xs: 4, xxs: 2 }}
            rowHeight={100}
            width={width}
            dragConfig={{ enabled: isEditing, handle: ".drag-handle" }}
            resizeConfig={{ enabled: isEditing }}
            onLayoutChange={onLayoutChange}
            margin={[20, 20]}
          >
            {widgets.map(widget => (
              <div key={widget.id} className="group">
                <WidgetWrapper 
                  widget={widget} 
                  isEditing={isEditing} 
                  onRemove={() => removeWidget(widget.id)}
                  onTogglePin={() => togglePin(widget.id)}
                />
              </div>
            ))}
          </ResponsiveGridLayout>
        )}
      </div>

      {/* Add Widget Modal */}
      <AnimatePresence>
        {isAddingWidget && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden"
            >
              <div className="p-6 border-b border-slate-100 flex items-center justify-between">
                <h2 className="text-xl font-bold text-pharma-primary">Add New Widget</h2>
                <button onClick={() => setIsAddingWidget(false)} className="p-2 hover:bg-slate-100 rounded-full transition-colors">
                  <X className="w-5 h-5 text-slate-400" />
                </button>
              </div>

              <div className="p-6 space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Widget Title</label>
                  <input
                    type="text"
                    value={newWidget.title}
                    onChange={e => setNewWidget({ ...newWidget, title: e.target.value })}
                    className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-pharma-accent outline-none"
                    placeholder="e.g., Batch Yield Analysis"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Data Source</label>
                    <select
                      value={newWidget.source}
                      onChange={e => setNewWidget({ ...newWidget, source: e.target.value as any })}
                      className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-pharma-accent outline-none"
                    >
                      <option value="global">Global Metrics</option>
                      <option value="batches">Batches</option>
                      <option value="inventory">Inventory</option>
                      <option value="production">Production</option>
                      <option value="quality">Quality</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Widget Type</label>
                    <select
                      value={newWidget.type}
                      onChange={e => setNewWidget({ ...newWidget, type: e.target.value as any })}
                      className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-pharma-accent outline-none"
                    >
                      <option value="chart">Chart</option>
                      <option value="kpi_group">KPI Group</option>
                      <option value="list">List</option>
                      <option value="table">Table</option>
                    </select>
                  </div>
                </div>

                {newWidget.type === 'chart' && (
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Visualization</label>
                    <div className="grid grid-cols-4 gap-2">
                      {[
                        { id: 'bar', icon: BarChart3, label: 'Bar' },
                        { id: 'pie', icon: PieChartIcon, label: 'Pie' },
                        { id: 'line', icon: LineChartIcon, label: 'Line' },
                        { id: 'area', icon: Activity, label: 'Area' }
                      ].map(vis => (
                        <button
                          key={vis.id}
                          onClick={() => setNewWidget({ ...newWidget, visualization: vis.id as any })}
                          className={cn(
                            "flex flex-col items-center gap-1 p-3 rounded-xl border transition-all",
                            newWidget.visualization === vis.id 
                              ? "border-pharma-accent bg-pharma-accent/5 text-pharma-accent" 
                              : "border-slate-100 hover:border-slate-200 text-slate-500"
                          )}
                        >
                          <vis.icon className="w-5 h-5" />
                          <span className="text-[10px] font-medium">{vis.label}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <div className="p-6 bg-slate-50 flex gap-3">
                <button
                  onClick={addWidget}
                  className="flex-1 py-3 bg-pharma-primary text-white rounded-xl font-bold hover:bg-pharma-primary/90 transition-colors"
                >
                  Add to Dashboard
                </button>
                <button
                  onClick={() => setIsAddingWidget(false)}
                  className="flex-1 py-3 bg-white border border-slate-200 text-slate-600 rounded-xl font-bold hover:bg-slate-50 transition-colors"
                >
                  Cancel
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

const WidgetWrapper = ({ widget, isEditing, onRemove, onTogglePin }: { 
  widget: Widget, 
  isEditing: boolean, 
  onRemove: () => void,
  onTogglePin: () => void
}) => {
  return (
    <div className="h-full bg-white border border-slate-200 rounded-3xl shadow-sm overflow-hidden flex flex-col group/widget">
      {/* Widget Header */}
      <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between bg-white">
        <div className="flex items-center gap-2">
          {isEditing && (
            <div className="drag-handle cursor-grab active:cursor-grabbing p-1 hover:bg-slate-100 rounded transition-colors">
              <GripVertical className="w-4 h-4 text-slate-400" />
            </div>
          )}
          <h3 className="text-sm font-semibold text-pharma-primary truncate max-w-[150px]">
            {widget.title}
          </h3>
        </div>

        <div className="flex items-center gap-1">
          {isEditing && (
            <>
              <button 
                onClick={onTogglePin}
                className={cn(
                  "p-1.5 rounded-lg transition-colors",
                  widget.isPinned ? "text-pharma-accent bg-pharma-accent/10" : "text-slate-400 hover:bg-slate-100"
                )}
                title={widget.isPinned ? "Unpin Widget" : "Pin Widget"}
              >
                {widget.isPinned ? <Pin className="w-3.5 h-3.5" /> : <PinOff className="w-3.5 h-3.5" />}
              </button>
              <button 
                onClick={onRemove}
                className="p-1.5 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                title="Remove Widget"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </>
          )}
          {!isEditing && (
            <button className="p-1.5 text-slate-400 hover:bg-slate-50 rounded-lg transition-colors">
              <MoreVertical className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Widget Content */}
      <div className="flex-1 p-4 overflow-auto min-h-0">
        <WidgetContent widget={widget} />
      </div>
    </div>
  );
};

const WidgetContent = ({ widget }: { widget: Widget }) => {
  const [data, setData] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setIsLoading(true);
        const res = await api.get('/dashboard/widgets/data', {
          params: {
            source: widget.source,
            type: widget.type,
            visualization: widget.visualization
          }
        });
        setData(res.data);
      } catch (error) {
        console.error('Failed to fetch widget data:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
    const interval = setInterval(fetchData, 60000); // Auto refresh every 60s
    return () => clearInterval(interval);
  }, [widget.source, widget.type, widget.visualization]);

  if (isLoading && !data) {
    return (
      <div className="flex items-center justify-center h-full">
        <RefreshCw className="w-5 h-5 animate-spin text-slate-300" />
      </div>
    );
  }

  if (!data) return <div className="text-xs text-slate-400 text-center mt-4">No data available</div>;

  if (widget.type === 'kpi_group') {
    if (!Array.isArray(data)) return <div className="text-xs text-slate-400 text-center mt-4">Invalid KPI data format</div>;
    return (
      <div className="grid grid-cols-2 gap-4 h-full content-center">
        {data.map((kpi: any, idx: number) => (
          <div key={idx} className="space-y-1">
            <p className="text-[10px] font-medium text-slate-500 uppercase tracking-wider">{kpi.label}</p>
            <div className="flex items-baseline gap-2">
              <p className="text-xl font-bold text-pharma-primary">{kpi.value}</p>
              {kpi.trend && (
                <span className={cn(
                  "text-[10px] font-bold",
                  kpi.trend > 0 ? "text-emerald-500" : "text-rose-500"
                )}>
                  {kpi.trend > 0 ? '+' : ''}{kpi.trend}%
                </span>
              )}
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (widget.type === 'chart') {
    if (!Array.isArray(data)) return <div className="text-xs text-slate-400 text-center mt-4">Invalid chart data format</div>;
    return (
      <ResponsiveContainer width="100%" height="100%">
        {widget.visualization === 'pie' ? (
          <PieChart>
            <Pie
              data={data}
              innerRadius="60%"
              outerRadius="80%"
              paddingAngle={5}
              dataKey="value"
            >
              {data.map((entry: any, index: number) => (
                <Cell key={`cell-${index}`} fill={['#0f172a', '#10b981', '#6366f1', '#f59e0b', '#ef4444'][index % 5]} />
              ))}
            </Pie>
            <Tooltip 
              contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
            />
          </PieChart>
        ) : widget.visualization === 'line' ? (
          <LineChart data={data}>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
            <XAxis dataKey="name" hide />
            <YAxis hide />
            <Tooltip 
              contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
            />
            <Line type="monotone" dataKey="value" stroke="#10b981" strokeWidth={3} dot={false} />
          </LineChart>
        ) : widget.visualization === 'area' ? (
          <AreaChart data={data}>
            <defs>
              <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <XAxis dataKey="name" hide />
            <YAxis hide />
            <Tooltip />
            <Area type="monotone" dataKey="value" stroke="#10b981" fillOpacity={1} fill="url(#colorValue)" />
          </AreaChart>
        ) : (
          <BarChart data={data}>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
            <XAxis dataKey="name" hide />
            <YAxis hide />
            <Tooltip 
              contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
            />
            <Bar dataKey="value" fill="#0f172a" radius={[4, 4, 0, 0]} />
          </BarChart>
        )}
      </ResponsiveContainer>
    );
  }

  if (widget.type === 'list') {
    if (!Array.isArray(data)) return <div className="text-xs text-slate-400 text-center mt-4">Invalid list data format</div>;
    return (
      <div className="space-y-3">
        {data.map((item: any, idx: number) => (
          <div key={idx} className="flex items-center justify-between p-2 hover:bg-slate-50 rounded-xl transition-colors">
            <div className="flex items-center gap-3">
              <div className={cn(
                "w-2 h-2 rounded-full",
                item.status === 'Critical' ? 'bg-rose-500' : 
                item.status === 'Warning' ? 'bg-amber-500' : 'bg-emerald-500'
              )} />
              <div>
                <p className="text-xs font-semibold text-pharma-primary">{item.title}</p>
                <p className="text-[10px] text-slate-400">{item.subtitle}</p>
              </div>
            </div>
            <p className="text-xs font-bold text-pharma-primary">{item.value}</p>
          </div>
        ))}
      </div>
    );
  }

  return <div className="text-xs text-slate-400 text-center mt-4">Unsupported widget type</div>;
};

function cn(...classes: string[]) {
  return classes.filter(Boolean).join(' ');
}
