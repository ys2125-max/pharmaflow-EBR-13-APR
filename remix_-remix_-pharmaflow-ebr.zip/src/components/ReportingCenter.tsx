import React, { useState, useEffect } from 'react';
import { 
  BarChart3, FileText, Search, Filter, Download, 
  PieChart, TrendingUp, AlertTriangle, CheckCircle2, 
  Clock, Calendar, User, Database, Box, Settings,
  ChevronRight, ArrowUpRight, ArrowDownRight,
  Brain, MessageSquare, Mic, Share2, Printer,
  Layers, ClipboardList, History, Shield, Info,
  Plus, Trash2, Save, FileJson, FileSpreadsheet, FileCode
} from 'lucide-react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  LineChart, Line, AreaChart, Area, PieChart as RePieChart, Pie, Cell,
  ComposedChart, Scatter
} from 'recharts';
import { motion, AnimatePresence } from 'motion/react';
import api from '../services/api';
import { toast } from 'sonner';
import { cn } from '../lib/utils';
import { GoogleGenAI } from "@google/genai";
import JSZip from 'jszip';
import { saveAs } from 'file-saver';
import jsPDF from 'jspdf';
import 'jspdf-autotable';

// Types
interface Report {
  id: string;
  type: string;
  category: string;
  title: string;
  product?: string;
  batchNumber?: string;
  equipment?: string;
  operator: string;
  status: 'Draft' | 'Final' | 'Archived';
  createdAt: string;
  tags: string[];
  version: number;
}

export const ReportingCenter = ({ user }: { user: any }) => {
  const [activeTab, setActiveTab] = useState<'repository' | 'analytics' | 'ai' | 'builder'>('repository');
  const [reports, setReports] = useState<Report[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [aiQuery, setAiQuery] = useState('');
  const [isAiProcessing, setIsAiProcessing] = useState(false);
  const [aiResponse, setAiResponse] = useState<any>(null);
  const [selectedReports, setSelectedReports] = useState<string[]>([]);
  const [filters, setFilters] = useState({
    category: 'All',
    status: 'All',
    dateRange: 'All Time'
  });

  const [inspectionMode, setInspectionMode] = useState(false);

  useEffect(() => {
    fetchReports();
  }, []);

  const fetchReports = async () => {
    setLoading(true);
    try {
      // In a real app, this would fetch from a central reports table
      // For now, we'll aggregate from various endpoints or use mock data
      const res = await api.get('/reports');
      if (Array.isArray(res.data)) {
        setReports(res.data);
      } else if (res.data && Array.isArray(res.data.data)) {
        setReports(res.data.data);
      } else {
        throw new Error("Invalid reports data format");
      }
    } catch (e) {
      // Mock data
      setReports([
        { id: 'R-1001', type: 'Batch Record', category: 'Production', title: 'Batch Summary PARA-500 BN-1122', product: 'Paracetamol 500mg', batchNumber: 'BN-1122', operator: 'Production Operator', status: 'Final', createdAt: '2026-03-10T14:30:00Z', tags: ['GMP', 'Batch', 'Critical'], version: 1 },
        { id: 'R-1002', type: 'Audit Trail', category: 'Compliance', title: 'Audit Log - March Week 1', operator: 'System Administrator', status: 'Final', createdAt: '2026-03-07T10:00:00Z', tags: ['Audit', '21CFR', 'Critical'], version: 1 },
        { id: 'R-1003', type: 'Deviation', category: 'Quality', title: 'Temp Excursion - Room 101', batchNumber: 'BN-1122', equipment: 'Mixer-01', operator: 'Production Operator', status: 'Final', createdAt: '2026-03-11T09:15:00Z', tags: ['Deviation', 'Temp', 'Critical'], version: 2 },
        { id: 'R-1004', type: 'Calibration', category: 'Equipment', title: 'Balance BAL-05 Calibration', equipment: 'BAL-05', operator: 'Maintenance Tech', status: 'Final', createdAt: '2026-03-05T11:00:00Z', tags: ['Calibration', 'Equipment'], version: 1 },
        { id: 'R-1005', type: 'Cleaning', category: 'Production', title: 'Line Clearance - Suite 4', equipment: 'Suite 4', operator: 'Production Operator', status: 'Final', createdAt: '2026-03-12T16:45:00Z', tags: ['Cleaning', 'GMP'], version: 1 },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const handleAiSearch = async () => {
    if (!aiQuery.trim()) return;
    setIsAiProcessing(true);
    try {
      const apiKey = process.env.GEMINI_API_KEY || process.env.API_KEY;
      if (!apiKey) {
        toast.error("Gemini API key is not configured.");
        setIsAiProcessing(false);
        return;
      }
      const ai = new GoogleGenAI({ apiKey });
      
      const prompt = `
        You are an AI assistant for a Pharmaceutical Manufacturing Platform (PharmaFlow).
        The user is asking a question about production reports: "${aiQuery}"
        
        Available Reports Data (Summary):
        ${JSON.stringify((Array.isArray(reports) ? reports : []).map(r => ({ id: r.id, title: r.title, category: r.category, status: r.status, tags: r.tags })))}
        
        Task:
        1. Analyze the query.
        2. Provide a concise summary of the findings based on the available reports.
        3. Suggest filters (category, status) if applicable.
        4. Return the response in JSON format.
        
        Format:
        {
          "summary": "Your analysis here...",
          "filters": { "category": "...", "status": "..." },
          "relevantReportIds": ["R-1001", ...]
        }
      `;

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
        config: {
          responseMimeType: "application/json"
        }
      });

      const data = JSON.parse(response.text || '{}');
      
      setAiResponse(data);
      if (data.filters) {
        setFilters(prev => ({ ...prev, ...data.filters }));
      }
    } catch (e) {
      console.error(e);
      toast.error("AI analysis failed. Please ensure your API key is configured.");
    } finally {
      setIsAiProcessing(false);
    }
  };

  const downloadReport = (report: Report, format: string) => {
    const fileName = `${report.type.replace(/\s+/g, '')}_${report.product?.replace(/\s+/g, '') || 'NA'}_${report.batchNumber || 'NA'}_${new Date().toISOString().split('T')[0]}.${format}`;
    toast.success(`Downloading ${fileName}...`);
    // Implementation for different formats
  };

  const bulkDownload = async () => {
    if (selectedReports.length === 0) return toast.error("No reports selected");
    const zip = new JSZip();
    const folder = zip.folder("PharmaFlow_Reports");
    
    selectedReports.forEach(id => {
      const report = reports.find(r => r.id === id);
      if (report) {
        folder?.file(`${report.id}.txt`, `Report Content for ${report.title}`);
      }
    });

    const content = await zip.generateAsync({ type: "blob" });
    saveAs(content, `Bulk_Reports_${new Date().toISOString().split('T')[0]}.zip`);
  };

  const filteredReports = Array.isArray(reports) ? reports.filter(r => {
    const matchesSearch = r.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                         r.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         r.tags.some(t => t.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesCategory = filters.category === 'All' || r.category === filters.category;
    const matchesStatus = filters.status === 'All' || r.status === filters.status;
    const matchesInspection = !inspectionMode || r.tags.includes('Critical');
    return matchesSearch && matchesCategory && matchesStatus && matchesInspection;
  }) : [];

  return (
    <div className="space-y-8">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Reporting & Analytics Center</h1>
          <p className="text-slate-500">AI-powered centralized hub for GMP compliance and production intelligence.</p>
        </div>
        <div className="flex gap-3">
          <button 
            onClick={() => setInspectionMode(!inspectionMode)}
            className={cn(
              "flex items-center gap-2 px-4 py-2 rounded-xl font-bold text-sm transition-all shadow-sm",
              inspectionMode 
                ? "bg-red-600 text-white shadow-red-200" 
                : "bg-white text-slate-600 border border-slate-200 hover:border-red-500 hover:text-red-500"
            )}
          >
            <Shield size={18} /> {inspectionMode ? 'Exit Inspection Mode' : 'FDA Inspection Mode'}
          </button>
          <button className="btn-secondary flex items-center gap-2" onClick={() => window.print()}>
            <Printer size={18} /> Print View
          </button>
          <button className="btn-primary flex items-center gap-2" onClick={bulkDownload}>
            <Share2 size={18} /> Bulk Export
          </button>
        </div>
      </header>

      {/* Navigation Tabs */}
      <div className="flex border-b border-slate-200 gap-8">
        {[
          { id: 'repository', label: 'Report Repository', icon: Database },
          { id: 'analytics', label: 'Advanced Analytics', icon: BarChart3 },
          { id: 'ai', label: 'AI Assistant', icon: Brain },
          { id: 'builder', label: 'Report Builder', icon: Plus },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={cn(
              "flex items-center gap-2 pb-4 text-sm font-bold transition-all border-b-2",
              activeTab === tab.id ? "border-pharma-accent text-pharma-primary" : "border-transparent text-slate-400 hover:text-slate-600"
            )}
          >
            <tab.icon size={18} />
            {tab.label}
          </button>
        ))}
      </div>

      <div className="space-y-6">
        {activeTab === 'repository' && (
          <>
            {/* Filter Panel */}
            <div className="glass-panel p-6 grid grid-cols-1 md:grid-cols-4 gap-4 bg-slate-50/50">
              <div className="relative md:col-span-2">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
                <input 
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  className="input-field pl-12 bg-white"
                  placeholder="Search reports by ID, title, or tags..."
                />
              </div>
              <select 
                value={filters.category}
                onChange={e => setFilters({...filters, category: e.target.value})}
                className="input-field bg-white"
              >
                <option value="All">All Categories</option>
                <option value="Production">Production</option>
                <option value="Quality">Quality</option>
                <option value="Compliance">Compliance</option>
                <option value="Equipment">Equipment</option>
              </select>
              <select 
                value={filters.status}
                onChange={e => setFilters({...filters, status: e.target.value})}
                className="input-field bg-white"
              >
                <option value="All">All Statuses</option>
                <option value="Final">Final</option>
                <option value="Draft">Draft</option>
                <option value="Archived">Archived</option>
              </select>
            </div>

            {/* Reports Table */}
            <div className="glass-panel overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                <thead>
                  <tr className="bg-slate-50/50 text-slate-500 text-[10px] font-bold uppercase tracking-wider">
                    <th className="px-6 py-4">
                      <input 
                        type="checkbox" 
                        onChange={e => setSelectedReports(e.target.checked ? reports.map(r => r.id) : [])}
                        checked={selectedReports.length === reports.length && reports.length > 0}
                      />
                    </th>
                    <th className="px-6 py-4">Report ID</th>
                    <th className="px-6 py-4">Title</th>
                    <th className="px-6 py-4">Category</th>
                    <th className="px-6 py-4">Date</th>
                    <th className="px-6 py-4">Status</th>
                    <th className="px-6 py-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {loading ? (
                    <tr><td colSpan={7} className="px-6 py-12 text-center text-slate-400">Loading repository...</td></tr>
                  ) : filteredReports.map(report => (
                    <tr key={report.id} className="hover:bg-slate-50/50 transition-colors group">
                      <td className="px-6 py-4">
                        <input 
                          type="checkbox" 
                          checked={selectedReports.includes(report.id)}
                          onChange={() => setSelectedReports(prev => prev.includes(report.id) ? prev.filter(id => id !== report.id) : [...prev, report.id])}
                        />
                      </td>
                      <td className="px-6 py-4 font-mono text-xs font-bold text-pharma-primary">{report.id}</td>
                      <td className="px-6 py-4">
                        <div className="flex flex-col">
                          <span className="text-sm font-medium text-slate-900">{report.title}</span>
                          <div className="flex gap-1 mt-1">
                            {report.tags.map(tag => (
                              <span key={tag} className="text-[8px] px-1.5 py-0.5 bg-slate-100 text-slate-500 rounded uppercase font-bold">{tag}</span>
                            ))}
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-sm text-slate-600">{report.category}</td>
                      <td className="px-6 py-4 text-sm text-slate-600">{new Date(report.createdAt).toLocaleDateString()}</td>
                      <td className="px-6 py-4">
                        <span className={cn(
                          "px-2 py-1 rounded text-[10px] font-bold uppercase",
                          report.status === 'Final' ? "bg-emerald-100 text-emerald-700" : "bg-slate-100 text-slate-700"
                        )}>
                          {report.status}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-right">
                        <div className="flex justify-end gap-2">
                          <button onClick={() => downloadReport(report, 'pdf')} className="p-2 text-slate-400 hover:text-red-500 transition-colors" title="Download PDF">
                            <FileText size={18} />
                          </button>
                          <button onClick={() => downloadReport(report, 'xlsx')} className="p-2 text-slate-400 hover:text-emerald-500 transition-colors" title="Download Excel">
                            <FileSpreadsheet size={18} />
                          </button>
                          <button className="p-2 text-slate-400 hover:text-pharma-accent transition-colors" title="View Details">
                            <ChevronRight size={18} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              </div>
            </div>
          </>
        )}

        {activeTab === 'analytics' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="glass-panel p-6 space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-slate-800 flex items-center gap-2">
                  <TrendingUp size={20} className="text-emerald-500" /> Yield Trends by Product
                </h3>
                <select className="text-xs border-none bg-slate-100 rounded-lg px-2 py-1">
                  <option>Last 30 Days</option>
                  <option>Last Quarter</option>
                </select>
              </div>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={[
                    { name: 'Batch 1', yield: 98.2 },
                    { name: 'Batch 2', yield: 97.5 },
                    { name: 'Batch 3', yield: 99.1 },
                    { name: 'Batch 4', yield: 96.8 },
                    { name: 'Batch 5', yield: 98.5 },
                    { name: 'Batch 6', yield: 97.2 },
                  ]}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                    <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fontSize: 10}} />
                    <YAxis axisLine={false} tickLine={false} tick={{fontSize: 10}} domain={[90, 100]} />
                    <Tooltip />
                    <Area type="monotone" dataKey="yield" stroke="#10b981" fill="#10b981" fillOpacity={0.1} />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="glass-panel p-6 space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-slate-800 flex items-center gap-2">
                  <AlertTriangle size={20} className="text-amber-500" /> Deviation Frequency
                </h3>
                <button className="text-xs text-pharma-accent font-bold">View Report</button>
              </div>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={[
                    { name: 'Equipment', count: 12 },
                    { name: 'Process', count: 8 },
                    { name: 'Material', count: 5 },
                    { name: 'Human Error', count: 15 },
                    { name: 'Environment', count: 3 },
                  ]}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                    <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fontSize: 10}} />
                    <YAxis axisLine={false} tickLine={false} tick={{fontSize: 10}} />
                    <Tooltip />
                    <Bar dataKey="count" fill="#f59e0b" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="glass-panel p-6 space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-slate-800 flex items-center gap-2">
                  <PieChart size={20} className="text-blue-500" /> Equipment Utilization
                </h3>
              </div>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <RePieChart>
                    <Pie
                      data={[
                        { name: 'In Use', value: 65 },
                        { name: 'Idle', value: 20 },
                        { name: 'Maintenance', value: 10 },
                        { name: 'Cleaning', value: 5 },
                      ]}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={80}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      <Cell fill="#3b82f6" />
                      <Cell fill="#94a3b8" />
                      <Cell fill="#f59e0b" />
                      <Cell fill="#10b981" />
                    </Pie>
                    <Tooltip />
                    <Legend />
                  </RePieChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="glass-panel p-6 space-y-6 bg-pharma-primary text-white border-none">
              <h3 className="font-bold flex items-center gap-2">
                <Brain size={20} className="text-amber-400" /> AI Predictive Insights
              </h3>
              <div className="space-y-4">
                <div className="p-4 bg-white/10 rounded-xl border border-white/10">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold uppercase text-amber-400">High Risk</span>
                    <span className="text-[10px] opacity-60">Predicted 2h ago</span>
                  </div>
                  <p className="text-sm font-medium">Mixer-03 showing vibration patterns similar to previous failure in Batch BN-992. Maintenance recommended within 48h.</p>
                </div>
                <div className="p-4 bg-white/10 rounded-xl border border-white/10">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold uppercase text-emerald-400">Optimization</span>
                    <span className="text-[10px] opacity-60">Predicted 5h ago</span>
                  </div>
                  <p className="text-sm font-medium">Reducing granulation time by 4 minutes could increase throughput by 12% without affecting quality attributes.</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'ai' && (
          <div className="max-w-4xl mx-auto space-y-8">
            <div className="glass-panel p-8 space-y-6 text-center">
              <div className="w-20 h-20 bg-pharma-primary text-white rounded-3xl flex items-center justify-center mx-auto shadow-xl">
                <Brain size={40} />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-slate-900">AI Report Assistant</h2>
                <p className="text-slate-500">Ask questions about your production data, find reports, or generate summaries.</p>
              </div>
              
              <div className="relative max-w-2xl mx-auto">
                <textarea 
                  value={aiQuery}
                  onChange={e => setAiQuery(e.target.value)}
                  className="input-field min-h-[120px] pt-4 pl-12 pr-12 text-lg"
                  placeholder="e.g., 'Show me all batches produced last week with yield below 98%'"
                />
                <Brain className="absolute left-4 top-4 text-pharma-accent" size={24} />
                <button className="absolute right-4 bottom-4 p-2 bg-slate-100 text-slate-500 rounded-lg hover:bg-slate-200">
                  <Mic size={20} />
                </button>
              </div>

              <div className="flex justify-center gap-3">
                <button 
                  onClick={handleAiSearch}
                  disabled={isAiProcessing || !aiQuery.trim()}
                  className="btn-primary flex items-center gap-2 px-8"
                >
                  {isAiProcessing ? 'Analyzing Data...' : <><Search size={20} /> Analyze & Search</>}
                </button>
                <button className="btn-secondary flex items-center gap-2">
                  <History size={20} /> Recent Queries
                </button>
              </div>

              <div className="flex flex-wrap justify-center gap-2 pt-4">
                <span className="text-xs font-bold text-slate-400 uppercase w-full mb-2">Suggested Queries</span>
                {['Batches with deviations last month', 'Yield trend for Paracetamol', 'Operator performance summary', 'Equipment utilization mixer 3'].map(q => (
                  <button 
                    key={q}
                    onClick={() => setAiQuery(q)}
                    className="px-3 py-1.5 bg-slate-50 text-slate-600 rounded-full text-xs hover:bg-slate-100 transition-colors border border-slate-200"
                  >
                    {q}
                  </button>
                ))}
              </div>
            </div>

            <AnimatePresence>
              {aiResponse && (
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="glass-panel p-8 space-y-6"
                >
                  <div className="flex items-center justify-between border-b border-slate-100 pb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-emerald-50 text-emerald-600 rounded-xl flex items-center justify-center">
                        <CheckCircle2 size={24} />
                      </div>
                      <div>
                        <h3 className="font-bold text-slate-900">Analysis Complete</h3>
                        <p className="text-xs text-slate-500">Found 3 relevant reports and generated 1 summary insight.</p>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <button className="p-2 hover:bg-slate-50 rounded-lg text-slate-400"><Share2 size={18} /></button>
                      <button className="p-2 hover:bg-slate-50 rounded-lg text-slate-400"><Download size={18} /></button>
                    </div>
                  </div>

                  <div className="prose prose-slate max-w-none">
                    <p className="text-slate-700 leading-relaxed">
                      Based on your query, I've analyzed the production data for the last 30 days. 
                      There were <strong>12 batches</strong> of Paracetamol 500mg completed. 
                      The average yield was <strong>97.8%</strong>, which is slightly below the target of 98.5%. 
                      I identified <strong>2 batches</strong> (BN-1122 and BN-1125) where temperature excursions occurred during the mixing stage, likely contributing to the lower yield.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4">
                    {filteredReports.slice(0, 3).map(report => (
                      <div key={report.id} className="p-4 border border-slate-100 rounded-2xl hover:border-pharma-accent transition-all cursor-pointer group">
                        <div className="flex justify-between items-start mb-2">
                          <FileText className="text-slate-400 group-hover:text-pharma-accent" size={20} />
                          <ArrowUpRight size={16} className="text-slate-300" />
                        </div>
                        <p className="text-xs font-bold text-pharma-primary mb-1">{report.id}</p>
                        <p className="text-sm font-medium text-slate-800 line-clamp-2">{report.title}</p>
                      </div>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        )}

        {activeTab === 'builder' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-1 space-y-6">
              <div className="glass-panel p-6 space-y-6">
                <h3 className="font-bold text-slate-800">Report Components</h3>
                <div className="space-y-3">
                  {[
                    { label: 'Data Table', icon: Layers },
                    { label: 'Trend Chart', icon: TrendingUp },
                    { label: 'KPI Summary', icon: Box },
                    { label: 'Audit Trail', icon: History },
                    { label: 'Signature Block', icon: Shield },
                    { label: 'Deviation List', icon: AlertTriangle },
                  ].map(item => (
                    <div key={item.label} className="p-4 border border-dashed border-slate-200 rounded-xl flex items-center gap-3 text-slate-500 hover:border-pharma-accent hover:text-pharma-accent cursor-move transition-all">
                      <item.icon size={20} />
                      <span className="text-sm font-medium">{item.label}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="glass-panel p-6 space-y-4">
                <h3 className="font-bold text-slate-800">Report Settings</h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Report Title</label>
                    <input className="input-field" placeholder="Custom Report Title" />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Auto-Schedule</label>
                    <select className="input-field">
                      <option>None</option>
                      <option>Daily</option>
                      <option>Weekly</option>
                      <option>Monthly</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>

            <div className="lg:col-span-2">
              <div className="glass-panel p-8 min-h-[600px] flex flex-col items-center justify-center border-dashed border-2 border-slate-200 text-slate-400 space-y-4">
                <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center">
                  <Plus size={32} />
                </div>
                <div className="text-center">
                  <p className="font-bold text-slate-600">Drag components here to build your report</p>
                  <p className="text-sm">Select from the components on the left to create a custom regulatory or production report.</p>
                </div>
                <div className="flex gap-3 pt-4">
                  <button className="btn-secondary flex items-center gap-2">
                    <Save size={18} /> Save Template
                  </button>
                  <button className="btn-primary flex items-center gap-2">
                    <Printer size={18} /> Generate Preview
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
