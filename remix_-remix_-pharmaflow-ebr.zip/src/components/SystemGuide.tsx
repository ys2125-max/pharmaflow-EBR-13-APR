import React, { useState } from 'react';
import { 
  HelpCircle, BookOpen, MessageSquare, Search, 
  ChevronRight, PlayCircle, Info, AlertCircle, 
  CheckCircle2, Settings, Users, Database, 
  Layers, ClipboardList, BarChart3, Shield,
  Warehouse, ShoppingCart, Truck, Clock,
  PlusCircle, Save, Send, Download, ExternalLink,
  Lightbulb, Zap, Terminal, Microscope, Loader2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { toast } from 'sonner';
import { cn } from '../lib/utils';
import { GoogleGenAI } from "@google/genai";
import { HelpTooltip } from './HelpTooltip';

interface GuideSection {
  id: string;
  title: string;
  icon: any;
  content: string;
  steps?: string[];
  role?: string;
}

export const SystemGuide = () => {
  const [activeTab, setActiveTab] = useState<'modules' | 'workflows' | 'ai' | 'training'>('modules');
  const [selectedSection, setSelectedSection] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [aiQuery, setAiQuery] = useState('');
  const [aiResponse, setAiResponse] = useState<string | null>(null);
  const [isAiLoading, setIsAiLoading] = useState(false);

  const sections: GuideSection[] = [
    {
      id: 'dashboard',
      title: 'Dashboard & Overview',
      icon: BarChart3,
      content: 'The Dashboard provides a real-time overview of manufacturing operations, including active batches, pending reviews, and system health metrics. It is the primary entry point for all users to monitor production status. It uses a "Bento Grid" layout to maximize information density while maintaining clarity.',
      steps: [
        'View active batch counts and status distribution (e.g., "Work in Process", "Under Review").',
        'Monitor real-time production trends using the Yield vs. Quality chart.',
        'Access quick actions like "Start New Batch" or "Review Deviations" directly from the sidebar.',
        'Check system notifications and alerts for critical equipment failures or calibration needs.'
      ]
    },
    {
      id: 'ebr',
      title: 'Electronic Batch Records (EBR)',
      icon: ClipboardList,
      content: 'The EBR module is where manufacturing processes are designed and executed. It replaces traditional paper batch records with structured, validated digital workflows that ensure 21 CFR Part 11 compliance. It supports dynamic formulas, conditional logic, and electronic signatures.',
      steps: [
        'Workflow Designer: Create and version manufacturing processes (e.g., "Aspirin 500mg Granulation").',
        'Instance Execution: Perform batch steps with real-time validation (e.g., "Weight must be between 100g and 110g").',
        'Electronic Signatures: Sign off on steps and reviews securely using your system password.',
        'Review & Approval: QA review of completed batch records with full audit trail visibility.'
      ],
      role: 'Operator, Reviewer, QA'
    },
    {
      id: 'scheduling',
      title: 'Supply Chain & Scheduling',
      icon: Clock,
      content: 'Manage the production schedule, warehouse inventory, and material requirements. This module ensures that equipment and materials are available before production starts. It integrates with the Warehouse module for real-time stock tracking.',
      steps: [
        'Warehouse Management: Track bin locations and stock levels for raw materials (e.g., "API-001 in Bin A-12").',
        'BOM Management: Define Bill of Materials for each product, including excipients and active ingredients.',
        'Production Scheduling: Assign batches to equipment and time slots to prevent resource conflicts.',
        'Purchasing & Shipping: Manage raw material intake and finished goods dispatch with full traceability.'
      ],
      role: 'Admin, Planner'
    },
    {
      id: 'equipment',
      title: 'Equipment Management',
      icon: Settings,
      content: 'Track the status, calibration, and maintenance of all manufacturing equipment. The system prevents the use of equipment that is not cleaned or calibrated. Each piece of equipment has a unique "System Status" (e.g., "In Use", "Cleaning Needed", "Calibrated").',
      steps: [
        'Equipment Inventory: List all assets with their current status and location.',
        'Calibration Tracking: Monitor next calibration dates and receive alerts 30 days in advance.',
        'Maintenance Logs: Record all service and repair activities with electronic signatures.',
        'Cleaning Verification: Log and verify cleaning between batches to prevent cross-contamination.'
      ]
    },
    {
      id: 'quality',
      title: 'Quality & Deviations',
      icon: AlertCircle,
      content: 'Manage deviations, CAPAs, and quality control checks. The system automatically flags unusual process parameters and guides the investigation process. It ensures that no batch is released without a closed deviation or an approved justification.',
      steps: [
        'Deviation Logging: Record any unplanned events during production (e.g., "Temperature spike in Reactor 1").',
        'Investigation: Document root cause analysis and impact assessment using the built-in investigation form.',
        'CAPA Management: Create and track corrective and preventive actions to prevent recurrence.',
        'QA Release: Final approval for batch distribution after all quality checks are satisfied.'
      ],
      role: 'QA, Reviewer'
    },
    {
      id: 'reporting',
      title: 'Reporting & Analytics',
      icon: Database,
      content: 'Access all system reports and perform advanced data analysis. The AI-powered reporting center provides insights into process capability and production performance. Reports can be exported in PDF and Excel formats with custom headers and footers.',
      steps: [
        'Report Repository: Central library for all generated reports, including Audit Trails and Batch Summaries.',
        'AI Search: Find data using natural language queries (e.g., "Show me all batches with deviations in 2023").',
        'Trend Analysis: Visualize yield and quality trends over time using interactive Recharts components.',
        'Regulatory Export: Generate inspection-ready documentation that complies with FDA and EMA requirements.'
      ]
    },
    {
      id: 'audit',
      title: 'Audit Trail & Compliance',
      icon: Shield,
      content: 'The Audit Trail module captures every action taken in the system, including logins, data entries, signatures, and configuration changes. It provides a "Who, What, When, Where, Why" record for every transaction.',
      steps: [
        'Real-time Logging: Every button click and data entry is logged with a timestamp and user ID.',
        'Version Control: View previous and new values for every data change (e.g., "Weight changed from 100g to 105g").',
        'Signature Meaning: Every electronic signature includes a meaning (e.g., "Approved", "Verified", "Executed").',
        'Review History: Track the full lifecycle of a batch from creation to final QA release.'
      ]
    },
    {
      id: 'help',
      title: 'Help & Support System',
      icon: HelpCircle,
      content: 'The PharmaFlow platform features an integrated help system designed to provide context-aware support throughout the application. Every major button includes a small question mark icon that provides a quick explanation of its function.',
      steps: [
        'Contextual Tooltips: Hover over the "?" icon on any button to see a brief description of what it does.',
        'Direct Guide Links: Click the "View System Notes" link within a tooltip to jump directly to the relevant section in this guide.',
        'AI Assistant: Use the "AI Help Assistant" tab to ask natural language questions about system operations.',
        'Training Mode: Practice complex tasks in a safe sandbox environment without affecting production data.'
      ]
    }
  ];

  const handleAiHelp = async () => {
    if (!aiQuery.trim()) return;
    setIsAiLoading(true);
    try {
      const apiKey = process.env.GEMINI_API_KEY || process.env.API_KEY;
      if (!apiKey) {
        toast.error("Gemini API key is not configured.");
        setIsAiLoading(false);
        return;
      }
      const ai = new GoogleGenAI({ apiKey });
      
      const prompt = `
        You are a helpful AI assistant for the PharmaFlow EBR platform.
        The user has a question about how to use the system: "${aiQuery}"
        
        System Context:
        PharmaFlow is a digital Electronic Batch Record system for pharmaceutical manufacturing.
        Modules: Dashboard, EBR (Workflows, Instances), Supply Chain (Warehouse, Scheduling), Equipment, Quality (Deviations, CAPA), Reporting.
        Compliance: 21 CFR Part 11, GMP.
        
        Task:
        Provide a helpful, concise answer to the user's question. 
        Guide them to the correct module or action.
      `;

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt
      });

      setAiResponse(response.text || "I couldn't find a specific answer. Please try rephrasing your question.");
    } catch (e) {
      console.error(e);
      setAiResponse("Sorry, I'm having trouble connecting to the AI service. Please check your configuration.");
    } finally {
      setIsAiLoading(false);
    }
  };

  const filteredSections = sections.filter(s => 
    s.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
    s.content.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-8 max-w-6xl mx-auto">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">System Guide & Help Center</h1>
          <p className="text-slate-500">Everything you need to know about operating the PharmaFlow EBR platform.</p>
        </div>
        <div className="flex gap-3">
          <button className="btn-secondary flex items-center gap-2">
            <Download size={18} /> Download User Manual
            <HelpTooltip text="Download the complete system documentation in PDF format for offline reading." guideLink="help" />
          </button>
          <button className="btn-primary flex items-center gap-2">
            <PlayCircle size={18} /> Video Tutorials
            <HelpTooltip text="Watch step-by-step video guides on how to operate the system." guideLink="help" />
          </button>
        </div>
      </header>

      {/* Navigation Tabs */}
      <div className="flex border-b border-slate-200 gap-8">
        {[
          { id: 'modules', label: 'Module Documentation', icon: BookOpen },
          { id: 'workflows', label: 'System Workflows', icon: Zap },
          { id: 'ai', label: 'AI Help Assistant', icon: MessageSquare },
          { id: 'training', label: 'Training Mode', icon: Microscope },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={cn(
              "flex items-center gap-2 pb-4 text-sm font-bold transition-all border-b-2",
              activeTab === tab.id ? "border-pharma-accent text-pharma-primary" : "border-transparent text-slate-400 hover:text-slate-600"
            )}
          >
            <tab.icon size={18} />
            {tab.label}
          </button>
        ))}
      </div>

      <div className="space-y-6">
        {activeTab === 'modules' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-1 space-y-4">
              <div className="relative mb-6">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                <input 
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  className="input-field pl-10" 
                  placeholder="Search help topics..." 
                />
              </div>
              <div className="space-y-2">
                {filteredSections.map(section => (
                  <button
                    key={section.id}
                    onClick={() => setSelectedSection(section.id)}
                    className={cn(
                      "w-full flex items-center gap-3 p-4 rounded-xl text-left transition-all border",
                      selectedSection === section.id 
                        ? "bg-pharma-primary text-white border-pharma-primary shadow-lg" 
                        : "bg-white text-slate-600 border-slate-100 hover:border-pharma-accent"
                    )}
                  >
                    <section.icon size={20} />
                    <span className="font-bold text-sm">{section.title}</span>
                    <ChevronRight size={16} className="ml-auto opacity-50" />
                  </button>
                ))}
              </div>
            </div>

            <div className="lg:col-span-2">
              <AnimatePresence mode="wait">
                {selectedSection ? (
                  <motion.div 
                    key={selectedSection}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    className="glass-panel p-8 space-y-8"
                  >
                    {sections.filter(s => s.id === selectedSection).map(section => (
                      <div key={section.id} className="space-y-6">
                        <div className="flex items-center gap-4 border-b border-slate-100 pb-6">
                          <div className="w-16 h-16 bg-slate-50 text-pharma-primary rounded-2xl flex items-center justify-center border border-slate-100">
                            <section.icon size={32} />
                          </div>
                          <div>
                            <h2 className="text-2xl font-bold text-slate-900">{section.title}</h2>
                            {section.role && (
                              <span className="text-[10px] font-bold bg-amber-100 text-amber-700 px-2 py-0.5 rounded uppercase">Roles: {section.role}</span>
                            )}
                          </div>
                        </div>

                        <div className="prose prose-slate max-w-none">
                          <p className="text-slate-600 text-lg leading-relaxed">{section.content}</p>
                        </div>

                        {section.steps && (
                          <div className="space-y-4">
                            <h3 className="font-bold text-slate-800 flex items-center gap-2">
                              <Lightbulb className="text-amber-500" size={20} /> Key Functionalities
                            </h3>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              {section.steps.map((step, i) => (
                                <div key={i} className="p-4 bg-slate-50 rounded-xl border border-slate-100 flex gap-3">
                                  <div className="w-6 h-6 bg-white text-pharma-primary rounded-full flex items-center justify-center text-xs font-bold shrink-0 border border-slate-200">
                                    {i + 1}
                                  </div>
                                  <p className="text-sm text-slate-600">{step}</p>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}

                        <div className="pt-6 border-t border-slate-100 flex justify-between items-center">
                          <div className="flex gap-4">
                            <button className="text-sm font-bold text-pharma-accent flex items-center gap-1 hover:underline">
                              <ExternalLink size={14} /> View API Docs
                            </button>
                            <button className="text-sm font-bold text-pharma-accent flex items-center gap-1 hover:underline">
                              <Terminal size={14} /> System Logic
                            </button>
                          </div>
                          <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Last Updated: March 2026 • v2.4.0</p>
                        </div>
                      </div>
                    ))}
                  </motion.div>
                ) : (
                  <div className="glass-panel p-12 flex flex-col items-center justify-center text-center space-y-4 text-slate-400">
                    <BookOpen size={64} className="opacity-20" />
                    <div>
                      <h3 className="text-xl font-bold text-slate-600">Select a module to learn more</h3>
                      <p className="max-w-md">Choose a section from the left to view detailed documentation, step-by-step guides, and role-based instructions.</p>
                    </div>
                  </div>
                )}
              </AnimatePresence>
            </div>
          </div>
        )}

        {activeTab === 'workflows' && (
          <div className="glass-panel p-8 space-y-12">
            <div className="text-center max-w-2xl mx-auto space-y-4">
              <h2 className="text-2xl font-bold text-slate-900">End-to-End System Workflow</h2>
              <p className="text-slate-500">Understanding how data flows through the PharmaFlow platform from initial design to final batch release.</p>
            </div>

            <div className="relative">
              <div className="absolute left-[50%] top-0 bottom-0 w-px bg-slate-200 hidden md:block" />
              <div className="space-y-12">
                {[
                  { title: 'Workflow Design', desc: 'Admin creates a digital MBR with structured steps and validation rules.', icon: Settings, color: 'bg-blue-500' },
                  { title: 'QA Review & Release', desc: 'QA team reviews the workflow and releases it for production use.', icon: Shield, color: 'bg-amber-500' },
                  { title: 'Batch Scheduling', desc: 'Planner schedules a batch, assigning equipment and materials.', icon: Clock, color: 'bg-purple-500' },
                  { title: 'Production Execution', desc: 'Operators execute steps on the floor, capturing data in real-time.', icon: Zap, color: 'bg-emerald-500' },
                  { title: 'Deviation Handling', desc: 'Any unplanned events are logged and investigated by QA.', icon: AlertCircle, color: 'bg-red-500' },
                  { title: 'Final QA Approval', desc: 'QA performs a final review of the batch record and releases the batch.', icon: CheckCircle2, color: 'bg-emerald-600' },
                ].map((step, i) => (
                  <div key={i} className={cn(
                    "flex flex-col md:flex-row items-center gap-8 relative",
                    i % 2 === 0 ? "md:flex-row" : "md:flex-row-reverse"
                  )}>
                    <div className="flex-1 text-center md:text-right">
                      {i % 2 === 0 && (
                        <div className="space-y-2">
                          <h3 className="font-bold text-slate-900">{step.title}</h3>
                          <p className="text-sm text-slate-500">{step.desc}</p>
                        </div>
                      )}
                    </div>
                    <div className={cn("w-12 h-12 rounded-full flex items-center justify-center text-white shadow-lg z-10", step.color)}>
                      <step.icon size={20} />
                    </div>
                    <div className="flex-1 text-center md:text-left">
                      {i % 2 !== 0 && (
                        <div className="space-y-2">
                          <h3 className="font-bold text-slate-900">{step.title}</h3>
                          <p className="text-sm text-slate-500">{step.desc}</p>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'ai' && (
          <div className="max-w-3xl mx-auto space-y-8">
            <div className="glass-panel p-8 space-y-6 text-center">
              <div className="w-20 h-20 bg-pharma-primary text-white rounded-3xl flex items-center justify-center mx-auto shadow-xl">
                <MessageSquare size={40} />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-slate-900">AI Help Assistant</h2>
                <p className="text-slate-500">Ask any question about the system and get instant answers.</p>
              </div>
              
              <div className="relative">
                <input 
                  value={aiQuery}
                  onChange={e => setAiQuery(e.target.value)}
                  onKeyPress={e => e.key === 'Enter' && handleAiHelp()}
                  className="input-field pl-12 pr-24 py-4 text-lg"
                  placeholder="e.g., 'How do I release a batch?'"
                />
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={24} />
                <button 
                  onClick={handleAiHelp}
                  disabled={isAiLoading}
                  className="absolute right-2 top-1/2 -translate-y-1/2 btn-primary py-2 px-4 flex items-center gap-2"
                >
                  {isAiLoading ? <Loader2 className="animate-spin" size={18} /> : 'Ask AI'}
                  <HelpTooltip text="Send your question to the AI assistant for an instant response." guideLink="ai" />
                </button>
              </div>

              <div className="flex flex-wrap justify-center gap-2">
                {['How to create a workflow?', 'What is a deviation?', 'How to sign a step?', 'Where are reports stored?'].map(q => (
                  <button 
                    key={q}
                    onClick={() => setAiQuery(q)}
                    className="px-3 py-1.5 bg-slate-50 text-slate-600 rounded-full text-xs hover:bg-slate-100 transition-colors border border-slate-200"
                  >
                    {q}
                  </button>
                ))}
              </div>
            </div>

            <AnimatePresence>
              {aiResponse && (
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="glass-panel p-8 bg-pharma-primary text-white border-none shadow-2xl"
                >
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center shrink-0">
                      <MessageSquare size={24} />
                    </div>
                    <div className="space-y-4">
                      <p className="text-lg font-medium leading-relaxed">{aiResponse}</p>
                      <div className="flex gap-3">
                        <button className="text-xs font-bold bg-white/10 hover:bg-white/20 px-3 py-1.5 rounded-lg transition-all">
                          Was this helpful? Yes
                        </button>
                        <button className="text-xs font-bold bg-white/10 hover:bg-white/20 px-3 py-1.5 rounded-lg transition-all">
                          No, tell me more
                        </button>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        )}

        {activeTab === 'training' && (
          <div className="glass-panel p-12 text-center space-y-8">
            <div className="w-24 h-24 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center mx-auto border-4 border-emerald-100">
              <Microscope size={48} />
            </div>
            <div className="max-w-2xl mx-auto space-y-4">
              <h2 className="text-3xl font-bold text-slate-900">Interactive Training Mode</h2>
              <p className="text-slate-600 text-lg">Practice system operations in a safe, isolated environment. No real data will be affected, and all actions are for learning purposes only.</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
              <div className="p-6 border border-slate-100 rounded-3xl space-y-4 hover:shadow-xl transition-all group cursor-pointer">
                <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center group-hover:bg-blue-600 group-hover:text-white transition-all">
                  <PlusCircle size={24} />
                </div>
                <h3 className="font-bold">Workflow Design Lab</h3>
                <p className="text-xs text-slate-500">Learn how to build complex manufacturing steps and validation rules.</p>
              </div>
              <div className="p-6 border border-slate-100 rounded-3xl space-y-4 hover:shadow-xl transition-all group cursor-pointer">
                <div className="w-12 h-12 bg-amber-50 text-amber-600 rounded-2xl flex items-center justify-center group-hover:bg-amber-600 group-hover:text-white transition-all">
                  <Zap size={24} />
                </div>
                <h3 className="font-bold">Execution Simulator</h3>
                <p className="text-xs text-slate-500">Practice batch execution, signature verification, and deviation logging.</p>
              </div>
              <div className="p-6 border border-slate-100 rounded-3xl space-y-4 hover:shadow-xl transition-all group cursor-pointer">
                <div className="w-12 h-12 bg-purple-50 text-purple-600 rounded-2xl flex items-center justify-center group-hover:bg-purple-600 group-hover:text-white transition-all">
                  <Shield size={24} />
                </div>
                <h3 className="font-bold">QA Approval Sandbox</h3>
                <p className="text-xs text-slate-500">Learn the review process and how to identify compliance risks in batch records.</p>
              </div>
            </div>
            <button onClick={() => toast.success('Training environment launched successfully. You are now in sandbox mode.')} className="btn-primary px-12 py-4 text-lg font-bold shadow-xl">
              Launch Training Environment
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
