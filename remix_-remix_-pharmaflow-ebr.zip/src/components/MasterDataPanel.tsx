import React, { useState, useEffect } from 'react';
import { Package, Database, Plus, Search, Filter, ArrowRight, X, Loader2 } from 'lucide-react';
import api from '../services/api';
import { toast } from 'sonner';
import { motion, AnimatePresence } from 'motion/react';
import { useMaterials } from '../hooks/useMaterials';

export const MasterDataPanel = () => {
  const [activeTab, setActiveTab] = useState<'products' | 'materials'>('products');
  const [products, setProducts] = useState<any[]>([]);
  const { materials, loading, refetch } = useMaterials();
  const [showAddModal, setShowAddModal] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  // Form states
  const [formData, setFormData] = useState<any>({});
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      const prodRes = await api.get('/products');
      setProducts(prodRes.data);
    } catch (err) {
      toast.error('Failed to fetch products');
    }
  };

  const filteredData = (activeTab === 'products' ? products : materials).filter(item => 
    item.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    item.code?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    try {
      const endpoint = activeTab === 'products' ? '/products' : '/materials';
      await api.post(endpoint, formData);
      toast.success(`${activeTab === 'products' ? 'Product' : 'Material'} added successfully`);
      setShowAddModal(false);
      setFormData({});
      if (activeTab === 'products') fetchProducts();
      else refetch();
    } catch (err) {
      toast.error(`Failed to add ${activeTab}`);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex bg-slate-100 p-1 rounded-xl">
          <button
            onClick={() => setActiveTab('products')}
            className={`px-6 py-2 rounded-lg font-bold text-sm transition-all ${activeTab === 'products' ? 'bg-white text-pharma-primary shadow-sm' : 'text-slate-50'}`}
          >
            Product Master
          </button>
          <button
            onClick={() => setActiveTab('materials')}
            className={`px-6 py-2 rounded-lg font-bold text-sm transition-all ${activeTab === 'materials' ? 'bg-white text-pharma-primary shadow-sm' : 'text-slate-500'}`}
          >
            Material Master
          </button>
        </div>
        <button 
          onClick={() => {
            setFormData({});
            setShowAddModal(true);
          }}
          className="btn-primary flex items-center gap-2"
        >
          <Plus size={18} /> Add New {activeTab === 'products' ? 'Product' : 'Material'}
        </button>
      </div>

      <AnimatePresence>
        {showAddModal && (
          <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-3xl shadow-2xl max-w-lg w-full overflow-hidden"
            >
              <div className="p-6 bg-pharma-primary text-white flex justify-between items-center">
                <h3 className="text-xl font-bold">Add New {activeTab === 'products' ? 'Product' : 'Material'}</h3>
                <button onClick={() => setShowAddModal(false)} className="p-2 hover:bg-white/10 rounded-full transition-colors">
                  <X size={24} />
                </button>
              </div>
              
              <form onSubmit={handleSave} className="p-8 space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="col-span-2">
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Name</label>
                    <input 
                      required
                      value={formData.name || ''}
                      onChange={e => setFormData({ ...formData, name: e.target.value })}
                      className="input-field" 
                      placeholder="Enter name..." 
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Code</label>
                    <input 
                      required
                      value={formData.code || ''}
                      onChange={e => setFormData({ ...formData, code: e.target.value })}
                      className="input-field" 
                      placeholder="e.g. PROD-001" 
                    />
                  </div>
                  {activeTab === 'products' ? (
                    <>
                      <div>
                        <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Dosage Form</label>
                        <select 
                          required
                          value={formData.dosageForm || ''}
                          onChange={e => setFormData({ ...formData, dosageForm: e.target.value })}
                          className="input-field"
                        >
                          <option value="">Select...</option>
                          <option value="Tablet">Tablet</option>
                          <option value="Capsule">Capsule</option>
                          <option value="Liquid">Liquid</option>
                          <option value="Ointment">Ointment</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Strength</label>
                        <input 
                          value={formData.strength || ''}
                          onChange={e => setFormData({ ...formData, strength: e.target.value })}
                          className="input-field" 
                          placeholder="e.g. 500mg" 
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Batch Size (Standard)</label>
                        <input 
                          type="number"
                          value={formData.batchSize || ''}
                          onChange={e => setFormData({ ...formData, batchSize: e.target.value })}
                          className="input-field" 
                          placeholder="e.g. 10000" 
                        />
                      </div>
                    </>
                  ) : (
                    <>
                      <div>
                        <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Supplier</label>
                        <input 
                          value={formData.supplier || ''}
                          onChange={e => setFormData({ ...formData, supplier: e.target.value })}
                          className="input-field" 
                          placeholder="Supplier name..." 
                        />
                      </div>
                      <div className="col-span-2">
                        <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Storage Conditions</label>
                        <input 
                          value={formData.storageConditions || ''}
                          onChange={e => setFormData({ ...formData, storageConditions: e.target.value })}
                          className="input-field" 
                          placeholder="e.g. Store below 25°C" 
                        />
                      </div>
                    </>
                  )}
                </div>

                <div className="flex gap-4 pt-4">
                  <button type="button" onClick={() => setShowAddModal(false)} className="btn-secondary flex-1">Cancel</button>
                  <button type="submit" disabled={isSaving} className="btn-primary flex-1 flex items-center justify-center gap-2">
                    {isSaving ? <Loader2 className="animate-spin" size={18} /> : <Plus size={18} />}
                    Save {activeTab === 'products' ? 'Product' : 'Material'}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <div className="glass-panel overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex items-center gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input 
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-slate-50 border-none rounded-xl text-sm" 
              placeholder={`Search ${activeTab}...`} 
            />
          </div>
          <button className="p-2 bg-slate-50 text-slate-500 rounded-xl hover:bg-slate-100">
            <Filter size={18} />
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-slate-50/50 text-slate-500 text-[10px] font-bold uppercase tracking-wider">
                <th className="px-6 py-4">Code</th>
                <th className="px-6 py-4">Name</th>
                {activeTab === 'products' ? (
                  <>
                    <th className="px-6 py-4">Dosage Form</th>
                    <th className="px-6 py-4">Strength</th>
                    <th className="px-6 py-4">Batch Size</th>
                  </>
                ) : (
                  <>
                    <th className="px-6 py-4">Supplier</th>
                    <th className="px-6 py-4">Storage</th>
                  </>
                )}
                <th className="px-6 py-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading ? (
                <tr>
                  <td colSpan={6} className="px-6 py-12 text-center">
                    <Loader2 className="animate-spin mx-auto text-pharma-primary" size={24} />
                  </td>
                </tr>
              ) : filteredData.map((item) => (
                <tr key={item.id} className="hover:bg-slate-50/50 transition-colors group">
                  <td className="px-6 py-4 font-mono text-xs font-bold text-pharma-primary">{item.code}</td>
                  <td className="px-6 py-4 text-sm font-medium text-slate-900">{item.name}</td>
                  {activeTab === 'products' ? (
                    <>
                      <td className="px-6 py-4 text-sm text-slate-600">{item.dosage_form}</td>
                      <td className="px-6 py-4 text-sm text-slate-600">{item.strength}</td>
                      <td className="px-6 py-4 text-sm text-slate-600">{item.batch_size_standard}</td>
                    </>
                  ) : (
                    <>
                      <td className="px-6 py-4 text-sm text-slate-600">{item.supplier}</td>
                      <td className="px-6 py-4 text-sm text-slate-600">{item.storage_conditions}</td>
                    </>
                  )}
                  <td className="px-6 py-4 text-right">
                    <button className="p-2 text-slate-400 hover:text-pharma-primary transition-colors">
                      <ArrowRight size={18} />
                    </button>
                  </td>
                </tr>
              ))}
              {!loading && filteredData.length === 0 && (
                <tr>
                  <td colSpan={6} className="px-6 py-12 text-center text-slate-400 italic">
                    No {activeTab} found matching "{searchQuery}".
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
