import React, { useState, useEffect } from 'react';
import { UserPlus, Shield, UserCheck, UserX, Key, History, Search, Filter, MoreVertical, Loader2, Edit2, X, AlertTriangle } from 'lucide-react';
import api from '../services/api';
import { toast } from 'sonner';
import { motion, AnimatePresence } from 'motion/react';
import { ConfirmationModal } from './ConfirmationModal';

export const UserAdminPanel = () => {
  const [users, setUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingUser, setEditingUser] = useState<any>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [confirmModal, setConfirmModal] = useState<{ isOpen: boolean; onConfirm: () => void; title: string; message: string; type?: 'danger' | 'warning' | 'info' } | null>(null);

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    setLoading(true);
    try {
      const res = await api.get('/admin/users');
      if (Array.isArray(res.data)) {
        setUsers(res.data);
      } else {
        console.error('API returned non-array data:', res.data);
        setUsers([]);
      }
    } catch (err) {
      toast.error('Failed to fetch users');
      setUsers([]);
    } finally {
      setLoading(false);
    }
  };

  const toggleUserStatus = async (userId: number, currentStatus: boolean) => {
    setConfirmModal({
      isOpen: true,
      title: currentStatus ? 'Deactivate User' : 'Activate User',
      message: `Are you sure you want to ${currentStatus ? 'deactivate' : 'activate'} this user? ${currentStatus ? 'They will no longer be able to log in.' : 'They will regain access to the system.'}`,
      type: currentStatus ? 'danger' : 'info',
      onConfirm: async () => {
        try {
          await api.post(`/admin/users/${userId}/status`, { isActive: !currentStatus });
          toast.success(`User ${!currentStatus ? 'activated' : 'deactivated'}`);
          fetchUsers();
        } catch (err) {
          toast.error('Failed to update user status');
        }
      }
    });
  };

  const handleUpdateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    try {
      await api.put(`/admin/users/${editingUser.id}`, {
        role: editingUser.role,
        full_name: editingUser.full_name,
        permissions: editingUser.permissions || []
      });
      toast.success('User updated successfully');
      setEditingUser(null);
      fetchUsers();
    } catch (err) {
      toast.error('Failed to update user');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-pharma-primary/10 text-pharma-primary rounded-xl flex items-center justify-center">
            <Shield size={24} />
          </div>
          <h2 className="text-2xl font-bold text-slate-900">User Administration</h2>
        </div>
        <button 
          onClick={() => setShowAddModal(true)}
          className="btn-primary flex items-center gap-2"
        >
          <UserPlus size={18} /> Create New User
        </button>
      </div>

      {/* Edit User Modal */}
      <AnimatePresence>
        {editingUser && (
          <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-3xl shadow-2xl max-w-md w-full overflow-hidden"
            >
              <div className="p-6 bg-pharma-primary text-white flex justify-between items-center">
                <h3 className="text-xl font-bold">Edit User</h3>
                <button onClick={() => setEditingUser(null)} className="p-2 hover:bg-white/10 rounded-full transition-colors">
                  <X size={24} />
                </button>
              </div>
              
              <form onSubmit={handleUpdateUser} className="p-8 space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Full Name</label>
                  <input 
                    required
                    className="w-full px-4 py-3 bg-slate-50 border-none rounded-xl text-sm focus:ring-2 focus:ring-pharma-primary/20 transition-all"
                    value={editingUser.full_name}
                    onChange={(e) => setEditingUser({...editingUser, full_name: e.target.value})}
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Role</label>
                  <select 
                    className="w-full px-4 py-3 bg-slate-50 border-none rounded-xl text-sm focus:ring-2 focus:ring-pharma-primary/20 transition-all"
                    value={editingUser.role}
                    onChange={(e) => setEditingUser({...editingUser, role: e.target.value})}
                  >
                    <option value="Operator">Operator</option>
                    <option value="Reviewer">Reviewer</option>
                    <option value="QA Approver">QA Approver</option>
                    <option value="Admin">Admin</option>
                  </select>
                </div>

                <div className="pt-4 border-t border-slate-100">
                  <label className="block text-xs font-bold text-slate-400 uppercase mb-3">Permissions</label>
                  <div className="grid grid-cols-1 gap-3">
                    {[
                      { id: 'can_edit_workflows', label: 'Manage Workflows' },
                      { id: 'can_edit_inventory', label: 'Manage Inventory' },
                      { id: 'can_edit_quality', label: 'Manage Quality/QC' },
                      { id: 'can_edit_audit', label: 'View Audit Logs' },
                      { id: 'can_edit_settings', label: 'Manage Settings' },
                      { id: 'can_perform_weighing', label: 'Perform Weighing' },
                    ].map(perm => (
                      <label key={perm.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-xl cursor-pointer hover:bg-slate-100 transition-colors">
                        <span className="text-sm font-medium text-slate-700">{perm.label}</span>
                        <input 
                          type="checkbox"
                          className="w-5 h-5 rounded border-slate-300 text-pharma-primary focus:ring-pharma-primary"
                          checked={!!editingUser.permissions?.[perm.id]}
                          onChange={(e) => {
                            const newPerms = { ...(editingUser.permissions || {}) };
                            newPerms[perm.id] = e.target.checked ? 1 : 0;
                            setEditingUser({ ...editingUser, permissions: newPerms });
                          }}
                        />
                      </label>
                    ))}
                  </div>
                </div>
                
                <div className="pt-4 flex gap-3">
                  <button 
                    type="button"
                    onClick={() => setEditingUser(null)}
                    className="flex-1 px-6 py-3 bg-slate-100 text-slate-600 font-bold rounded-xl hover:bg-slate-200 transition-all"
                  >
                    Cancel
                  </button>
                  <button 
                    type="submit"
                    disabled={isSaving}
                    className="flex-1 px-6 py-3 bg-pharma-primary text-white font-bold rounded-xl hover:bg-pharma-primary/90 shadow-lg shadow-pharma-primary/20 transition-all disabled:opacity-50"
                  >
                    {isSaving ? <Loader2 className="animate-spin mx-auto" size={20} /> : 'Save Changes'}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="glass-panel p-4 flex items-center gap-4">
          <div className="w-10 h-10 bg-blue-100 text-blue-600 rounded-xl flex items-center justify-center">
            <UserCheck size={20} />
          </div>
          <div>
            <p className="text-xs font-bold text-slate-400 uppercase">Active Users</p>
            <p className="text-xl font-bold text-slate-900">{Array.isArray(users) ? users.filter(u => u.is_active).length : 0}</p>
          </div>
        </div>
        <div className="glass-panel p-4 flex items-center gap-4">
          <div className="w-10 h-10 bg-red-100 text-red-600 rounded-xl flex items-center justify-center">
            <UserX size={20} />
          </div>
          <div>
            <p className="text-xs font-bold text-slate-400 uppercase">Deactivated</p>
            <p className="text-xl font-bold text-slate-900">{Array.isArray(users) ? users.filter(u => !u.is_active).length : 0}</p>
          </div>
        </div>
        <div className="glass-panel p-4 flex items-center gap-4">
          <div className="w-10 h-10 bg-emerald-100 text-emerald-600 rounded-xl flex items-center justify-center">
            <Shield size={20} />
          </div>
          <div>
            <p className="text-xs font-bold text-slate-400 uppercase">Admins</p>
            <p className="text-xl font-bold text-slate-900">{Array.isArray(users) ? users.filter(u => u.role === 'Admin').length : 0}</p>
          </div>
        </div>
        <div className="glass-panel p-4 flex items-center gap-4">
          <div className="w-10 h-10 bg-amber-100 text-amber-600 rounded-xl flex items-center justify-center">
            <Key size={20} />
          </div>
          <div>
            <p className="text-xs font-bold text-slate-400 uppercase">Recent Logins</p>
            <p className="text-xl font-bold text-slate-900">12</p>
          </div>
        </div>
      </div>

      <div className="glass-panel overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex items-center gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input className="w-full pl-10 pr-4 py-2 bg-slate-50 border-none rounded-xl text-sm" placeholder="Search users..." />
          </div>
          <button className="p-2 bg-slate-50 text-slate-500 rounded-xl hover:bg-slate-100">
            <Filter size={18} />
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-slate-50/50 text-slate-500 text-[10px] font-bold uppercase tracking-wider">
                <th className="px-6 py-4">User</th>
                <th className="px-6 py-4">Role</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4">Last Login</th>
                <th className="px-6 py-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {Array.isArray(users) && users.map((user) => (
                <tr key={user.id} className="hover:bg-slate-50/50 transition-colors group">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-slate-100 text-slate-500 rounded-full flex items-center justify-center font-bold text-xs">
                        {user.full_name.split(' ').map((n: string) => n[0]).join('')}
                      </div>
                      <div>
                        <p className="text-sm font-bold text-slate-900">{user.full_name}</p>
                        <p className="text-xs text-slate-500">@{user.username}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-xs font-bold text-slate-600 bg-slate-100 px-2 py-1 rounded-full">{user.role}</span>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex items-center gap-1.5 text-xs font-bold ${user.is_active ? 'text-emerald-600' : 'text-red-600'}`}>
                      <div className={`w-1.5 h-1.5 rounded-full ${user.is_active ? 'bg-emerald-600' : 'bg-red-600'}`} />
                      {user.is_active ? 'Active' : 'Deactivated'}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-xs text-slate-500">
                    {user.last_login_at ? new Date(user.last_login_at).toLocaleString() : 'Never'}
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <button 
                        onClick={() => setEditingUser(user)}
                        className="p-2 text-pharma-primary hover:bg-pharma-primary/5 rounded-xl transition-colors"
                        title="Edit User"
                      >
                        <Edit2 size={18} />
                      </button>
                      <button 
                        onClick={() => toggleUserStatus(user.id, user.is_active)}
                        className={`p-2 rounded-xl transition-colors ${user.is_active ? 'text-red-400 hover:bg-red-50' : 'text-emerald-400 hover:bg-emerald-50'}`}
                        title={user.is_active ? 'Deactivate' : 'Activate'}
                      >
                        {user.is_active ? <UserX size={18} /> : <UserCheck size={18} />}
                      </button>
                      <button className="p-2 text-slate-400 hover:bg-slate-100 rounded-xl transition-colors">
                        <Key size={18} />
                      </button>
                      <button className="p-2 text-slate-400 hover:bg-slate-100 rounded-xl transition-colors">
                        <History size={18} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {users.length === 0 && !loading && (
                <tr>
                  <td colSpan={5} className="px-6 py-12 text-center text-slate-400 italic">
                    No users found.
                  </td>
                </tr>
              )}
              {loading && (
                <tr>
                  <td colSpan={5} className="px-6 py-12 text-center">
                    <Loader2 className="animate-spin mx-auto text-pharma-primary" size={24} />
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {confirmModal && (
        <ConfirmationModal
          isOpen={confirmModal.isOpen}
          onClose={() => setConfirmModal(null)}
          onConfirm={confirmModal.onConfirm}
          title={confirmModal.title}
          message={confirmModal.message}
          type={confirmModal.type}
        />
      )}
    </div>
  );
};
