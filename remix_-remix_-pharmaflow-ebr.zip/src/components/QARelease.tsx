import React, { useState, useEffect } from 'react';
import { ShieldCheck, CheckCircle, XCircle, AlertTriangle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import api from '../services/api';
import { toast } from 'sonner';
import { ElectronicSignatureModal } from './ElectronicSignatureModal';

export const QARelease = ({ user }: { user: any }) => {
  const [inventory, setInventory] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedItem, setSelectedItem] = useState<any>(null);
  const [qaNotes, setQaNotes] = useState('');
  const [signatureReq, setSignatureReq] = useState<{ status: 'APPROVED' | 'REJECTED' } | null>(null);

  const fetchQuarantined = async () => {
    setLoading(true);
    try {
      const res = await api.get('/inventory');
      const quarantined = res.data.materials.filter((i: any) => i.status === 'QUARANTINE' || i.status === 'IN_TESTING');
      setInventory(quarantined);
    } catch (err) {
      toast.error('Failed to load quarantined inventory');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchQuarantined();
  }, []);

  const handleDecision = async (status: 'APPROVED' | 'REJECTED') => {
    if (!selectedItem) return;
    setSignatureReq({ status });
  };

  const processDecision = async (signature: any) => {
    if (!selectedItem || !signatureReq) return;
    const { status } = signatureReq;
    try {
      await api.post('/warehouse/qa-release', {
        inventory_id: selectedItem.id,
        decision: status,
        reason: qaNotes,
        signature
      });
      toast.success(`Material ${status.toLowerCase()} successfully.`);
      setSelectedItem(null);
      setQaNotes('');
      fetchQuarantined();
    } catch (err: any) {
      toast.error(err.response?.data?.error || 'Failed to update QA status');
    } finally {
      setSignatureReq(null);
    }
  };

  return (
    <div className="space-y-6">
      {signatureReq && (
        <ElectronicSignatureModal
          isOpen={true}
          onClose={() => setSignatureReq(null)}
          onSign={processDecision}
          meaning="Approved"
          action={`QA Release: ${signatureReq.status} for Lot ${selectedItem?.lot_number}`}
        />
      )}
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-lg font-bold flex items-center gap-2">
          <ShieldCheck className="text-pharma-primary" /> QA Release & Disposition
        </h3>
        <button onClick={fetchQuarantined} className="btn-secondary text-sm">Refresh</button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-4">
          {loading ? (
            <div className="p-8 text-center text-slate-400">Loading...</div>
          ) : inventory.length === 0 ? (
            <div className="p-8 text-center text-slate-400 border border-dashed border-slate-200 rounded-xl">
              No items pending QA release.
            </div>
          ) : (
            inventory.map(item => (
              <motion.div 
                key={item.id}
                whileHover={{ scale: 1.01 }}
                onClick={() => setSelectedItem(item)}
                className={`p-4 border rounded-xl cursor-pointer transition-all ${selectedItem?.id === item.id ? 'border-pharma-primary bg-blue-50/50 shadow-sm' : 'border-slate-200 hover:border-slate-300'}`}
              >
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="font-bold text-slate-800">{item.material_name}</h4>
                    <p className="text-xs text-slate-500 mt-1">Lot: {item.lot_number} | Qty: {item.quantity}</p>
                    <p className="text-xs text-slate-500">Received: {new Date(item.created_at).toLocaleDateString()}</p>
                  </div>
                  <span className={`px-2 py-1 rounded text-[10px] font-bold uppercase ${item.status === 'QUARANTINE' ? 'bg-amber-100 text-amber-700' : 'bg-blue-100 text-blue-700'}`}>
                    {item.status}
                  </span>
                </div>
              </motion.div>
            ))
          )}
        </div>

        <div>
          {selectedItem ? (
            <div className="p-6 border border-slate-200 rounded-xl bg-white sticky top-6 shadow-sm">
              <h4 className="font-bold text-slate-800 mb-4 border-b pb-2">Disposition Decision</h4>
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Selected Item</label>
                  <p className="text-sm font-medium">{selectedItem.material_name} (Lot: {selectedItem.lot_number})</p>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">QA Notes / Justification</label>
                  <textarea 
                    value={qaNotes}
                    onChange={e => setQaNotes(e.target.value)}
                    className="input-field min-h-[100px]" 
                    placeholder="Enter analytical results reference, deviations, or release notes..."
                  />
                </div>
                <div className="flex gap-3 pt-4 border-t border-slate-100">
                  <button 
                    onClick={() => handleDecision('REJECTED')}
                    className="flex-1 py-2 bg-red-50 text-red-600 hover:bg-red-100 font-bold rounded-lg text-sm flex items-center justify-center gap-2 transition-colors"
                  >
                    <XCircle size={16} /> Reject
                  </button>
                  <button 
                    onClick={() => handleDecision('APPROVED')}
                    className="flex-1 py-2 bg-emerald-50 text-emerald-600 hover:bg-emerald-100 font-bold rounded-lg text-sm flex items-center justify-center gap-2 transition-colors"
                  >
                    <CheckCircle size={16} /> Approve
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="p-6 border border-slate-200 rounded-xl bg-slate-50 text-center text-slate-400 text-sm h-full flex items-center justify-center">
              Select an item from the list to make a disposition decision.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
