import React, { useState } from 'react';
import { HelpCircle, ExternalLink } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';

interface HelpTooltipProps {
  text: string;
  guideLink?: string;
  className?: string;
}

export const HelpTooltip: React.FC<HelpTooltipProps> = ({ text, guideLink, className }) => {
  const [show, setShow] = useState(false);
  let timer: any;

  const handleMouseEnter = () => {
    clearTimeout(timer);
    setShow(true);
  };

  const handleMouseLeave = () => {
    timer = setTimeout(() => setShow(false), 200);
  };

  return (
    <span
      className={cn("relative inline-flex items-center ml-1", className)}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
    >
      <span
        role="button"
        tabIndex={0}
        onClick={(e) => {
          e.stopPropagation();
          setShow(!show);
        }}
        className="text-slate-400 hover:text-pharma-accent transition-colors p-0.5 rounded-full hover:bg-slate-100 cursor-pointer"
      >
        <HelpCircle size={12} />
      </span>

      <AnimatePresence>
        {show && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 5 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 5 }}
            className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-48 p-3 bg-slate-900 text-white text-[11px] rounded-xl shadow-2xl z-[100] pointer-events-auto"
          >
            <div className="relative">
              <p className="leading-relaxed mb-2">{text}</p>
              {guideLink && (
                <span 
                  role="button"
                  tabIndex={0}
                  onClick={(e) => {
                    e.stopPropagation();
                    window.dispatchEvent(new CustomEvent('open-guide', { detail: { section: guideLink } }));
                  }}
                  className="flex items-center gap-1 text-pharma-accent font-bold hover:underline cursor-pointer"
                >
                  <ExternalLink size={10} /> View System Notes
                </span>
              )}
              {/* Arrow */}
              <div className="absolute top-full left-1/2 -translate-x-1/2 w-2 h-2 bg-slate-900 rotate-45 -mt-1" />
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </span>
  );
};
