import { query, db } from './db.ts';
import bcrypt from 'bcryptjs';

const schema = `
  -- SQLite Schema for PharmaFlow EBR
  
  CREATE TABLE IF NOT EXISTS companies (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    subdomain TEXT UNIQUE,
    settings TEXT DEFAULT '{}',
    is_active INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id INTEGER REFERENCES companies(id) ON DELETE CASCADE,
    username TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    full_name TEXT NOT NULL,
    role TEXT NOT NULL, -- 'Admin', 'Operator', 'Reviewer', 'QA Approver'
    email TEXT,
    phone TEXT,
    is_active INTEGER DEFAULT 1,
    failed_attempts INTEGER DEFAULT 0,
    locked_until DATETIME,
    last_login_at DATETIME,
    permissions TEXT DEFAULT '{}',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(company_id, username)
  );

  CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id INTEGER REFERENCES companies(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    code TEXT NOT NULL,
    strength TEXT,
    dosage_form TEXT,
    batch_size_standard REAL,
    instructions_ref TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(company_id, code)
  );

  CREATE TABLE IF NOT EXISTS materials (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id INTEGER REFERENCES companies(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    code TEXT NOT NULL,
    sku TEXT,
    type TEXT, -- 'Raw Material', 'Intermediate', 'Finished Good'
    lot_number TEXT,
    supplier TEXT,
    specifications TEXT,
    storage_conditions TEXT,
    status TEXT DEFAULT 'Pending', -- 'Pending', 'Approved', 'Rejected', 'Quarantine'
    potency REAL DEFAULT 100,
    tolerance_range REAL DEFAULT 0.05,
    quantity REAL DEFAULT 0,
    unit TEXT DEFAULT 'kg',
    expiry_date DATE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(company_id, code)
  );

  CREATE TABLE IF NOT EXISTS workflows (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id INTEGER REFERENCES companies(id) ON DELETE CASCADE,
    product_id INTEGER REFERENCES products(id),
    name TEXT NOT NULL,
    description TEXT,
    version INTEGER DEFAULT 1,
    status TEXT DEFAULT 'Draft', -- 'Draft', 'Active', 'Archived'
    is_latest INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS workflow_steps (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    workflow_id INTEGER REFERENCES workflows(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    type TEXT NOT NULL,
    step_order INTEGER NOT NULL,
    config TEXT DEFAULT '{}',
    responsible_role TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS batch_records (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id INTEGER REFERENCES companies(id) ON DELETE CASCADE,
    workflow_id INTEGER REFERENCES workflows(id),
    product_id INTEGER REFERENCES products(id),
    product_name TEXT,
    batch_number TEXT NOT NULL,
    status TEXT DEFAULT 'Executing', -- 'Executing', 'Under Review', 'Completed', 'Discontinued', 'Archived'
    current_step_index INTEGER DEFAULT 0,
    created_by INTEGER REFERENCES users(id),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    scheduled_at DATETIME,
    completed_at DATETIME,
    UNIQUE(company_id, batch_number)
  );

  CREATE TABLE IF NOT EXISTS batch_data (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    batch_id INTEGER REFERENCES batch_records(id) ON DELETE CASCADE,
    step_id INTEGER REFERENCES workflow_steps(id),
    data TEXT DEFAULT '{}',
    submitted_by INTEGER REFERENCES users(id),
    submitted_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    version INTEGER DEFAULT 1
  );

  CREATE TABLE IF NOT EXISTS signatures (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    batch_id INTEGER REFERENCES batch_records(id) ON DELETE CASCADE,
    step_id INTEGER REFERENCES workflow_steps(id),
    user_id INTEGER REFERENCES users(id),
    meaning TEXT NOT NULL, -- 'Executed', 'Reviewed', 'Approved', 'Verified'
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    timezone TEXT,
    signature_hash TEXT -- For data integrity verification
  );

  CREATE TABLE IF NOT EXISTS deviations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id INTEGER REFERENCES companies(id) ON DELETE CASCADE,
    batch_id INTEGER REFERENCES batch_records(id),
    step_id INTEGER REFERENCES workflow_steps(id),
    description TEXT NOT NULL,
    root_cause TEXT,
    corrective_action TEXT,
    preventive_action TEXT,
    status TEXT DEFAULT 'Open', -- 'Open', 'Under Investigation', 'Closed'
    qa_approver_id INTEGER REFERENCES users(id),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS capas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id INTEGER REFERENCES companies(id) ON DELETE CASCADE,
    deviation_id INTEGER REFERENCES deviations(id),
    description TEXT NOT NULL,
    assigned_to INTEGER REFERENCES users(id),
    due_date DATE,
    status TEXT DEFAULT 'Open', -- 'Open', 'In Progress', 'Completed', 'Verified'
    effectiveness_verification TEXT,
    qa_approver_id INTEGER REFERENCES users(id),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    message TEXT NOT NULL,
    type TEXT DEFAULT 'info', -- 'info', 'warning', 'error', 'success'
    is_read INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS warehouses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id INTEGER REFERENCES companies(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    location TEXT,
    is_active INTEGER DEFAULT 1
  );

  CREATE TABLE IF NOT EXISTS bins (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id INTEGER REFERENCES companies(id) ON DELETE CASCADE,
    warehouse_id INTEGER REFERENCES warehouses(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    zone TEXT, -- 'Ambient', 'Cold', 'Hazardous'
    is_allergen_zone INTEGER DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS boms (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id INTEGER REFERENCES companies(id) ON DELETE CASCADE,
    product_id INTEGER REFERENCES products(id),
    version TEXT DEFAULT '1.0',
    status TEXT DEFAULT 'Approved',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS bom_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    bom_id INTEGER REFERENCES boms(id) ON DELETE CASCADE,
    material_id INTEGER REFERENCES materials(id),
    quantity REAL NOT NULL,
    unit TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS purchase_orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id INTEGER REFERENCES companies(id) ON DELETE CASCADE,
    po_number TEXT NOT NULL,
    vendor_name TEXT NOT NULL,
    total_amount REAL,
    status TEXT DEFAULT 'Open',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(company_id, po_number)
  );

  CREATE TABLE IF NOT EXISTS shipments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id INTEGER REFERENCES companies(id) ON DELETE CASCADE,
    shipment_number TEXT NOT NULL,
    customer_name TEXT NOT NULL,
    carrier TEXT,
    status TEXT DEFAULT 'Pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(company_id, shipment_number)
  );

  CREATE TABLE IF NOT EXISTS inspections (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id INTEGER REFERENCES companies(id) ON DELETE CASCADE,
    target_type TEXT NOT NULL, -- 'Material', 'Batch', 'Equipment'
    target_id INTEGER NOT NULL,
    inspector_id INTEGER REFERENCES users(id),
    results TEXT,
    status TEXT DEFAULT 'Pending', -- 'Pending', 'Passed', 'Failed'
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS maintenance_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id INTEGER REFERENCES companies(id) ON DELETE CASCADE,
    equipment_id INTEGER REFERENCES equipment(id),
    type TEXT NOT NULL, -- 'Preventive', 'Repair', 'Calibration'
    performed_by TEXT,
    description TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS audit_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id INTEGER REFERENCES companies(id) ON DELETE CASCADE,
    user_id INTEGER REFERENCES users(id),
    action TEXT NOT NULL,
    target_type TEXT NOT NULL,
    target_id INTEGER,
    old_value TEXT,
    new_value TEXT,
    reason TEXT,
    details TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    timezone TEXT
  );

  CREATE TABLE IF NOT EXISTS equipment (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id INTEGER REFERENCES companies(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    asset_id TEXT NOT NULL,
    type TEXT, -- 'Balance', 'Sensor', 'Mixer'
    status TEXT DEFAULT 'Cleaned',
    last_cleaned DATETIME,
    last_calibration DATE,
    next_calibration DATE,
    connection_config TEXT DEFAULT '{}',
    UNIQUE(company_id, asset_id)
  );

  CREATE TABLE IF NOT EXISTS weighing_transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id INTEGER REFERENCES companies(id) ON DELETE CASCADE,
    material_id INTEGER REFERENCES materials(id),
    equipment_id INTEGER REFERENCES equipment(id),
    batch_id INTEGER REFERENCES batch_records(id),
    tare_weight REAL,
    gross_weight REAL,
    net_weight REAL,
    unit TEXT DEFAULT 'kg',
    operator_id INTEGER REFERENCES users(id),
    signature TEXT,
    comments TEXT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS password_resets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT,
    phone TEXT,
    otp TEXT NOT NULL,
    expires_at DATETIME NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS grn (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id INTEGER REFERENCES companies(id) ON DELETE CASCADE,
    po_id INTEGER REFERENCES purchase_orders(id),
    vendor_id INTEGER,
    material_id INTEGER REFERENCES materials(id),
    quantity_received REAL NOT NULL,
    lot_number TEXT,
    status TEXT DEFAULT 'QUARANTINE',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS inventory (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id INTEGER REFERENCES companies(id) ON DELETE CASCADE,
    material_id INTEGER REFERENCES materials(id),
    lot_number TEXT,
    quantity REAL NOT NULL,
    status TEXT DEFAULT 'QUARANTINE',
    expiry_date DATE,
    location_id INTEGER REFERENCES bins(id),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS qc_results (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id INTEGER REFERENCES companies(id) ON DELETE CASCADE,
    inventory_id INTEGER REFERENCES inventory(id),
    test_name TEXT NOT NULL,
    result_value TEXT,
    passed INTEGER DEFAULT 0,
    tested_by INTEGER REFERENCES users(id),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS qa_release (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id INTEGER REFERENCES companies(id) ON DELETE CASCADE,
    inventory_id INTEGER REFERENCES inventory(id),
    decision TEXT NOT NULL,
    reason TEXT,
    reviewer_id INTEGER REFERENCES users(id),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id INTEGER REFERENCES companies(id) ON DELETE CASCADE,
    inventory_id INTEGER REFERENCES inventory(id),
    batch_id INTEGER REFERENCES batch_records(id),
    from_location_id INTEGER REFERENCES bins(id),
    to_location_id INTEGER REFERENCES bins(id),
    quantity REAL,
    user_id INTEGER REFERENCES users(id),
    verifier_id INTEGER REFERENCES users(id),
    type TEXT NOT NULL,
    details TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS role_dashboards (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id INTEGER REFERENCES companies(id) ON DELETE CASCADE,
    role TEXT NOT NULL,
    layout_json TEXT NOT NULL,
    widgets_json TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(company_id, role)
  );

  CREATE TABLE IF NOT EXISTS user_dashboards (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    company_id INTEGER REFERENCES companies(id) ON DELETE CASCADE,
    layout_json TEXT NOT NULL,
    widgets_json TEXT NOT NULL,
    is_active INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`;

export async function initDb() {
  try {
    db.exec("PRAGMA foreign_keys = ON;");
    db.exec(schema);
    
    // Migration: Add missing columns to materials if they don't exist
    try { db.exec("ALTER TABLE materials ADD COLUMN sku TEXT;"); } catch (e) {}
    try { db.exec("ALTER TABLE materials ADD COLUMN lot_number TEXT;"); } catch (e) {}
    try { db.exec("ALTER TABLE materials ADD COLUMN status TEXT DEFAULT 'Pending';"); } catch (e) {}
    try { db.exec("ALTER TABLE materials ADD COLUMN potency REAL DEFAULT 100;"); } catch (e) {}
    try { db.exec("ALTER TABLE materials ADD COLUMN tolerance_range REAL DEFAULT 0.05;"); } catch (e) {}
    try { db.exec("ALTER TABLE materials ADD COLUMN quantity REAL DEFAULT 0;"); } catch (e) {}
    try { db.exec("ALTER TABLE materials ADD COLUMN unit TEXT DEFAULT 'kg';"); } catch (e) {}
    try { db.exec("ALTER TABLE materials ADD COLUMN expiry_date DATE;"); } catch (e) {}
    try { db.exec("ALTER TABLE materials ADD COLUMN type TEXT;"); } catch (e) {}
    try { db.exec("ALTER TABLE bins ADD COLUMN company_id INTEGER REFERENCES companies(id) ON DELETE CASCADE;"); } catch (e) {}
    try { db.exec("UPDATE bins SET company_id = (SELECT company_id FROM warehouses WHERE warehouses.id = bins.warehouse_id) WHERE company_id IS NULL;"); } catch (e) {}
    
    // Migration: Add missing columns to batch_records
    try { db.exec("ALTER TABLE batch_records ADD COLUMN product_name TEXT;"); } catch (e) {}
    try { db.exec("ALTER TABLE workflows ADD COLUMN description TEXT;"); } catch (e) {}
    try { db.exec("ALTER TABLE equipment ADD COLUMN last_cleaned DATETIME;"); } catch (e) {}
    try { db.exec("ALTER TABLE batch_records ADD COLUMN scheduled_at DATETIME;"); } catch (e) {}
    try { db.exec("ALTER TABLE batch_records ADD COLUMN completed_at DATETIME;"); } catch (e) {}

    console.log('SQLite Database Schema Initialized Successfully');

    // Seed Data
    const companyCount = await query("SELECT count(*) as count FROM companies");
    if (companyCount.rows[0].count === 0) {
      console.log('Seeding initial data...');
      
      // 1. Create Demo Company
      const companyRes = await query(`
        INSERT INTO companies (name, subdomain) 
        VALUES ('Demo Pharma', 'demo')
        RETURNING id
      `);
      const companyId = companyRes.rows[0].id;

      // 2. Create Users
      const adminPass = await bcrypt.hash('Admin_Pharma_99!_Secure', 10);
      const opPass = await bcrypt.hash('Operator_Pharma_77!_Work', 10);
      const revPass = await bcrypt.hash('Reviewer_Pharma_55!_Check', 10);
      const qaPass = await bcrypt.hash('QA_Pharma_33!_Approve', 10);

      await query(`
        INSERT INTO users (company_id, username, password_hash, full_name, role) VALUES
        (?, 'admin', ?, 'System Administrator', 'Admin'),
        (?, 'operator', ?, 'Production Operator', 'Operator'),
        (?, 'reviewer', ?, 'Batch Reviewer', 'Reviewer'),
        (?, 'qa', ?, 'QA Approver', 'QA Approver')
      `, [companyId, adminPass, companyId, opPass, companyId, revPass, companyId, qaPass]);

      // 3. Create Role-Based Dashboards
      const adminLayout = [
        { i: 'stats', x: 0, y: 0, w: 12, h: 2, static: true },
        { i: 'batches_chart', x: 0, y: 2, w: 6, h: 4 },
        { i: 'inventory_alerts', x: 6, y: 2, w: 6, h: 4 },
        { i: 'production_trend', x: 0, y: 6, w: 12, h: 4 }
      ];
      const adminWidgets = [
        { id: 'stats', type: 'kpi_group', title: 'Global Metrics', source: 'global' },
        { id: 'batches_chart', type: 'chart', title: 'Batch Status Distribution', source: 'batches', visualization: 'pie' },
        { id: 'inventory_alerts', type: 'list', title: 'Critical Inventory Alerts', source: 'inventory', visualization: 'list' },
        { id: 'production_trend', type: 'chart', title: 'Production Trend', source: 'batches', visualization: 'line' }
      ];

      await query(`
        INSERT INTO role_dashboards (company_id, role, layout_json, widgets_json) 
        VALUES ($1, 'Admin', $2, $3)
      `, [companyId, JSON.stringify(adminLayout), JSON.stringify(adminWidgets)]);

      // 4. Create Demo Product
      const productRes = await query(`
        INSERT INTO products (company_id, name, code, strength, dosage_form)
        VALUES (?, 'Paracetamol 500mg', 'PARA-500', '500mg', 'Tablet')
        RETURNING id
      `, [companyId]);
      const productId = productRes.rows[0].id;

      // 4. Create Demo Workflow
      const workflowRes = await query(`
        INSERT INTO workflows (company_id, product_id, name, status)
        VALUES (?, ?, 'Standard Manufacturing Process', 'Active')
        RETURNING id
      `, [companyId, productId]);
      const workflowId = workflowRes.rows[0].id;

      // 5. Create Workflow Steps
      await query(`
        INSERT INTO workflow_steps (workflow_id, name, type, step_order, responsible_role, config) VALUES
        (?, 'Line Clearance Verification', 'comment', 1, 'Operator', '{"required": true}'),
        (?, 'Material Dispensing Check', 'table', 2, 'Operator', '{"tableConfig": {"columns": [{"id": "mat", "name": "Material"}, {"id": "qty", "name": "Quantity"}]}}'),
        (?, 'Mixing Parameters Log', 'number', 3, 'Operator', '{"unit": "RPM"}'),
        (?, 'Final Quality Check', 'comment', 4, 'QA Approver', '{"required": true}')
      `, [workflowId, workflowId, workflowId, workflowId]);

      // 6. Create Demo Materials
      await query(`
        INSERT INTO materials (company_id, name, code, sku, type, lot_number, status, potency, quantity, unit, expiry_date) VALUES
        (?, 'Paracetamol Powder', 'MAT-001', 'SKU-PARA-01', 'Raw Material', 'LOT-9921', 'Approved', 99.5, 500, 'kg', '2027-12-31'),
        (?, 'Microcrystalline Cellulose', 'MAT-002', 'SKU-MCC-01', 'Raw Material', 'LOT-4412', 'Approved', 100, 1200, 'kg', '2026-06-30'),
        (?, 'Magnesium Stearate', 'MAT-003', 'SKU-MAG-01', 'Raw Material', 'LOT-1102', 'Approved', 100, 50, 'kg', '2028-01-15')
      `, [companyId, companyId, companyId]);

      // 7. Create Demo Equipment
      await query(`
        INSERT INTO equipment (company_id, name, asset_id, type, status, next_calibration) VALUES
        (?, 'Analytical Balance 01', 'BAL-001', 'Balance', 'Cleaned', '2026-09-15'),
        (?, 'Platform Scale 02', 'SCL-002', 'Balance', 'Cleaned', '2026-08-20'),
        (?, 'High Shear Mixer 05', 'MIX-005', 'Mixer', 'Cleaned', '2026-12-01')
      `, [companyId, companyId, companyId]);

      // 8. Seed Supply Chain & Quality
      const whRes = await query(`
        INSERT INTO warehouses (company_id, name, location) 
        VALUES (?, 'Main Distribution Center', 'Zone A-1')
        RETURNING id
      `, [companyId]);
      await query("INSERT INTO warehouses (company_id, name, location) VALUES (?, 'Cold Storage Facility', 'Zone B-4')", [companyId]);
      
      const whId = whRes.rows[0].id;
      await query("INSERT INTO bins (company_id, warehouse_id, name, zone) VALUES (?, ?, 'BIN-A101', 'Ambient')", [companyId, whId]);
      
      const bomRes = await query(`
        INSERT INTO boms (company_id, product_id, version) 
        VALUES (?, ?, '1.0')
        RETURNING id
      `, [companyId, productId]);
      const bomId = bomRes.rows[0].id;
      await query("INSERT INTO bom_items (bom_id, material_id, quantity, unit) VALUES (?, 1, 500, 'mg')", [bomId]);
      
      await query("INSERT INTO purchase_orders (company_id, po_number, vendor_name, total_amount) VALUES (?, 'PO-2026-001', 'Global Pharma Supplies', 15000.00)", [companyId]);
      await query("INSERT INTO shipments (company_id, shipment_number, customer_name, carrier) VALUES (?, 'SHP-99881', 'CVS Pharmacy', 'FedEx')", [companyId]);
      
      await query("INSERT INTO inspections (company_id, target_type, target_id, status) VALUES (?, 'Material', 1, 'Passed')", [companyId]);
      await query("INSERT INTO maintenance_logs (company_id, equipment_id, type, performed_by, description) VALUES (?, 1, 'Preventive', 'John Tech', 'Annual calibration')", [companyId]);

      console.log('Seed data created successfully');
    }
  } catch (err) {
    console.error('Error Initializing Database Schema:', err);
  }
}
