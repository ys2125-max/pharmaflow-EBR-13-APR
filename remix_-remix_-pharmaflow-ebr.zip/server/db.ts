import Database from 'better-sqlite3';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Use a local SQLite database file
export const db = new Database(path.join(__dirname, '../pharmaflow.sqlite'));

// Helper to convert PostgreSQL $1, $2... syntax to SQLite ? syntax
const convertQuery = (text: string) => {
  return text.replace(/\$\d+/g, '?');
};

export const query = async (text: string, params: any[] = []) => {
  const sqliteText = convertQuery(text);
  const stmt = db.prepare(sqliteText);
  
  const upperText = sqliteText.trim().toUpperCase();
  if (upperText.startsWith('SELECT') || upperText.includes('RETURNING')) {
    const rows = stmt.all(...params);
    return { rows, rowCount: rows.length };
  } else {
    const result = stmt.run(...params);
    // Mimic pg response structure
    return { 
      rows: [], 
      rowCount: result.changes,
      lastID: result.lastInsertRowid 
    };
  }
};

export default { query };
