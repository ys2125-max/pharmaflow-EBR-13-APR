import express from "express";
import { query } from "../db.ts";

const router = express.Router();

// Helper to log audit trail
const logAudit = async (companyId: number, userId: number, action: string, details: string) => {
  await query(
    `INSERT INTO audit_logs (company_id, user_id, action, target_type, details) VALUES (?, ?, ?, 'inventory', ?)`,
    [companyId, userId, action, details]
  );
};

// 1. Goods Receiving
router.post("/receive-material", async (req: any, res) => {
  const { po_id, material_id, quantity, lot_number, expiry_date, vendor_id } = req.body;
  const companyId = req.companyId;
  const userId = req.user.id;

  try {
    // Validate PO exists and is open
    // Create GRN (Goods Receipt Note)
    const grnResult = await query(
      `INSERT INTO grn (company_id, po_id, vendor_id, material_id, quantity_received, lot_number, status) 
       VALUES (?, ?, ?, ?, ?, ?, 'QUARANTINE') RETURNING id`,
      [companyId, po_id, vendor_id, material_id, quantity, lot_number]
    );
    
    // Add to inventory in Quarantine status
    await query(
      `INSERT INTO inventory (company_id, material_id, lot_number, quantity, status, expiry_date, location_id) 
       VALUES (?, ?, ?, ?, 'QUARANTINE', ?, (SELECT id FROM bins WHERE name = 'Receiving Dock' LIMIT 1))`,
      [companyId, material_id, lot_number, quantity, expiry_date]
    );

    await logAudit(companyId, userId, 'MATERIAL_RECEIVED', `Received ${quantity} of material ${material_id}, Lot: ${lot_number}`);
    res.json({ success: true, grn_id: grnResult.lastID });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 2. Sampling & QC
router.post("/sample-material", async (req: any, res) => {
  const { inventory_id, sample_quantity } = req.body;
  const companyId = req.companyId;
  const userId = req.user.id;

  try {
    await query(`UPDATE inventory SET quantity = quantity - ? WHERE id = ? AND company_id = ?`, [sample_quantity, inventory_id, companyId]);
    await logAudit(companyId, userId, 'MATERIAL_SAMPLED', `Sampled ${sample_quantity} from inventory ${inventory_id}`);
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post("/qc-test-result", async (req: any, res) => {
  const { inventory_id, test_name, result_value, passed } = req.body;
  const companyId = req.companyId;
  const userId = req.user.id;

  try {
    await query(
      `INSERT INTO qc_results (company_id, inventory_id, test_name, result_value, passed, tested_by) VALUES (?, ?, ?, ?, ?, ?)`,
      [companyId, inventory_id, test_name, result_value, passed ? 1 : 0, userId]
    );
    await logAudit(companyId, userId, 'QC_TEST_RECORDED', `Test ${test_name} for inventory ${inventory_id}: ${passed ? 'PASS' : 'FAIL'}`);
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 3. QA Release
router.post("/qa-release", async (req: any, res) => {
  const { inventory_id, decision, reason } = req.body; // decision: 'APPROVED' | 'REJECTED'
  const companyId = req.companyId;
  const userId = req.user.id;

  try {
    await query(`UPDATE inventory SET status = ? WHERE id = ? AND company_id = ?`, [decision, inventory_id, companyId]);
    await query(
      `INSERT INTO qa_release (company_id, inventory_id, decision, reason, reviewer_id) VALUES (?, ?, ?, ?, ?)`,
      [companyId, inventory_id, decision, reason, userId]
    );
    await logAudit(companyId, userId, 'QA_RELEASE', `Inventory ${inventory_id} marked as ${decision}. Reason: ${reason}`);
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 4. Inventory Movement
router.post("/move-inventory", async (req: any, res) => {
  const { inventory_id, to_location_id } = req.body;
  const companyId = req.companyId;
  const userId = req.user.id;

  try {
    const inv = await query(`SELECT location_id FROM inventory WHERE id = ?`, [inventory_id]);
    const from_location_id = inv.rows[0]?.location_id;

    await query(`UPDATE inventory SET location_id = ? WHERE id = ? AND company_id = ?`, [to_location_id, inventory_id, companyId]);
    await query(
      `INSERT INTO transactions (company_id, inventory_id, from_location_id, to_location_id, user_id, type) VALUES (?, ?, ?, ?, ?, 'MOVE')`,
      [companyId, inventory_id, from_location_id, to_location_id, userId]
    );
    await logAudit(companyId, userId, 'INVENTORY_MOVED', `Moved inventory ${inventory_id} to location ${to_location_id}`);
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 5. Staging & Dispensing
router.post("/stage-material", async (req: any, res) => {
  const { inventory_id, batch_id, quantity } = req.body;
  const companyId = req.companyId;
  const userId = req.user.id;

  try {
    // In a real app, we'd split the inventory record or mark a portion as reserved.
    // For simplicity, we just update the status or location.
    await query(`UPDATE inventory SET status = 'STAGED' WHERE id = ? AND company_id = ?`, [inventory_id, companyId]);
    await logAudit(companyId, userId, 'MATERIAL_STAGED', `Staged ${quantity} of inventory ${inventory_id} for batch ${batch_id}`);
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post("/dispense-material", async (req: any, res) => {
  const { inventory_id, batch_id, quantity_dispensed, verifier_id } = req.body;
  const companyId = req.companyId;
  const userId = req.user.id;

  if (!verifier_id || verifier_id === userId) {
    return res.status(400).json({ error: "Double verification required by a different user." });
  }

  try {
    await query(`UPDATE inventory SET quantity = quantity - ? WHERE id = ? AND company_id = ?`, [quantity_dispensed, inventory_id, companyId]);
    await query(
      `INSERT INTO transactions (company_id, inventory_id, batch_id, quantity, user_id, verifier_id, type) VALUES (?, ?, ?, ?, ?, ?, 'DISPENSE')`,
      [companyId, inventory_id, batch_id, quantity_dispensed, userId, verifier_id]
    );
    await logAudit(companyId, userId, 'MATERIAL_DISPENSED', `Dispensed ${quantity_dispensed} of inventory ${inventory_id} for batch ${batch_id}. Verified by ${verifier_id}`);
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 6. Production Integration
router.post("/consume-material", async (req: any, res) => {
  const { inventory_id, batch_id, quantity } = req.body;
  const companyId = req.companyId;
  const userId = req.user.id;

  try {
    await query(
      `INSERT INTO transactions (company_id, inventory_id, batch_id, quantity, user_id, type) VALUES (?, ?, ?, ?, ?, 'CONSUME')`,
      [companyId, inventory_id, batch_id, quantity, userId]
    );
    await logAudit(companyId, userId, 'MATERIAL_CONSUMED', `Consumed ${quantity} of inventory ${inventory_id} in batch ${batch_id}`);
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post("/create-finished-goods", async (req: any, res) => {
  const { batch_id, product_id, quantity, lot_number, expiry_date } = req.body;
  const companyId = req.companyId;
  const userId = req.user.id;

  try {
    await query(
      `INSERT INTO inventory (company_id, material_id, lot_number, quantity, status, expiry_date, location_id) 
       VALUES (?, ?, ?, ?, 'QUARANTINE', ?, (SELECT id FROM bins WHERE name = 'Finished Goods Quarantine' LIMIT 1))`,
      [companyId, product_id, lot_number, quantity, expiry_date]
    );
    await logAudit(companyId, userId, 'FINISHED_GOODS_CREATED', `Created ${quantity} of product ${product_id}, Lot: ${lot_number} from batch ${batch_id}`);
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 7. Finished Goods & Dispatch
router.post("/release-finished-goods", async (req: any, res) => {
  const { inventory_id, decision, reason } = req.body;
  const companyId = req.companyId;
  const userId = req.user.id;

  try {
    await query(`UPDATE inventory SET status = ? WHERE id = ? AND company_id = ?`, [decision, inventory_id, companyId]);
    await logAudit(companyId, userId, 'FG_QA_RELEASE', `Finished Good ${inventory_id} marked as ${decision}. Reason: ${reason}`);
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post("/dispatch", async (req: any, res) => {
  const { inventory_id, quantity, destination } = req.body;
  const companyId = req.companyId;
  const userId = req.user.id;

  try {
    const inv = await query(`SELECT status FROM inventory WHERE id = ?`, [inventory_id]);
    if (inv.rows[0]?.status !== 'APPROVED') {
      return res.status(400).json({ error: "Cannot dispatch unapproved goods." });
    }

    await query(`UPDATE inventory SET quantity = quantity - ? WHERE id = ? AND company_id = ?`, [quantity, inventory_id, companyId]);
    await query(
      `INSERT INTO transactions (company_id, inventory_id, quantity, user_id, type, details) VALUES (?, ?, ?, ?, 'DISPATCH', ?)`,
      [companyId, inventory_id, quantity, userId, `Dispatched to ${destination}`]
    );
    await logAudit(companyId, userId, 'GOODS_DISPATCHED', `Dispatched ${quantity} of inventory ${inventory_id} to ${destination}`);
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 8. Cycle Count
router.post("/cycle-count", async (req: any, res) => {
  const { inventory_id, physical_quantity, reason } = req.body;
  const companyId = req.companyId;
  const userId = req.user.id;

  try {
    const inv = await query(`SELECT quantity FROM inventory WHERE id = ?`, [inventory_id]);
    const system_quantity = inv.rows[0]?.quantity || 0;
    const discrepancy = physical_quantity - system_quantity;

    await query(`UPDATE inventory SET quantity = ? WHERE id = ? AND company_id = ?`, [physical_quantity, inventory_id, companyId]);
    await query(
      `INSERT INTO transactions (company_id, inventory_id, quantity, user_id, type, details) VALUES (?, ?, ?, ?, 'CYCLE_COUNT_ADJUSTMENT', ?)`,
      [companyId, inventory_id, discrepancy, userId, `Reason: ${reason}`]
    );
    await logAudit(companyId, userId, 'CYCLE_COUNT', `Adjusted inventory ${inventory_id} by ${discrepancy}. Reason: ${reason}`);
    
    // CAPA Integration for inventory discrepancies
    if (Math.abs(discrepancy) > 0) {
      await query(
        `INSERT INTO deviations (company_id, description, status) VALUES (?, ?, 'Open')`,
        [companyId, `Inventory Discrepancy (CAPA Required): Cycle count discrepancy of ${discrepancy} for inventory ID ${inventory_id}. Reason provided: ${reason}`]
      );
    }

    res.json({ success: true, discrepancy });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
